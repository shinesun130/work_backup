/*
 * loadmodel.h
 *
 *  Created on: 2016年12月16日
 *      Author: huinan1
 */

#ifndef LOADMODEL_H_
#define LOADMODEL_H_

#endif /* LOADMODEL_H_ */

#include <string>
#include <vector>
#include <math.h>
#include <map>
#include <iostream>
#include <fstream>
#include <sstream>
#include "StringTool.h"

using namespace std;

struct feature_node
{
    int index;
    double value;
};

class Node
{
private:
    int feature;
    int indexInTree;
    // for intermediate node
    double threshold;
    int yesIndex;
    int noIndex;
    int missingIndex;
    bool isLeaf;
    // for leaf node
    double value;
    string desc;

public:
    bool isLeafNode()
    {
        return this->isLeaf;
    }

    double getValue()
    {
        return this->value;
    }

    double getThresh()
    {
        return this->threshold;
    }

    int getIndex()
    {
        return this->indexInTree;
    }

    Node* asIntermediateNode(int feature, int indexInTree, double threshold,
            int yesIndex, int noIndex, int missingIndex, string desc);
    Node* asLeaf(double value, int indexInTree, string desc);
    int nextNode(const map<int, double>& featureIndex2Value);

    int findFeatureIndex(const struct feature_node* feature_nodes,
            int nr_features);
    string getDesc();

};

class Tree
{
private:
    vector<Node*> nodes;
    vector<int> leafIndex;
    int leafNum;
    int maxNodeIndex;
    int indexInTree;
    static int pow2(int x)
    {
        return 1 << x;
    }
public:
    Tree(int depth);
    ~Tree();

    vector<Node*> getNodes();
    int getLeafNum();
    int getMaxNodeNum()
    {
        return this->maxNodeIndex + 1;
    }
    vector<int> getLeafIndex()
    {
        return this->leafIndex;
    }
    int getIndex()
    {
        return this->indexInTree;
    }
    double predict(const map<int, double>& featureIndex2Value);
    string apply(const map<int, double>& featureIndex2Value);
    Node* findLeaf(const map<int, double>& featureIndex2Value);
    void genNode(string nodeMsg);
    bool toLeaf(string nodeMsg);
    bool toIntermediateNode(string nodeMsg);
    Tree* parse(vector<string> dumps);
};

class XgboostModel
{
private:
    vector<Tree*> trees;
    int treesNum;
    int treeDepth;
    int eachTreeNodesNum;
    int totalNodesNum;

public:
    XgboostModel();
    ~XgboostModel();

    vector<Tree*> getTrees()
    {
        return trees;
    }
    int getTotalNodesNum()
    {
        return totalNodesNum;
    }
    int getEachTreeNodesNum()
    {
        return this->eachTreeNodesNum;
    }
    XgboostModel* build(string customModelFile);
    void parseTreesNumsAndDepth(string parameters);
    static double sigmod(double x)
    {
        return (1 / (1 + exp(-1 * x)));
    }
//  double predict(Vector vector);
    vector<string> calcDecisionPath(
            const map<int, double>& featureIndex2Value);
    double predict_probability(
            const map<int, double>& featureIndex2Value);
//    void get_predict_leaf_index(
//            const map<int, double>& featureIndex2Value,
//            vector<int>& leaf_index);
//
//    void get_one_hot_feature(
//            const map<int, double>& featureIndex2Value,
//            vector<int>& one_hot_feature);
    void get_feature_comb(const map<int, double>& featureIndex2Value,
            vector<float>& comb_feature);
};

