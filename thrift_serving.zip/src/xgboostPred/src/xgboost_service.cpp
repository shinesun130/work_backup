/*****************************************************
 * @file:dupsimilarity.cpp
 *
 * @author:liubo9@staff.sina.com.cn
 *
 * @date:2014-05-16 17:13:25
 *
 * @description:content similarity anlysis
 *****************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <pthread.h>
#include <assert.h>
#include "modulecommon.h"
#include "parsejson.h"
#include "StringTool.h"
#include "parseDataConf.h"
#include "loadmodel.h"

using namespace std;

//ENCODE_TYPE encode = UTF_8;
//GRAN_TYPE gran = NORMAL_WORD;

struct XgboostPredModule
{
    XgboostModel* xgboostModel;
    string configFile;
    logger_t logger;
};

struct module_thread_data
{
    JsonTree_t *ptree;
    JsonText_t *ptext;
//    SegResult *pSegResult;
};

void* module_load(const char * data_dir, logger_t logger)
{
    cerr << "initing global data from:" << data_dir << endl;

    string modelFile = string(data_dir) + "/custom.model";
    XgboostPredModule* module = new XgboostPredModule();
    module->xgboostModel = (new XgboostModel())->build(modelFile);
    module->configFile = data_dir;
    module->logger = logger;
    cerr << "glabal data init success!" << endl;
    return (void*) module;
}

int module_unload(void* plug)
{
    XgboostPredModule *module = (XgboostPredModule*) plug;
    delete (XgboostModel*) module->xgboostModel;
    module->xgboostModel = NULL;
    free(module);
    return 0;
}

void *module_thread_data_create(void* plug)
{
    module_thread_data* thread_data = (module_thread_data*) malloc(
            sizeof(module_thread_data));
    assert(thread_data != NULL);
    thread_data->ptree = CreateJsonTree();
    assert(thread_data->ptree != NULL);
    thread_data->ptext = CreateJsonText(1000);
    assert(thread_data->ptext != NULL);
    XgboostPredModule* module = (XgboostPredModule*) plug;
//  thread_data->pSegResult = module->pTokenizer->CreateSegResult();
    return thread_data;
}

void module_thread_data_release(void*plug, void *thread_data)
{
    module_thread_data* t_data = (module_thread_data*) thread_data;
    if (t_data->ptree != NULL)
    {
        FreeJsonTree(t_data->ptree);
        t_data->ptree = NULL;
        FreeJsonText(t_data->ptext);
        t_data->ptext = NULL;
    }
//    if (t_data->pSegResult != NULL)
//    {
//        delete (SegResult*) t_data->pSegResult;
//        t_data->pSegResult = NULL;
//    }
    free(thread_data);
}

int ParseJsonInput(module_thread_data *workData, map<string, string>&tField,
        char *input, int srcLen)
{
    int ret;
    JsonTree_t *ptree = workData->ptree;
    PairNode_t *ppair;
    ret = ParseJson(input, srcLen, ptree);
    if (ret <= 0)
        return -1;
    if (ptree->rootType != V_PAIR_ARRAY)
        return -2;
    map<string, string>::iterator it;
    tField.clear();
    ForEachPairNode(ptree, 0, ppair)
    {
        if (ppair->keyStr == NULL || ppair->pStr == NULL
                || (ppair->v_type != V_STR && ppair->v_type != V_VALUE_STR))
            return -3;
#ifdef DEBUG2
        fprintf(stderr,"parseJson:%s-->%s\n",ppair->keyStr,ppair->pStr);
#endif
        it = tField.find(ppair->keyStr);
        if (it == tField.end())
            tField.insert(
                    map<string, string>::value_type(ppair->keyStr,
                            ppair->pStr));
    }
    return 0;
}

void GenResult(char *resultStr, int &resultLen, map<string, string>& resMap)
{
    map<string, string>::iterator sit;
    string resstr = "{";
    for (sit = resMap.begin(); sit != resMap.end(); sit++)
    {
        resstr += "\"" + sit->first + "\":\"" + sit->second + "\",";
    }
    string res = resstr.substr(0, resstr.size() - 1) + "}";
#ifdef DEBUG
    cerr<<res<<"#"<<endl;
#endif
    strcpy(resultStr, res.c_str());
    resultLen = res.length();
}

int module_processor(void* module, const char *input, int intput_space_size,
        char *output, int output_space_size, void *thread_data)
{
#ifdef DEBUG
    cerr<<"input:"<<input<<endl;
#endif

    strcpy(output, input);
    XgboostPredModule* workModule = (XgboostPredModule*) module;
    module_thread_data* workData = (module_thread_data*) thread_data;
    strcpy(output, "default result");
    map<string, string> dataField;
    map<string, string> rMap;
    map<string, string>::iterator sit;
    char Log[65535];
    memcpy(Log, input, intput_space_size);
    int iret = ParseJsonInput(workData, dataField, Log, intput_space_size);
    if (iret < 0)
    {
        rMap.insert(
                map<string, string>::value_type("error", "parse input failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }

    map<string, DataConf> featureMap;

    bool parser = CDataConfParser::parseDataConf(featureMap,
            workModule->configFile + "/data.conf");

    if (!parser)
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "parse data.conf failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }

    map<int, double> feature2Value;
    bool getInstance = CDataConfParser::getInstance(featureMap, dataField,
            feature2Value);

    if (!getInstance)
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "get instance failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }

    vector<float> comb_feature;
    workModule->xgboostModel->get_feature_comb(feature2Value, comb_feature);
    string combFeature = "";
    ostringstream stream;
    for (int i = 0; i < comb_feature.size(); i++)
    {
        if (comb_feature[i] > 0)
        {
            stream << i;
            stream << ",";
        }
    }
    combFeature = stream.str();
    if (combFeature.empty())
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "get predict feature failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }
    combFeature = combFeature.substr(0, combFeature.size() - 1);
    rMap.insert(map<string, string>::value_type("featureComb", combFeature));
    GenResult(output, output_space_size, rMap);

    return output_space_size;
}

