#include "parsejson.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include<ctype.h>

#define MIN_VALUE_NUM 10
#define MIN_PAIR_NUM 20

int ExpandJsonTreeValueBuffer(JsonTree_t *ptree, int newValueNum);

int ExpandJsonTreePairBuffer(JsonTree_t *ptree, int newPairNum);

int ParseJsonMarkStr(char *text, int textLen,  JsonTree_t *ptree,int top);
int ParseJsonOtherStr(char *text, int textLen,  JsonTree_t *ptree,int top);

int ParseJsonWholeStr(char *text, int textLen, JsonTree_t *ptree);

int ParseJsonValueArray(char *text, int textLen,ValueNode_t* pValueArray, JsonTree_t *ptree, int top);
int ParseJsonPairArray(char *text, int textLen,PairNode_t* pPairArray, JsonTree_t *ptree, int top);


JsonTree_t * CreateJsonTree()
{
	JsonTree_t *ptree = (JsonTree_t*)calloc(sizeof(JsonTree_t),1);
	if(ptree==NULL)
	  return NULL;

	ptree->values = (ValueNode_t*)calloc(MIN_VALUE_NUM, sizeof(ValueNode_t));
	if(ptree->values==NULL)
	{
		goto ERR;
	}

	ptree->pairs = (PairNode_t*)calloc(MIN_PAIR_NUM,sizeof(PairNode_t));
	if(ptree->pairs==NULL)
	{
		goto ERR;
	}

	ptree->maxValueNum = MIN_VALUE_NUM;
	ptree->maxPairNum = MIN_PAIR_NUM;

	return ptree;
ERR:
	FreeJsonTree(ptree);
	return NULL;
}



void FreeJsonTree(JsonTree_t *ptree)
{
	if(ptree->values!=NULL)
	  free(ptree->values);
	if(ptree->pairs!=NULL)	
	  free(ptree->pairs);
	free(ptree);
}

int ExpandJsonTreeValueBuffer(JsonTree_t *ptree, int newValueNum)
{
	ValueNode_t *pvalues = ptree->values;
	ptree->values = (ValueNode_t*)realloc(pvalues,sizeof(ValueNode_t)*newValueNum);

	if(ptree->values==NULL)
	{
		ptree->errNo = 2;
		sprintf(ptree->errInfo,"realloc failed  newValueNum:%d\n",newValueNum);		
		ptree->values = pvalues;
		return -1;
	}

	ptree->maxValueNum = newValueNum;
	return 0;
}

int ExpandJsonTreePairBuffer(JsonTree_t *ptree, int newPairNum)
{
	PairNode_t *ppairs = ptree->pairs;
	ptree->pairs = (PairNode_t*)realloc(ppairs,sizeof(PairNode_t)*newPairNum);
	if(ptree->pairs==NULL)
	{
		ptree->errNo = 2;
		sprintf(ptree->errInfo,"realloc failed  newPairNum:%d\n",newPairNum);

		ptree->pairs = ppairs;
		return -1;
	}
	ptree->maxPairNum = newPairNum;

	return 0;
}


int ParseJson(char *text, int textLen,JsonTree_t *ptree)
{
	ptree->curBranchNum = 0 ;

	if(text[0]=='{')
	{
		ptree->rootType = V_PAIR_ARRAY;
		ptree->curValueNum = 0;
		ptree->curPairNum = 1;
		return ParseJsonPairArray(text,textLen,ptree->pairs,ptree, MAX_TREE_DEEP_LEVEL);
	}
	else if(text[0]=='[')
	{
		ptree->rootType = V_VALUE_ARRAY;
		ptree->curValueNum = 1;
		ptree->curPairNum = 0;
		return ParseJsonValueArray(text,textLen,ptree->values,ptree, MAX_TREE_DEEP_LEVEL);
	}
	else 
	{
		ptree->errNo = 1;
		sprintf(ptree->errInfo,"first char not { or [");
		return -1;
	}
}

int ParseJsonTop(char *text, int textLen , JsonTree_t *ptree, int top)
{
	ptree->curValueNum=0;

	if(top<=0)
	  top =MAX_TREE_DEEP_LEVEL;

	if(text[0]=='{')
	{
		ptree->rootType = V_PAIR_ARRAY;
		ptree->curValueNum = 0;
		ptree->curPairNum = 1;
		return ParseJsonPairArray(text,textLen,ptree->pairs,ptree, top);
	}
	else if(text[0]=='[')
	{
		ptree->rootType = V_VALUE_ARRAY;
		ptree->curValueNum = 1;
		ptree->curPairNum = 0;
		return ParseJsonValueArray(text,textLen,ptree->values,ptree, top);
	}
	else 
	{
		ptree->errNo = 1;
		sprintf(ptree->errInfo,"first char not { or [");
		return -1;
	}	
}



int ParseJsonMarkStr(char *text, int textLen, JsonTree_t *ptree, int top)
{
	char *ptr = text+1;
	char *curPtr=ptr;
	char *endptr = text+textLen;
	int isGood = 0;

	if(text[0]!='"')
	{
		ptree->errNo = 1;
		sprintf(ptree->errInfo,"ParseJsonMarkStr failed .no start char\n");

		return -1;
	}

	while(ptr<endptr)
	{
		if(ptr[0]=='\\')
		{
			ptr++;
			if(ptr<endptr)
			{
				switch(ptr[0])
				{
					case '"':
						curPtr[0]='"';
						break;
					case '\\':
						curPtr[0]='\\';
						break;
					case '/':
						curPtr[0]='/';
						break;					
					case 'b':
						curPtr[0]='\b';
						break;
					case 'f':
						curPtr[0]='\f';
						break;
					case 'n':
						curPtr[0]='\n';
						break;
					case 'r':
						curPtr[0]='\r';
						break;
					case 't':
						curPtr[0]='\t';
						break;					
					case 'u':	
						curPtr[0]='u';
						break;

					default:
						curPtr[0]='\\';	
						curPtr++;
						curPtr[0]=ptr[0];
						break;
				}
				curPtr++;
				ptr++;
			}
			else
			{
				break;
			}
		}
		else if(ptr[0]=='\"')
		{
			isGood = 1;
			ptr++;			
			break;
		}
		else 
		{
			curPtr[0] = ptr[0];
			curPtr++;
			ptr++;
		}
	}

	if(isGood)
	{
		if(top>0)	
		  curPtr[0] = 0;
		return ptr-text;
	}
	else 
	{
		ptree->errNo = 3;
		sprintf(ptree->errInfo,"ParseJsonMarkStr failed.  no match\n");
		return -2;
	}
}

int ParseJsonOtherStr(char *text, int textLen, JsonTree_t *ptree, int top)
{
	char *ptr = text;
	char *endptr = text+textLen;
	int isBreak = 0;

	while(ptr<endptr)
	{
		switch(ptr[0])
		{
			case ',':
			case '}':
			case ']':							
				isBreak=1;				
				break;
			default:
				if(isspace(ptr[0]))
				{	
					if(top>0)				
					  ptr[0]=0;
					isBreak=2;
					ptr++;

				}
				break;
		}

		if(isBreak)
		{
			break;
		}
		ptr++;
	}

	if(isBreak)
	{	
		return ptr-text;
	}
	else 
	{
		ptree->errNo = 3;
		sprintf(ptree->errInfo,"ParseJsonOtherStr failed . no stop\n");
		return -2;
	}
}


int ParseJsonValueArray(char *text, int textLen,ValueNode_t* pValueArray, JsonTree_t *ptree,  int top)
{
	int valueArrayPos = pValueArray - ptree->values;
	ValueNode_t *pNode = pValueArray;
	ValueNode_t *pPreNode = NULL;
	BranchInfo_t *curBranch;
	char *ptr = text;
	char *endptr = text+textLen;
	int isGood = 0;

	if(text[0]!='[')
	{
		ptree->errNo = 1;
		sprintf(ptree->errInfo,"ParseJsonValueArray failed .no start char . deeplevel:%d\n",ptree->curBranchNum);
		return -1;
	}

	curBranch = ptree->branchs+ptree->curBranchNum++;
	curBranch->valueType = V_VALUE_ARRAY;	
	curBranch->starti = 0;
	curBranch->startPos = valueArrayPos;

	pNode->nextPos = 0;
	pNode->startPos = -1;
	ptr++;
	while(ptr<endptr)
	{
		if(ptr[0]==']')
		{
			isGood=1;
			if(top==1)
			  ptr[0]=0;
			ptr++;
			break;
		}
		if(isspace(ptr[0]))
		{
			ptr++;
		}
		else if(ptr[0]==',')
		{

			ValueNode_t *pNewNode;
			if( pNode->startPos==-1 )
			{
				ptree->errNo = 4;
				sprintf(ptree->errInfo,"ParseJsonPairArray failed. for no value in node. deeplevel:%d\n",ptree->curBranchNum);
				return -11;
			}

			if(ptree->curValueNum>=ptree->maxValueNum)
			{
				int curNodeNum = pNode - ptree->values;
				int ret=ExpandJsonTreeValueBuffer(ptree, ptree->maxValueNum*1.5);
				if(ret<0)
				{
					return -2;
				}
				pNode = ptree->values+ curNodeNum;
			}

			pNewNode = ptree->values+ptree->curValueNum;
			pNode->nextPos =  ptree->curValueNum;			
			pPreNode = pNode;
			pNode = pNewNode;			
			pNode->nextPos = 0;
			pNode->startPos = -1;

			curBranch->starti++;			
			curBranch->startPos = ptree->curValueNum;

			ptree->curValueNum++;
			if(top==1)
			  ptr[0]=0;
			ptr++;

		}
		else if(ptr[0]=='{')
		{
			int strLen;
			PairNode_t *pNewPair;
			int curNodeNum = pNode - ptree->values;
			if( pNode->startPos!=-1 )
			{
				ptree->errNo = 4;
				sprintf(ptree->errInfo,"ParseJsonPairArray failed. has existed value . deeplevel:%d\n",ptree->curBranchNum);
				return -11;
			}

			if(ptree->curPairNum>=ptree->maxPairNum)
			{
				int ret=ExpandJsonTreePairBuffer(ptree, ptree->maxPairNum*1.5);
				if(ret<0)
				{
					return -2;
				}
			}

			pNewPair= ptree->pairs+ptree->curPairNum;

			pNode->v_type = V_PAIR_ARRAY;
			pNode->startPos = ptree->curPairNum;
			ptree->curPairNum++;

			strLen = ParseJsonPairArray(ptr,textLen-(ptr-text),pNewPair,ptree, top-1);
			if(strLen<=0)
			{
				return -3;
			}
			pNode = ptree->values+ curNodeNum;

			if(top==1)
			{
				pNode->v_type = V_VALUE_STR;
				pNode->pStr = ptr;				
			}

			ptr+=strLen;
		}
		else if(ptr[0]=='[')
		{
			int strLen;
			ValueNode_t *pNewValue;
			int curNodeNum = pNode - ptree->values;

			if( pNode->startPos!=-1 )
			{
				ptree->errNo = 4;
				sprintf(ptree->errInfo,"ParseJsonPairArray failed. has existed value . deeplevel:%d\n",ptree->curBranchNum);
				return -11;
			}

			if(ptree->curValueNum>=ptree->maxValueNum)
			{
				int ret=ExpandJsonTreeValueBuffer(ptree, ptree->maxValueNum*1.5);
				if(ret<0)
				{
					return -2;
				}
				pNode = ptree->values + curNodeNum;
			}

			pNewValue= ptree->values+ptree->curValueNum;

			pNode->v_type = V_VALUE_ARRAY;
			pNode->startPos = ptree->curValueNum;
			ptree->curValueNum++;

			strLen = ParseJsonValueArray(ptr,textLen-(ptr-text),pNewValue,ptree,top-1);
			if(strLen<=0)
			{
				return -4;
			}
			pNode = ptree->values+ curNodeNum;
			if(top==1)
			{
				pNode->v_type = V_VALUE_STR;
				pNode->pStr = ptr;				
			}

			ptr+=strLen;

		}
		else if(ptr[0]=='\"')
		{
			int strLen;
			if( pNode->startPos!=-1 )
			{
				ptree->errNo = 4;
				sprintf(ptree->errInfo,"ParseJsonPairArray failed. has existed value . deeplevel:%d\n",ptree->curBranchNum);
				return -11;
			}


			pNode->v_type = V_STR;

			strLen = ParseJsonMarkStr(ptr,textLen-(ptr-text),ptree,top);
			if(strLen<0)
			{
				return -5;
			}	
			pNode->pStr = ptr+1;	
			ptr+= strLen;
		}
		else 
		{
			int strLen;
			if( pNode->startPos!=-1 )
			{
				ptree->errNo = 4;
				sprintf(ptree->errInfo,"ParseJsonPairArray failed. has existed value . deeplevel:%d\n",ptree->curBranchNum);
				return -11;
			}


			pNode->v_type = V_VALUE_STR;
			strLen = ParseJsonOtherStr(ptr,textLen-(ptr-text),ptree,top);
			if(strLen<0)
			{
				return -6;
			}
			pNode->pStr = ptr;
			ptr+=strLen;
			if(ptr[0]==']')
			{
				if(top>0)
				  ptr[0]=0;
				ptr++;
				isGood=1;
				break;
			}
			else if(ptr[0]==',')
			{
				ValueNode_t *pNewNode;

				if(ptree->curValueNum>=ptree->maxValueNum)
				{
					int curNodeNum = pNode - ptree->values;
					int ret=ExpandJsonTreeValueBuffer(ptree, ptree->maxValueNum*1.5);
					if(ret<0)
					{
						return -2;
					}
					pNode = ptree->values + curNodeNum;
				}

				pNewNode = ptree->values+ptree->curValueNum;
				pNode->nextPos =  ptree->curValueNum;			
				pPreNode = pNode;
				pNode = pNewNode;
				pNode->nextPos = 0;
				pNode->startPos = -1;

				curBranch->starti++;			
				curBranch->startPos = ptree->curValueNum;

				ptree->curValueNum++;

				if(top>0)
				  ptr[0]=0;
				ptr++;
			}
		}
	}


	if(pNode->startPos==-1)
	{
		if(pPreNode==NULL)
		{
			/*
			   ptree->errNo = 4;
			   sprintf(ptree->errInfo,"ParseJsonPairArray failed. for no value\n");
			   return -11;*/			
		}
		else 
		{
			pPreNode->nextPos = 0;
			ptree->curValueNum-- ; 
		}
	}


	if(isGood)
	{
		ptree->curBranchNum--;

		return ptr - text;
	}
	else 
	{
		ptree->errNo = 3;
		sprintf(ptree->errInfo,"ParseJsonValueArray failed . no match\n");
		return -10;
	}
}

int ParseJsonPairArray(char *text, int textLen,PairNode_t* pPairArray, JsonTree_t *ptree, int top)
{
	int pairArrayPos;
	PairNode_t *pNode = pPairArray;
	PairNode_t *pPreNode = NULL;
	BranchInfo_t *curBranch;
	char *ptr = text;	
	char *endptr = text+textLen;
	int isGood = 0;
	int isPair = 0;
	if(text[0]!='{')
	{
		ptree->errNo = 1;
		sprintf(ptree->errInfo,"ParseJsonPairArray failed .no start char\n");
		return -1;
	}

	pairArrayPos = pPairArray - ptree->pairs;

	curBranch = ptree->branchs+ptree->curBranchNum++;
	curBranch->valueType = V_PAIR_ARRAY;
	curBranch->starti = 0;
	curBranch->startPos = pairArrayPos;

	pNode->nextPos = 0;
	pNode->keyStr = NULL;
	pNode->startPos = -1;

	ptr++;
	while(ptr<endptr)
	{
		if(ptr[0]=='}')
		{
			isGood = 1;
			if(top==1)
			  ptr[0]=0;
			ptr++;
			break;
		}

		if(isspace(ptr[0]))
		{
			ptr++;
		}
		else if(ptr[0]==':')
		{
			if(pNode->keyStr==NULL)
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for no pair key in %d\n",__LINE__);
				return -11;
			}
			isPair = 1;
			ptr++;
		}
		else if(ptr[0]==',')
		{

			PairNode_t *pNewNode;

			if((pNode->keyStr==NULL)||(pNode->startPos==-1) || (isPair==0)) 
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for no pair value;\n");
				return -11;
			}

			if(ptree->curPairNum>=ptree->maxPairNum)
			{
				int curNodeNum = pNode - ptree->pairs;
				int ret=ExpandJsonTreePairBuffer(ptree, ptree->maxPairNum*1.5);
				if(ret<0)
				{
					return -2;
				}

				pNode  = ptree->pairs + curNodeNum;	
			}

			pNewNode = ptree->pairs+ptree->curPairNum;
			pNode->nextPos =  ptree->curPairNum;			
			pPreNode = pNode;
			pNode = pNewNode;

			pNode->nextPos = 0;
			pNode->startPos = -1;
			pNode->keyStr = NULL;

			curBranch->starti++;
			curBranch->startPos = ptree->curPairNum;

			ptree->curPairNum++;
			isPair = 0;
			if(top==1)
			  ptr[0]=0;
			ptr++;

		}
		else if(ptr[0]=='{')
		{
			int strLen;
			PairNode_t *pNewPair;
			int curNodeNum = pNode - ptree->pairs;
			if(ptree->curPairNum>=ptree->maxPairNum)
			{				
				int ret=ExpandJsonTreePairBuffer(ptree, ptree->maxPairNum*1.5);
				if(ret<0)
				{
					return -2;
				}

				pNode  = ptree->pairs + curNodeNum;
			}

			pNewPair= ptree->pairs+ptree->curPairNum;

			if(pNode->keyStr==NULL)
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for no pair key in %d\n",__LINE__);
				return -11;
			}
			else if(pNode->startPos!=-1) 
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for has pair value in %d\n",__LINE__);
				return -11;
			}
			pNode->v_type = V_PAIR_ARRAY;
			pNode->startPos = ptree->curPairNum;
			ptree->curPairNum++;

			strLen = ParseJsonPairArray(ptr,textLen-(ptr-text),pNewPair,ptree, top-1);
			if(strLen<=0)
			{
				return -4;
			}

			pNode  = ptree->pairs + curNodeNum;

			if(top==1)
			{
				pNode->v_type = V_VALUE_STR;
				pNode->pStr = ptr;				
			}

			ptr+=strLen;
		}
		else if(ptr[0]=='[')
		{
			int strLen;
			ValueNode_t *pNewValue;
			int curNodeNum = pNode - ptree->pairs;
			if(ptree->curValueNum>=ptree->maxValueNum)
			{
				int ret=ExpandJsonTreeValueBuffer(ptree, ptree->maxValueNum*1.5);
				if(ret<0)
				{
					return -2;
				}
			}

			pNewValue= ptree->values+ptree->curValueNum;

			if(pNode->keyStr==NULL)
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for no pair key in %d\n",__LINE__);
				return -11;
			}
			else if(pNode->startPos!=-1) 
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for has pair value in %d\n",__LINE__);
				return -11;
			}

			pNode->v_type = V_VALUE_ARRAY;
			pNode->startPos = ptree->curValueNum;
			ptree->curValueNum++;

			strLen = ParseJsonValueArray(ptr,textLen-(ptr-text),pNewValue,ptree, top-1);
			if(strLen<=0)
			{
				return -4;
			}

			pNode  = ptree->pairs + curNodeNum;

			if(top==1)
			{
				pNode->v_type = V_VALUE_STR;
				pNode->pStr = ptr;				
			}

			ptr+=strLen;

		}
		else if(ptr[0]=='\"')
		{
			int strLen;

			strLen = ParseJsonMarkStr(ptr,textLen-(ptr-text),ptree,top);
			if(strLen<0)
			{
				return -5;
			}

			if(pNode->keyStr==NULL)
			  pNode->keyStr = ptr+1;
			else if(pNode->startPos==-1)
			{
				pNode->v_type = V_STR;
				pNode->pStr = ptr+1;
			}
			else
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for has pair value in %d\n", __LINE__);
				return -11;
			}
			ptr+= strLen;
		}
		else 
		{
			int strLen;			
			strLen = ParseJsonOtherStr(ptr,textLen-(ptr-text),ptree, top);
			if(strLen<0)
			{
				return -6;
			}

			if(pNode->keyStr==NULL)
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for no pair key in %d\n",__LINE__);
				return -11;
			}
			else if(pNode->startPos!=-1) 
			{
				ptree->errNo = 5;
				sprintf(ptree->errInfo,"ParseJsonPairArray faild; for has pair value in %d\n", __LINE__);
				return -11;
			}
			pNode->v_type = V_VALUE_STR;
			pNode->pStr = ptr;
			ptr+=strLen;
			if(ptr[0]=='}')
			{
				if(top>0)
				  ptr[0]=0;
				ptr++;
				isGood=1;
				break;
			}
			else if(ptr[0]==',')
			{
				PairNode_t *pNewNode;

				if(ptree->curPairNum>=ptree->maxPairNum)
				{
					int curNodeNum = pNode - ptree->pairs;
					int ret=ExpandJsonTreePairBuffer(ptree, ptree->maxPairNum*1.5);
					if(ret<0)
					{
						return -2;
					}

					pNode  = ptree->pairs + curNodeNum;
				}

				pNewNode = ptree->pairs+ptree->curPairNum;
				pNode->nextPos =  ptree->curPairNum;			
				pPreNode = pNode;
				pNode = pNewNode;

				pNode->nextPos = 0;
				pNode->startPos = -1;
				pNode->keyStr = NULL;

				curBranch->starti++;
				curBranch->startPos = ptree->curPairNum;

				ptree->curPairNum++;
				isPair = 0;
				if(top>0)
				  ptr[0]=0;
				ptr++;

			}
		}
	}

	if(pNode->keyStr==NULL)
	{
		if(pPreNode==NULL)
		{
			/*ptree->errNo = 5;
			  sprintf(ptree->errInfo,"ParseJsonPairArray faild; for no pair;\n");
			  return -11;*/
		}
		else
		{
			pPreNode->nextPos = 0;
			ptree->curPairNum--;
		}
	}
	else if((pNode->keyStr!=NULL)&&((pNode->startPos==-1) || (isPair==0))) 
	{
		ptree->errNo = 5;
		sprintf(ptree->errInfo,"ParseJsonPairArray faild; for no pair value;\n");
		return -11;
	}

	if(isGood)
	{
		ptree->curBranchNum--;

		return ptr - text;
	}
	else
	{
		ptree->errNo = 3;
		sprintf(ptree->errInfo,"ParseJsonPairArray failed. no match\n");
		return -10;
	}
}

int PrintBreakInfo(JsonTree_t *ptree)
{
	int i; 
	int preType = 0;
	for(i=0; i<ptree->curBranchNum; i++)
	{
		BranchInfo_t *pbranch = ptree->branchs+i;
		if(pbranch->valueType==V_PAIR_ARRAY)
		{
			PairNode_t *ppair = ptree->pairs+pbranch->startPos;
			printf("%d\t{%d}\t%s\n",i,pbranch->starti, ppair->keyStr);
		}
		else if(pbranch->valueType==V_VALUE_ARRAY)
		{
			ValueNode_t *pvalue = ptree->values+pbranch->startPos;
			printf("%d\t[%d]\n",i,pbranch->starti);
		}
		else 
		{
			ValueNode_t *pvalue = ptree->values+pbranch->startPos;
			printf("%d\t%d\n",i,pbranch->starti);
		}
		preType = pbranch->valueType==V_VALUE_ARRAY;
	}
	return 0;
}



JsonText_t *CreateJsonText(int initTextLen)
{
	JsonText_t *ptext = (JsonText_t*)malloc(sizeof(JsonText_t));
	if(ptext==NULL)
	  return NULL;
	ptext->text= (char*) malloc(initTextLen);
	if(ptext->text==NULL)
	{
		free(ptext);
		return NULL;
	}
	ptext->curLen  = 0;
	ptext->textLen = initTextLen;
	return ptext;
}

int PrintJsonMarkStr(char *str, JsonText_t *ptext);

int PrintJsonValueArray(JsonTree_t *ptree, ValueNode_t *pValueArray, JsonText_t *ptext, int deep);

int PrintJsonPairArray(JsonTree_t *ptree, PairNode_t *pPairArray, JsonText_t *ptext, int deep);

#define InsertSpace(ptr, num)\
{	int ii;\
	for(ii=0; ii<num; ii++)\
	ptr[ii]='\t';\
	ptr+=num;\
}

#define JudgeBufferSpace(ptext,curPtr,endPtr,deep)\
{	if(curPtr>=endPtr)\
	{	int curStrLen = curPtr - ptext->text;\
		int ret;\
		if(curStrLen<1000)\
		ret=ExpandJsonText(ptext,ptext->textLen*2);\
		else\
		ret=ExpandJsonText(ptext,ptext->textLen*1.5);\
		if(ret<0)\
		return -1;\
		curPtr = ptext->text+curStrLen;\
		endPtr = ptext->text + ptext->textLen-2-deep;\
	}\
}


void FreeJsonText(JsonText_t *ptext)
{
	free(ptext->text);
	free(ptext);
}

int ExpandJsonText(JsonText_t *ptext,int newTextLen)
{
	char *text = ptext->text;
	ptext->text = (char*) realloc(ptext->text, newTextLen );
	if(ptext->text==NULL)
	{
		ptext->errNo = 2;
		sprintf(ptext->errInfo,"ExpandJsonText failed . new alloc size :%d\n",newTextLen);
		ptext->text= text;
		return -1;
	}
	ptext->textLen = newTextLen;
	return 0;
}

int PrintJsonTree(JsonTree_t *ptree, JsonText_t *ptext)
{
	int strLen;
	ptext->curLen = 0;
	if(ptree->rootType==V_PAIR_ARRAY)
	{
		strLen = PrintJsonPairArray(ptree,ptree->pairs, ptext, 0);
	}
	else if(ptree->rootType==V_VALUE_ARRAY)
	{
		strLen = PrintJsonValueArray(ptree,ptree->values, ptext, 0);
	}
	else 
	{
		ptext->errNo = 1;
		sprintf(ptext->errInfo,"json type is invalid");
		return -1;
	}

	if(strLen<0)
	{
		return -1;
	}
	ptext->text[ptext->curLen] =  0;
	return 0;
}

int PrintJsonMarkStr(char *str, JsonText_t *ptext)
{
	int curLen=ptext->curLen;
	char *ptr = str;
	char *curPtr = ptext->text + ptext->curLen;
	char *endPtr = ptext->text + ptext->textLen-2;

	if(str==NULL)
	{
		ptext->errNo = 3;
		sprintf(ptext->errInfo,"PrintJsonMarkStr failed for invalid str\n");
		return -1;
	}

	JudgeBufferSpace(ptext,curPtr,endPtr, 0);

	curPtr[0]='"';
	curPtr++;

	JudgeBufferSpace(ptext,curPtr,endPtr, 0);

	while(ptr[0]!=0)
	{
		int wordLen=2;
		switch(ptr[0])
		{
			case '"':
				curPtr[0]='\\';								
				curPtr[1]='"';
				break; 
			case '\\':
				curPtr[0]='\\';								
				curPtr[1]='\\';
				break; 
			case '/':
				curPtr[0]='\\';								
				curPtr[1]='/';
				break; 
			case '\b':
				curPtr[0]='\\';								
				curPtr[1]='b';
				break; 
			case '\f':
				curPtr[0]='\\';								
				curPtr[1]='f';
				break; 
			case '\n':
				curPtr[0]='\\';								
				curPtr[1]='n';
				break; 
			case '\r':
				curPtr[0]='\\';								
				curPtr[1]='r';
				break; 
			case '\t':
				curPtr[0]='\\';								
				curPtr[1]='t';
				break; 
				/*case '\u':
				  curPtr[0]='\\';								
				  curPtr[1]='u';
				  break; 
				  */
			default:
				curPtr[0]=ptr[0];
				wordLen=1;
				break;
		}
		curPtr+=wordLen;

		JudgeBufferSpace(ptext,curPtr,endPtr, 0);

		ptr++;
	}

	curPtr[0]='"';
	curPtr++;

	ptext->curLen = curPtr-ptext->text;
	return ptext->curLen - curLen;
}

int AddPairValue(JsonText_t *ptext, char *key, char *value, VALUE_TYPE v_type)
{
	int startCurLen = ptext->curLen;
	int ret;
	if(ptext->curLen==0)
	{
		ptext->text[0] = '{';
		ptext->curLen+=1;
	}
	else 
	{
		ptext->text[ptext->curLen-1] = ',';
	}

	ret = PrintJsonMarkStr(key,ptext);
	if(ret<0)
	{
		return ret;
	}

	if(v_type!=V_STR)
	{
		int strLen = strlen(value)+3;
		if((ptext->curLen+strLen)>ptext->textLen)
		{
			ret = ExpandJsonText(ptext,ptext->textLen*1.5+strLen);
			if(ret<0)
			  return ret;
		}
		ptext->curLen += sprintf(ptext->text+ptext->curLen,":%s}",value);
	}
	else 
	{
		int strLen = strlen(value)+3;
		if((ptext->curLen+strLen)>ptext->textLen)
		{
			ret = ExpandJsonText(ptext,ptext->textLen*1.5+strLen);
			if(ret<0)
			  return ret;
		}

		ptext->text[ptext->curLen] = ':';
		ptext->curLen++;
		ret = PrintJsonMarkStr(value,ptext);
		if(ret<0)
		  return ret;

		if((ptext->curLen+2)>ptext->textLen)
		{
			ret = ExpandJsonText(ptext,ptext->textLen*1.5+2);
			if(ret<0)
			  return ret;
		}

		ptext->text[ptext->curLen] = '}';
		ptext->curLen++;
		ptext->text[ptext->curLen] = '0';
	}

	return ptext->curLen-startCurLen;
}

int AddArrayValue(JsonText_t *ptext, char *value, VALUE_TYPE v_type)
{
	int startCurLen = ptext->curLen;
	int ret;
	if(ptext->curLen==0)
	{
		ptext->text[0] = '[';
		ptext->curLen+=1;
	}
	else 
	{
		ptext->text[ptext->curLen-1] = ',';
	}

	if(v_type!=V_STR)
	{
		int strLen = strlen(value)+2;
		if((ptext->curLen+strLen)<ptext->textLen)
		{
			ret = ExpandJsonText(ptext,ptext->textLen*1.5+strLen);
			if(ret<0)
			  return ret;
		}

		ptext->curLen += sprintf(ptext->text+ptext->curLen,"%s]",value);
	}
	else 
	{
		ret = PrintJsonMarkStr(value, ptext);
		if(ret<0)
		  return ret;
		if((ptext->curLen+2)>ptext->textLen)
		{
			ret = ExpandJsonText(ptext,ptext->textLen*1.5+2);
			if(ret<0)
			  return ret;
		}
		ptext->text[ptext->curLen] = ']';
		ptext->curLen++;
		ptext->text[ptext->curLen]='0';
	}

	return ptext->curLen-startCurLen;
}


int PrintJsonValueArray(JsonTree_t *ptree, ValueNode_t *pValueArray, JsonText_t *ptext, int deep)
{
	ValueNode_t *pNode = pValueArray;
	int startCurLen=ptext->curLen;

	char *curPtr = ptext->text + ptext->curLen;
	char *endPtr = ptext->text + ptext->textLen-2-deep;

	JudgeBufferSpace(ptext,curPtr,endPtr, deep);

	curPtr[0]='[';	
	curPtr[1]='\n';
	curPtr+=2;

	JudgeBufferSpace(ptext,curPtr,endPtr, deep);
	if(pNode->startPos==-1)
	{
		pNode = NULL;
	}
	while(pNode!=NULL)
	{
		int ret;
		int textLen;

		//if(pNode!=pValueArray)
		{
			InsertSpace(curPtr,deep);		
			JudgeBufferSpace(ptext,curPtr,endPtr, deep);
		}

		textLen = ptext->textLen;
		ptext->curLen = curPtr - ptext->text;
		switch(pNode->v_type)
		{
			case V_VALUE_STR:
				{
					int strLen = strlen(pNode->pStr);
					if((curPtr+strLen)>endPtr)
					{
						ExpandJsonText(ptext,ptext->textLen*1.5+deep+strLen);
						curPtr = ptext->text + ptext->curLen;
						endPtr = ptext->text + ptext->textLen-2-deep;
					}
					memcpy(curPtr,pNode->pStr,strLen);
					ptext->curLen+=strLen;
					curPtr+=strLen;	
					JudgeBufferSpace(ptext,curPtr,endPtr, deep);
				}
				break;
			case V_STR:
				ret = PrintJsonMarkStr(pNode->pStr,ptext);
				if(ret<0)
				{
					return -2;
				}

				curPtr =  ptext->text + ptext->curLen;
				if(ptext->textLen!=textLen)
				  endPtr = ptext->text + ptext->textLen-2-deep;

				JudgeBufferSpace(ptext,curPtr,endPtr, deep);

				break;

			case V_VALUE_ARRAY:
				ret = PrintJsonValueArray(ptree,ptree->values+pNode->startPos, ptext,deep+1);
				if(ret<0)
				{
					return -2;
				}
				curPtr =  ptext->text + ptext->curLen;
				if(ptext->textLen!=textLen)
				  endPtr = ptext->text + ptext->textLen-2-deep;

				JudgeBufferSpace(ptext,curPtr,endPtr, deep);

				break;
			case V_PAIR_ARRAY:
				ret = PrintJsonPairArray(ptree,ptree->pairs+pNode->startPos, ptext,deep+1);
				if(ret<0)
				{
					return -2;
				}
				curPtr =  ptext->text + ptext->curLen;
				if(ptext->textLen!=textLen)
				  endPtr = ptext->text + ptext->textLen-2-deep;

				JudgeBufferSpace(ptext,curPtr,endPtr, deep);
				break;
			default:
				ptext->errNo = 4;
				sprintf(ptext->errInfo,"PrintJsonValueArray failed for err type, deep:%d\n",deep);
				return -2;	
		}

		if( pNode->nextPos!=0 )
		{
			curPtr[0]=',';
			curPtr[1]='\n';
			curPtr+=2;						
			JudgeBufferSpace(ptext,curPtr,endPtr, deep);
			pNode = ptree->values+pNode->nextPos;
		}
		else
		{
			curPtr[0]='\n';
			curPtr+=1;						
			JudgeBufferSpace(ptext,curPtr,endPtr, deep);
			pNode = NULL;
		}
	}

	InsertSpace(curPtr,deep);
	curPtr[0]=']';	
	curPtr+=1;
	JudgeBufferSpace(ptext,curPtr,endPtr, deep);

	ptext->curLen = curPtr-ptext->text;
	return ptext->curLen - startCurLen;
}

int PrintJsonPairArray(JsonTree_t *ptree, PairNode_t *pPairArray, JsonText_t *ptext, int deep)
{
	PairNode_t *pNode = pPairArray;
	int startCurLen=ptext->curLen;

	char *curPtr = ptext->text + ptext->curLen;
	char *endPtr = ptext->text + ptext->textLen-2-deep;

	JudgeBufferSpace(ptext,curPtr,endPtr, deep);

	curPtr[0]='{';	
	curPtr[1]='\n';	
	curPtr+=2;

	JudgeBufferSpace(ptext,curPtr,endPtr, deep);

	if(pNode->startPos==-1)
	{
		pNode = NULL;
	}

	while(pNode!=NULL)
	{
		int ret;
		int textLen;

		//if(pNode!=pPairArray)
		{
			InsertSpace(curPtr,deep);		
			JudgeBufferSpace(ptext,curPtr,endPtr, deep);
		}
		textLen = ptext->textLen;
		ptext->curLen = curPtr - ptext->text;

		ret = PrintJsonMarkStr(pNode->keyStr,ptext);
		if(ret<0)
		{
			return -2;
		}
		curPtr =  ptext->text + ptext->curLen;
		if(ptext->textLen!=textLen)
		  endPtr =  ptext->text + ptext->textLen-2-deep;

		JudgeBufferSpace(ptext,curPtr,endPtr, deep);

		curPtr[0]=' ';
		curPtr[1]=':';
		curPtr[2]=' ';
		curPtr+=3;

		JudgeBufferSpace(ptext,curPtr,endPtr, deep);

		textLen = ptext->textLen;
		ptext->curLen = curPtr - ptext->text;
		switch(pNode->v_type)
		{
			case V_VALUE_STR:
				{
					int strLen = strlen(pNode->pStr);
					if((curPtr+strLen)>endPtr)
					{
						ExpandJsonText(ptext,ptext->textLen*1.5+deep+strLen);
						curPtr = ptext->text + ptext->curLen;
						endPtr = ptext->text + ptext->textLen-2-deep;
					}
					memcpy(curPtr,pNode->pStr,strLen);
					ptext->curLen+=strLen;
					curPtr+=strLen;	
					JudgeBufferSpace(ptext,curPtr,endPtr, deep);
				}
				break;
			case V_STR:
				ret = PrintJsonMarkStr(pNode->pStr,ptext);
				if(ret<0)
				{
					return -2;
				}

				curPtr =  ptext->text + ptext->curLen;
				if(ptext->textLen!=textLen)
				  endPtr =  ptext->text + ptext->textLen-2-deep;

				JudgeBufferSpace(ptext,curPtr,endPtr, deep);

				break;

			case V_VALUE_ARRAY:
				ret = PrintJsonValueArray(ptree, ptree->values+pNode->startPos, ptext,deep+1);
				if(ret<0)
				{
					return -2;
				}

				curPtr =  ptext->text + ptext->curLen;
				if(ptext->textLen!=textLen)
				  endPtr =  ptext->text + ptext->textLen-2-deep;

				JudgeBufferSpace(ptext,curPtr,endPtr, deep);

				break;
			case V_PAIR_ARRAY:
				ret = PrintJsonPairArray(ptree, ptree->pairs+pNode->startPos, ptext,deep+1);
				if(ret<0)
				{
					return -2;
				}

				curPtr =  ptext->text + ptext->curLen;
				if(ptext->textLen!=textLen)
				  endPtr =  ptext->text + ptext->textLen-2-deep;

				JudgeBufferSpace(ptext,curPtr,endPtr, deep);
				break;
			default:
				ptext->errNo = 5;
				sprintf(ptext->errInfo,"PrintJsonPairArray failed for err type, deep:%d\n",deep);
				return -2;	
		}

		if( pNode->nextPos!=0 )
		{
			curPtr[0]=',';
			curPtr[1]='\n';
			curPtr+=2;						
			JudgeBufferSpace(ptext,curPtr,endPtr, deep);
			pNode = ptree->pairs+pNode->nextPos;
		}
		else
		{
			curPtr[0]='\n';
			curPtr+=1;						
			JudgeBufferSpace(ptext,curPtr,endPtr, deep);
			pNode = NULL;
		}
	}

	InsertSpace(curPtr,deep);
	curPtr[0]='}';	
	curPtr+=1;
	JudgeBufferSpace(ptext,curPtr,endPtr, deep);

	ptext->curLen = curPtr-ptext->text;
	return ptext->curLen - startCurLen;
}


int PackedJsonText(char *text, int textLen )
{
	char *curPtr;
	char *endPtr = text+textLen;
	char *ptr;
	int isStr=0;
	curPtr= text; 
	ptr= text;
	while(ptr<endPtr)
	{
		if(isStr)
		{
			curPtr[0]=ptr[0];
			curPtr++;
			if(ptr[0]=='\\')
			{
				ptr++;
				curPtr[0]=ptr[0];
				curPtr++;

				ptr++;
			}
			else if (ptr[0]=='"')
			{
				ptr++;
				isStr = 0;				
			}
			else 
			  ptr++;

		}
		else if(isspace(ptr[0]))
		{
			ptr++;
		}
		else
		{
			if(ptr[0]=='"')
			{
				isStr=1;
			}
			curPtr[0]=ptr[0];
			curPtr++;
			ptr++;
		}
	}
	if(curPtr<endPtr)
	  curPtr[0]=0;
	return 0;
}

#ifdef TEST
int main(int argc, char** argv)
{
	JsonText_t *ptext; 
	JsonTree_t *ptree;
	char buffer[10240];
	FILE *fp;
	if(argc!=4)
	{
		printf("%s jsonfile top num\n",argv[0]);
		return 0;
	}

	int top = atoi(argv[2]);
	int num = atoi(argv[3]);
	fp = fopen(argv[1],"r");
	int bufferLen = fread(buffer,1, 10240, fp);

	int i;
	for(i=0; i<num; i++)
	{
		char * newbuffer=malloc(bufferLen);
		memcpy(newbuffer, buffer, bufferLen);

		ptree = CreateJsonTree();
		ptext= CreateJsonText(1);
		int ret=ParseJsonTop(newbuffer, bufferLen, ptree,top);
		if(i==0)
		  printf("ParseJson ret:%d . valueNum:%d-%d pairNum:%d-%d\n",ret,ptree->curValueNum, ptree->maxValueNum, ptree->curPairNum,ptree->maxPairNum);
		if(ret<0)
		{
			printf("errNo:%d\nerrInfo:%s\n",ptree->errNo,ptree->errInfo);
			PrintBreakInfo(ptree);
			return -1;
		}

		ret = PrintJsonTree(ptree, ptext);
		if(i==0)
		  printf("PrintJsonTree ret:%d textLen:%d-%d\n",ret, ptext->curLen, ptext->textLen);
		if(ret<0)
		{
			return -2;
		}
		if(i==0)
		{
			printf("%s\n",ptext->text);
			PackedJsonText(ptext->text,ptext->curLen);
			printf("\n-----PackedJsonText------\n%s\n",ptext->text);
		}	
		FreeJsonText(ptext);
		FreeJsonTree(ptree);
		free(newbuffer);
	}
	fclose(fp);
	return 0;
}


#endif

#ifdef GEN_TEXT

int main(int argc, char** argv)
{

	char *delivers[]=
	{	"DeliverID",//0
		"CompaignID",
		"CreativeID",//2
		"Status",
		"StartTime",//4
		"EndTime",
		"Weight",//6
		"AlText",
		"ClickThroughUrl",//8
		"DeliverType",
		"CountGuaranteed",//10
		"CountDelivered",
		"CountClicked",//12
		"DeliverBy",
		"WeekDays",//14
		"Hours",
		"MaxImpPerClient",//16
		"ImpIntervalPerClient",
		"KeyWords",//18
		"ParseInfo",
		"sectionID"//20
	};

	if( argc!=3 )
	{
		printf("%s startid num\n",argv[0]);
		return 0;
	}

	int startid = atoi(argv[1]);
	int num = atoi(argv[2]);

	int i;
	srand(time());
	for(i=0; i<num; i++)
	{
		char key[100];
		char value[100];
		int j,knum;
		JsonText_t *ptext= CreateJsonText(1000); 		
		JsonText_t *keys = CreateJsonText(100);  		 
		JsonText_t *ParseInfo= CreateJsonText(500); 

		knum=rand()%10;
		if(knum>0)
		{
			for(j=0; j<knum; j++)
			{
				sprintf(key,"k-%d",rand()%10000);
				sprintf(value,"%d",(i+1)*(j+1)%1000);
				AddPairValue(keys,key,value,V_VALUE_STR);
			}
			AddPairValue(ParseInfo,"pagekeys",keys->text,V_VALUE_STR);
		}

		knum=rand()%10;
		if(knum>0)
		{
			keys->curLen = 0;
			for(j=0; j<knum; j++)
			{
				sprintf(key,"k-%d",rand()%10000);
				sprintf(value,"%d",(i+1)*(j+1)%1000);
				AddPairValue(keys,key,value,V_VALUE_STR);
			}			
			AddPairValue(ParseInfo,"extendkeys",keys->text,V_VALUE_STR);

		}

		knum=rand()%10;
		if(knum>0)
		{
			keys->curLen = 0;
			for(j=0; j<knum; j++)
			{
				sprintf(key,"t-%d",rand()%1000);
				sprintf(value,"%d",(i+1)*(j+1)%1000);
				AddPairValue(keys,key,value,V_VALUE_STR);
			}
			AddPairValue(ParseInfo,"typekeys",keys->text,V_VALUE_STR);
		}

		sprintf(value,"%d",rand());
		AddPairValue(ParseInfo,"attr",value,V_VALUE_STR);

		sprintf(value,"%d",startid+i);
		AddPairValue(ptext,delivers[0],value,V_VALUE_STR);	

		sprintf(value,"%d",rand()%100);
		AddPairValue(ptext,delivers[1],value,V_VALUE_STR);

		sprintf(value,"%d",rand()%10);
		AddPairValue(ptext,delivers[20],value,V_VALUE_STR);

		sprintf(value,"%d",rand()%100000);
		AddPairValue(ptext,delivers[2],value,V_VALUE_STR);

		sprintf(value,"%d",rand()%5);
		AddPairValue(ptext,delivers[3],value,V_VALUE_STR);

		int curTime=time()-(rand()%1000000)+300000;

		sprintf(value,"%u",curTime);
		AddPairValue(ptext,delivers[4],value,V_VALUE_STR);
		sprintf(value,"%u",curTime+(rand()%2000000));
		AddPairValue(ptext,delivers[5],value,V_VALUE_STR);

		sprintf(value,"%u",rand()%10);
		AddPairValue(ptext,delivers[6],value,V_VALUE_STR);

		sprintf(value,"alt %d %d",i,rand());
		AddPairValue(ptext,delivers[7],value,V_STR);

		sprintf(value,"url %d %d",i,rand());
		AddPairValue(ptext,delivers[8],value,V_STR);

		sprintf(value,"%d",rand()%3);
		AddPairValue(ptext,delivers[9],value,V_VALUE_STR);

		int totalNum = (rand()%100000)+100;
		sprintf(value,"%d",totalNum);
		AddPairValue(ptext,delivers[10],value,V_VALUE_STR);

		totalNum = rand()%totalNum;
		sprintf(value,"%d",totalNum);
		AddPairValue(ptext,delivers[11],value,V_VALUE_STR);

		if(totalNum>0)
		  totalNum = rand()%totalNum;
		sprintf(value,"%d",totalNum);
		AddPairValue(ptext,delivers[12],value,V_VALUE_STR);

		sprintf(value,"%d",rand()%4);
		AddPairValue(ptext,delivers[13],value,V_VALUE_STR);

		sprintf(value,"%d",rand()%128);
		AddPairValue(ptext,delivers[14],value,V_VALUE_STR);

		sprintf(value,"%d",rand()%0xffffff);
		AddPairValue(ptext,delivers[15],value,V_VALUE_STR);

		sprintf(value,"%d",(rand()%0xffff) +1000);
		AddPairValue(ptext,delivers[16],value,V_VALUE_STR);

		sprintf(value,"%d",1+(rand()%100));
		AddPairValue(ptext,delivers[17],value,V_VALUE_STR);

		sprintf(value,"key %d %d",i,rand());
		AddPairValue(ptext,delivers[18],value,V_STR);

		AddPairValue(ptext,delivers[19],ParseInfo->text,V_VALUE_STR);

		printf("%s\n",ptext->text);

		FreeJsonText(ptext);
		FreeJsonText(keys);
		FreeJsonText(ParseInfo);
	}
}
#endif

#ifdef GEN_QUERY
int main(int argc, char** argv)
{		
	if( argc!=2 )
	{
		printf("%s num\n",argv[0]);
		return 0;
	}

	int num = atoi(argv[1]);
	int i;
	srand(time());
	for(i=0; i<num; i++)
	{
		char key[100];
		char value[100];
		int j,knum;
		JsonText_t *ptext= CreateJsonText(1000);
		JsonText_t *pageinfo= CreateJsonText(500); 
		JsonText_t *sectioninfo= CreateJsonText(500); 
		JsonText_t *headinfo= CreateJsonText(500); 


		AddPairValue(headinfo,"num","1",V_VALUE_STR);
		AddPairValue(ptext,"head",headinfo->text,V_VALUE_STR);	

		sprintf(value,"%d",rand()%10);
		AddPairValue(sectioninfo,"sectionid",value,V_VALUE_STR);
		AddPairValue(ptext,"section",sectioninfo->text,V_VALUE_STR);

		knum=1+(rand()%10);

		for(j=0; j<knum; j++)
		{
			sprintf(key,"k-%d",rand()%10000);
			sprintf(value,"%d",(i+1)*(j+1)%1000);
			AddPairValue(pageinfo,key,value,V_VALUE_STR);
		}
		AddPairValue(ptext,"pageinfo",pageinfo->text,V_VALUE_STR);

		printf("%s\n",ptext->text);		
		FreeJsonText(ptext);
		FreeJsonText(pageinfo);

		FreeJsonText(sectioninfo);
		FreeJsonText(headinfo);
	}
}
#endif 
