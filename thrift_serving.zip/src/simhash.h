/*
 * @file : simhash.h
 *
 * @author : liubo9@staff.sina.com.cn
 *
 * @data : 2014-05-21
 *
 */
#ifndef SIM_HASH_H_
#define SIM_HASH_H_

#include <vector>
#include <memory.h>
#include <string>
#include <iostream>
#include <fstream>
#include <map>
#include "tokenizer.h"
#include "wordfilter.h"
#include "jenkins.h"
using namespace std;
using namespace weibo::tokenizer;

#define tesbit(x,y) x&(1<<y)  //����x�ĵ�YλΪ1
#define chabit(x,y) x^=(1<<y) //�ı�X�ĵ�Yλ

#ifdef __cplusplus
extern "C"
{
#endif
	struct wordItem
	{
		string word;//��
		POS_TAG_TYPE pid;//����
		double weight;//��Ҫ��
		int tf;//��Ƶ
		int wordLen;//����
		bool isErase;//������־
	};
	//ѡ�����
	int chooseword(SegResult* pSegResult,string &norCnt,vector<wordItem> &wordVec);
	//�ı���ϣ
	int texthash(SegResult* pSegResult,int nMinCnt,unsigned long long &textKey);
    
	map<long,string>* InitSource(const char* file);

#ifdef __cplusplus
}
#endif


#endif//SIM_HASH_H_
