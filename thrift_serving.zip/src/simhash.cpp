#include "simhash.h"

//ѡ�����
int chooseword(SegResult* pSegResult,string &norCnt,vector<wordItem> &wordVec)
{
	if(NULL == pSegResult)
	  return -1;
	Token* cur = pSegResult->FirstToken();
	wordItem xx;
	while(cur != NULL)
	{
		xx.word = string(cur->pWord,cur->byteLength);
		xx.pid = cur->posTagId;
		xx.weight = cur->weight;
		xx.wordLen = cur->byteLength;
		xx.isErase =false;
		cur = cur->pNext;
//		cerr<<xx.word<<":"<<()xx.pid<<endl;
		if(POSFilter_Cate((uint8_t)xx.pid))
		  continue;
		wordVec.push_back(xx);
		norCnt += xx.word;
	}
	return 0;
}

//�ı���ϣ
int texthash(SegResult* pSegResult,int nMinCnt,unsigned long long &textKey)
{
	if(NULL == pSegResult)
	  return -1;
	unsigned int key = 0;
	int bucket[32];
	memset(bucket,0,32*sizeof(int));
	string standard = "";
	vector<wordItem> wordvec;
	int iret = chooseword(pSegResult,standard,wordvec);
    if(standard.length() <= nMinCnt)
	{
		textKey = 0;
#ifdef DEBUG
		cerr<<"content is too short and return"<<endl;
#endif
		return 0;
	}
	int wordnum = wordvec.size();//��ʼ������
	for(int i = wordnum-1; i >= 0;i--)
	{
		if(wordvec[i].wordLen == 1)
		  wordvec[i].isErase = true;
		else
		  break;
	}
	for(int i=0;i<wordnum;i++)
	{
		if(wordvec[i].isErase == true)
		  continue;
		key=jenkins_hash(wordvec[i].word.c_str(),wordvec[i].wordLen,0);
#ifdef DEBUG
		        cerr<<wordvec[i].word<<":"<<key<<endl;
#endif

		for(int j=0; j<32; j++)
		{
			if(tesbit(key,j))
			  bucket[j]++;
			else
			  bucket[j]--;
		}
	}
	unsigned long long tmpkey=1;
	textKey = 0;
	for(int j=0; j<32; j++)
	{
		if(bucket[j]>0)
		{
			tmpkey=1;
			tmpkey=tmpkey << j;
			textKey=textKey | tmpkey;
		}
	}
#ifdef DEBUG
	cerr<<textKey<<endl;
#endif
	return 0;
}

map<long,string>* InitSource(const char* file)
{
	map<long,string>* source = new map<long,string>;
	ifstream fin(file);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<file<<endl;
		return NULL;
	}
	string line;
	map<long,string>::iterator it;
	while(getline(fin,line))
	{
		if(line.size() < 2)
		  continue;
		if(line[0] == '#')
		  continue;
		int pos = line.find(":");
		string id = line.substr(0,pos);
		string name = line.substr(pos+1,line.size() - pos -1);
		long source_id = atol(id.c_str());
		it = source->find(source_id);
		cerr<<source_id<<endl;
		cerr<<name<<endl;
		if(it == source->end())
		  source->insert(map<long,string>::value_type(source_id,name));
	}
	fin.close();
	if(source->size() <1)
	{
		cerr<<"source init failed!"<<endl;
		return NULL;
	}
	return source;
}
