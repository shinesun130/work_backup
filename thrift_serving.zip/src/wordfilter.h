/*
 * @file: wordfilter.h
 * @author: liubo9@staff.sina.com.cn
 */
#ifndef _WORD_FILTER_H_
#define _WORD_FILTER_H_

#include "tokenizer_define.h"
using namespace weibo::tokenizer;

#ifdef __cplusplus
extern "C"
{
#endif

//filter words acording postag
bool POSFilter_Cate(POS_TAG_TYPE nPos);

#ifdef __cplusplus
}
#endif

#endif//_WORD_FILTER_H_



