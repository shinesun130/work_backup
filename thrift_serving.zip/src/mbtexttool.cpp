#include "mbtexttool.h"
/*********************************
* ���캯������������
*********************************/

map<unsigned short,unsigned short> CMBTool::m_Complex2Simple;
map<unsigned short,unsigned short> CMBTool::m_AbnormalNum;
map<unsigned short,string> CMBTool::m_Hanzi2Pinyin;
map<unsigned short,int> CMBTool::m_OddChar;
map<unsigned short,int> CMBTool::m_Punction;
map<unsigned short,int> CMBTool::m_JapChar;
map<unsigned short,int> CMBTool::m_ChiChar;
map<string,int> CMBTool::m_ContactTag;
map<string,int> CMBTool::m_NickNameEndTag;
map<string,int> CMBTool::m_UrlStartTag;
map<string,int> CMBTool::m_Emotion;


CMBTool::CMBTool()
{
}

CMBTool::~CMBTool()
{
}

/*******************************
 * �����ӿڲ���
 ******************************/

bool CMBTool::InitTool(const char* sPath)
{
	if("" == sPath)
	  return false;
	char file[1024];
	bool res = true;
	sprintf(file,"%s/%s",sPath,"emotion.rsc");
	res = LoadEmotion(file);
	sprintf(file,"%s/%s",sPath,"urlstart.rsc");
	res  = (res && LoadUrlStartTag(file));
	sprintf(file,"%s/%s",sPath,"nickend.rsc");
	res = (res&& LoadNickNameEndTag(file));
	sprintf(file,"%s/%s",sPath,"comp2simp.rsc");
	res = (res && LoadComplex2Simple(file));
	sprintf(file,"%s/%s",sPath,"oddchars.rsc");
	res = (res && LoadOddChar(file));
	sprintf(file,"%s/%s",sPath,"ch2dig.rsc");
	res = (res && LoadAbnormalNum(file));
	sprintf(file,"%s/%s",sPath,"ch2py.rsc");
	res = (res && LoadHanzi2Pinyin(file));
	sprintf(file,"%s/%s",sPath,"punction.rsc");
	res = (res && LoadPunction(file));
	sprintf(file,"%s/%s",sPath,"contact.rsc");
	res = (res && LoadContactTag(file));
	sprintf(file,"%s/%s",sPath,"simplechar.rsc");
	res = (res && LoadChiChar(file));
	return res;
}

int CMBTool::KillEmotion(string& sContent)
{
	int slen = sContent.size();
	char text[slen+1];
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	strcpy(text,sContent.c_str());
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -1;
	char tmp[2];
	unsigned short space = (unsigned short)' ';
	unsigned short left = (unsigned short)'[';
	unsigned short right = (unsigned short)']';
	bool emotion_flag = false;
	int  start_index = -1,end_index = 0;
	vector<pair<int,int> > posinfo;
	string curword = "";
	for(int i = 0;i< ulen;i++)
	{
		if(emotion_flag)
		{
			if(uni[i] == right)
			{
				end_index = i;
				if(end_index - start_index > 0 && end_index - start_index < 8)
				{
					string emotion = UnicodeToStr(uni+start_index,end_index-start_index+1);
					if(m_Emotion.find(emotion) != m_Emotion.end())
					{
						posinfo.push_back(make_pair(start_index,end_index));
					}
				}
				end_index = start_index = 0;
				emotion_flag = false;
			}
		}
		if(uni[i] == left)
		{
			emotion_flag = true;
			start_index = i;
			continue;
		}
	}
	int rnum = posinfo.size();
	if(rnum < 1)
	  return 0;
	for(int i = 0;i < posinfo.size();i++)
	{
		for(int j = posinfo[i].first;j <= posinfo[i].second;j++){
			uni[j] = space;
		}
	}
	char out[slen*2];
	tlen = uniToBytes(uni,ulen,out,slen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	sContent = string(out);
	return posinfo.size();
}

int CMBTool::KillEmotion(string& sContent,map<string,int>& emotionMap)
{
	int slen = sContent.size();
	char text[slen+1];
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	strcpy(text,sContent.c_str());
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -1;
	char tmp[2];
	unsigned short space = (unsigned short)' ';
	unsigned short left = (unsigned short)'[';
	unsigned short right = (unsigned short)']';
	bool emotion_flag = false;
	int  start_index = -1,end_index = 0;
	vector<pair<int,int> > posinfo;
	string curword = "";
	for(int i = 0;i< ulen;i++)
	{
		if(emotion_flag)
		{
			if(uni[i] == right)
			{
				end_index = i;
				if(end_index - start_index > 0 && end_index - start_index < 8)
				{
					string emotion = UnicodeToStr(uni+start_index,end_index-start_index+1);
					if(m_Emotion.find(emotion) != m_Emotion.end())
					{
						posinfo.push_back(make_pair(start_index,end_index));
						emotionMap.insert(map<string,int>::value_type(emotion,1));
					}
				}
				end_index = start_index = 0;
				emotion_flag = false;
			}
		}
		if(uni[i] == left)
		{
			emotion_flag = true;
			start_index = i;
			continue;
		}
	}
	int rnum = posinfo.size();
	if(rnum < 1)
	  return 0;
	for(int i = 0;i < posinfo.size();i++)
	{
		for(int j = posinfo[i].first;j <= posinfo[i].second;j++){
			uni[j] = space;
		}
	}
	char out[slen*2];
	tlen = uniToBytes(uni,ulen,out,slen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	sContent = string(out);
	return posinfo.size();
}

int CMBTool::KillNickName(string& sContent)
{
	int slen = sContent.size();
	char text[slen+1];
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	strcpy(text,sContent.c_str());
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -1;
	unsigned short space = (unsigned short)' ';
	unsigned short at = (unsigned short)'@';
	bool at_flag = false;
	int  start_index = 0,end_index = 0;
	vector<pair<int,int> > posinfo;
	string curword = "";
	for(int i = 0;i< ulen;i++)
	{
		if(at_flag)
		{
			curword = UnicodeToStr(uni[i]);
			if(m_NickNameEndTag.find(curword) != m_NickNameEndTag.end())
			{
				end_index = i;
				at_flag = false;
				if(end_index - start_index > 1 && end_index - start_index < 20)
				{
					posinfo.push_back(make_pair(start_index,end_index));
					start_index = end_index = 0;
				}
			}
			if(i == ulen -1 &&m_NickNameEndTag.find(curword) != m_NickNameEndTag.end())
			{
				end_index = i + 1;
				if(end_index - start_index > 1 && end_index - start_index < 20)
				{
					posinfo.push_back(make_pair(start_index,end_index));
				}
			}
		}
		if(uni[i] == at)
		{
			at_flag = true;
			start_index = i;
		}
	}
	int rnum = posinfo.size();
	if(rnum < 1)
	  return 0;
	for(int i = 0;i < posinfo.size();i++)
	{
		for(int j = posinfo[i].first;j < posinfo[i].second;j++){
			uni[j] = space;
		}
	}
	char out[slen*2+1];
	tlen = uniToBytes(uni,ulen,out,slen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	sContent = string(out);
	return posinfo.size();
}
int CMBTool::KillNickName(string& sContent,map<string,int>& nickMap)
{
	int slen = sContent.size();
	char text[slen+1];
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	strcpy(text,sContent.c_str());
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -1;
	unsigned short space = (unsigned short)' ';
	unsigned short at = (unsigned short)'@';
	bool at_flag = false;
	int  start_index = 0,end_index = 0;
	vector<pair<int,int> > posinfo;
	string curword = "";
	for(int i = 0;i< ulen;i++)
	{
		if(at_flag)
		{
			curword = UnicodeToStr(uni[i]);
			if(m_NickNameEndTag.find(curword) != m_NickNameEndTag.end())
			{
				end_index = i;
				at_flag = false;
				if(end_index - start_index > 1 && end_index - start_index < 20)
				{
					string nickname = UnicodeToStr(uni+start_index, end_index - start_index+1);
					nickMap.insert(map<string,int>::value_type(nickname,1));
					posinfo.push_back(make_pair(start_index,end_index));
					start_index = end_index = 0;
				}
			}
			if(i == ulen -1 &&m_NickNameEndTag.find(curword) != m_NickNameEndTag.end())
			{
				end_index = i + 1;
				if(end_index - start_index > 1 && end_index - start_index < 20)
				{
					string nickname = UnicodeToStr(uni+start_index, end_index - start_index + 1);
					nickMap.insert(map<string,int>::value_type(nickname,1));
					posinfo.push_back(make_pair(start_index,end_index));
				}
			}
		}
		if(uni[i] == at)
		{
			at_flag = true;
			start_index = i;
		}
	}
	int rnum = posinfo.size();
	if(rnum < 1)
	  return 0;
	for(int i = 0;i < posinfo.size();i++)
	{
		for(int j = posinfo[i].first;j < posinfo[i].second;j++){
			uni[j] = space;
		}
	}
	char out[slen*2 + 1];
	tlen = uniToBytes(uni,ulen,out,slen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	sContent = string(out);
	return posinfo.size();
}

int CMBTool::KillUrl(string& sContent)
{
	int slen = sContent.size();
	char text[slen+1];
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	strcpy(text,sContent.c_str());
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -1;
	unsigned short space = (unsigned short)' ';
	bool url_flag = false;
	int  start_index = 0,end_index = 0;
	string preword1 = "",preword2 = "",preword3= "",curword ="";
	string urlword1 = "", urlword2 = "";
	vector<pair<int,int> > posinfo;
	for(int i = 0;i< ulen;i++)
	{
		if(url_flag)
		{
			curword = UnicodeToStr(uni[i]);
			if(m_UrlStartTag.find(curword) == m_UrlStartTag.end())
			{
				end_index = i - 1;
				if(end_index - start_index > 6)
				{
					posinfo.push_back(make_pair(start_index,end_index+1));
				}
				start_index = end_index = 0;
				url_flag = false;
				preword1 = preword2 = preword3 = "";
			}
			if(m_UrlStartTag.find(curword) != m_UrlStartTag.end() && i == ulen - 1)
			{
				end_index = i;
				if(end_index - start_index > 6)
				{
					posinfo.push_back(make_pair(start_index,end_index+1));
				}
			}
		}
		if(!url_flag)
		{
			curword = UnicodeToStr(uni[i]);
			urlword1 = preword1 + preword2 + preword3 + curword;
			urlword2 = preword2 + preword3 + curword;
			preword1 = preword2;
			preword2 = preword3;
			preword3 = curword;
			if(urlword1 == "http")
			{
				start_index = i - 3;
				url_flag = true;
				continue;
			}
			if(urlword2 == "www")
			{
				start_index = i - 2;
				url_flag = true;
				continue;
			}
		}
	}
	int rnum = posinfo.size();
	if(rnum < 1)
	  return 0;
	for(int i = 0;i < rnum;i++)
	{
		for(int j = posinfo[i].first;j < posinfo[i].second;j++){
			uni[j] = space;
		}
	}
	char out[slen*2+1];
	tlen = uniToBytes(uni,ulen,out,slen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	sContent = string(out);
	return posinfo.size();
}


int CMBTool::KillUrl(string& sContent,map<string,int>& urlMap)
{
	int slen = sContent.size();
	char text[slen+1];
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	strcpy(text,sContent.c_str());
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -1;
	unsigned short space = (unsigned short)' ';
	bool url_flag = false;
	int  start_index = 0,end_index = 0;
	string preword1 = "",preword2 = "",preword3= "",curword ="";
	string urlword1 = "", urlword2 = "";
	vector<pair<int,int> > posinfo;
	urlMap.clear();
	for(int i = 0;i< ulen;i++)
	{
		if(url_flag)
		{
			curword = UnicodeToStr(uni[i]);
			if(m_UrlStartTag.find(curword) != m_UrlStartTag.end() && i == ulen - 1)
			{
				end_index = i;
				if(end_index - start_index > 6)
				{
					string url = UnicodeToStr(uni+start_index,end_index-start_index+1);
					urlMap.insert(map<string,int>::value_type(url,1));
					posinfo.push_back(make_pair(start_index,end_index+1));
				}
			}
			if(m_UrlStartTag.find(curword) == m_UrlStartTag.end())
			{
				end_index = i-1;
				if(end_index - start_index > 6)
				{
					string url = UnicodeToStr(uni+start_index,end_index-start_index+1);
					urlMap.insert(map<string,int>::value_type(url,1));
					posinfo.push_back(make_pair(start_index,end_index+1));
				}
				start_index = end_index = 0;
				url_flag = false;
				preword1 = preword2 = preword3 = "";
			}
		}
		if(!url_flag)
		{
			curword = UnicodeToStr(uni[i]);
			urlword1 = preword1 + preword2 + preword3 + curword;
			urlword2 = preword2 + preword3 + curword;
			preword1 = preword2;
			preword2 = preword3;
			preword3 = curword;
			if(urlword1 == "http")
			{
				start_index = i - 3;
				url_flag = true;
				continue;
			}
			if(urlword2 == "www")
			{
				start_index = i - 2;
				url_flag = true;
				continue;
			}
		}
	}
	int rnum = posinfo.size();
	if(rnum < 1)
	  return 0;
	for(int i = 0;i < rnum;i++)
	{
		for(int j = posinfo[i].first;j < posinfo[i].second;j++){
			uni[j] = space;
		}
	}
	char out[slen*2+1];
	tlen = uniToBytes(uni,ulen,out,slen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	sContent = string(out);
	return posinfo.size();
}

int CMBTool::Complex2Simple(string& sContent)
{
	if(sContent.size() < 1)
	  return -1;
	int slen = sContent.size();
	char text[65535] = "",out[65535] = "";
	int transNum = 0;
	unsigned short uni[65535];
	strcpy(text,sContent.c_str());
	int ulen = 0,tlen = 0;
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -2;
	for(int i=0;i<ulen;i++)
	{
		if(m_Complex2Simple.find(uni[i]) != m_Complex2Simple.end())
		{
			uni[i] = m_Complex2Simple[uni[i]];
			string word = UnicodeToStr(uni[i]);
			transNum++;
		}
	}
	tlen = uniToBytes(uni,ulen,out,ulen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	sContent = string(out);
	return transNum;
}


string CMBTool::Hanzi2Pinyin(string& sContent,bool flag)
{
	if(sContent.size() < 1)
	  return "";
	int slen = sContent.size();
	char text[slen];
	strcpy(text,sContent.c_str());
	int olen = slen + 1;
	unsigned short uni[slen+1];
	int ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return "";
	string res = "";
	map<unsigned short,string>::iterator it;
	for(int i=0;i<ulen;i++)
	{
		it = m_Hanzi2Pinyin.find(uni[i]);
		if(it != m_Hanzi2Pinyin.end())
		{
			res += it->second;
			res +="|";
		}
		else
		{
			if(flag)
			{
				if(m_Punction.find(uni[i]) != m_Punction.end())
				  continue;
				string word = "";
				if((uni[i] >= 65)&&(uni[i] <= 90))
				  word = UnicodeToStr(uni[i] + 32);
				else
				  word = UnicodeToStr(uni[i]);
				res += word;
				res +="|";
			}
		}
	}
	return res;
}


int CMBTool::NormalizeText(string& sContent,int flag)
{
	if(sContent.size() < 1)
	  return -1;
	int slen = sContent.size();
	char text[slen];
	int olen = slen +1;
	char out[olen];
	strcpy(text,sContent.c_str());
	if(normalize_str(text,slen,out,olen,flag) > 0)
	{
		sContent = string(out);
		return slen;
	}
	return -1;
}


int CMBTool::NormalizeTextMBText(string& sContent,TextInfo& info)
{
	int slen = sContent.size();
	char text[slen+1];
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	strncpy(text,sContent.c_str(),slen);
	text[slen+1] = '\0';
	ulen = bytesToUni(text,slen,uni,slen+1,"UTF-8");
	if(ulen <= 0)
	  return -1;
	unsigned short space = (unsigned short)' ';
	int front_type = 0;
	unsigned short contact[1000];
	bool contact_trig = false,contact_flag = false;
	int  num_index = 0,distance = 0;
	int contact_start = -1;
	//�������ֽṹ�������������֡���ʼλ�á�����
	map<string,ContactInfo> contact_num;
	info.Clear();
	for(int i = 0;i< ulen;i++)
	{
		if(distance > 0 || i == ulen -1)
		{
			if(contact_trig && i == ulen -1){
				if((uni[i] >= 48)&&(uni[i] <= 57)){
					contact[num_index++] = uni[i];
					info.digital_num++;
				}
				if(m_AbnormalNum.find(uni[i]) != m_AbnormalNum.end()){
					uni[i] = m_AbnormalNum[uni[i]];
					contact[num_index++] = uni[i];
					info.digital_num++;
				}
			}
			if(num_index > 4){
				int clen = num_index * 2 + 1;
				char lxfs[clen];
				int t = uniToBytes(contact,num_index,lxfs,clen,"UTF-8");
				if(t > 0)
				{
					lxfs[t] = '\0';
					ContactInfo cinfo;
					cinfo.start = contact_start;
					cinfo.len = num_index;
					cinfo.flag = contact_flag;
					contact_num.insert(map<string,ContactInfo>::value_type(string(lxfs),cinfo));
				}
			}
			distance = 0;
			num_index = 0;
			contact_trig = false;
			contact_start = -1;
			contact_flag = false;
		}
		//���
		if(m_Punction.find(uni[i]) != m_Punction.end())
		{
			if(m_Punction[uni[i]] == 3){
				uni[i] = space;
				info.punct_num++;
			}
			continue;

		}
		//����
		if((uni[i] >= 48)&&(uni[i] <= 57)){
			if(!contact_trig){
				contact_trig = true;
				contact_start = i;
			}
			if(contact_trig){
				contact[num_index++] = uni[i];
				info.digital_num++;
			}
			continue;
		}
		//��������
		if(m_AbnormalNum.find(uni[i]) != m_AbnormalNum.end()){
			uni[i] = m_AbnormalNum[uni[i]];
			info.digital_num++;
			if(!contact_trig){
				contact_flag = true;
				contact_trig = true;
				contact_start = i;
			}
			if(contact_trig){
				contact[num_index++] = uni[i];
				info.digital_num++;
			}
			continue;
		}
		//��ĸ
		if((uni[i] >= 65)&&(uni[i] <= 90)){
			uni[i] += 32;
			info.en_num++;
			if(contact_trig)
			  distance++;
			continue;
		}
		//���庺��
		if(m_Complex2Simple.find(uni[i]) != m_Complex2Simple.end()){
			uni[i] = m_Complex2Simple[uni[i]];
			info.complex_cn++;
			if(contact_trig)
			  distance++;
			continue;
		}
		//�����ַ�
		if(m_OddChar.find(uni[i]) != m_OddChar.end()){
			uni[i] = space;
			info.odd_char++;
			continue;
		}
		//����
		if(m_JapChar.find(uni[i]) != m_JapChar.end())
		{
			uni[i] = space;
			info.jap_num++;
			continue;
		}
		//���庺��
		if(m_ChiChar.find(uni[i]) != m_ChiChar.end())
		{
			info.cn_char++;
			if(contact_trig)
			  distance++;
			continue;
		}
		if(uni[i] == space)
		{
			info.space_num++;
			continue;
		}
	}
	//��ϵ��ʽ�ж�
	if(contact_num.size() > 0)
	{
		map<string,ContactInfo>::iterator it;
		bool flag = false;
		string lastword = "",curword = "";int num = 0;
		for(it = contact_num.begin();it != contact_num.end() && !flag ;it++){
			//��ϵ������ǰ���
			for(int i = it->second.start-1; i >= 0 && num < 8;i--){
				curword = UnicodeToStr(uni[i]);
				if(m_ContactTag.find(curword+lastword) != m_ContactTag.end() 
							||m_ContactTag.find(curword) != m_ContactTag.end() ){
					flag = true;
					break;
				}
				lastword = curword;
				num++;
			}
			//��ϵ��ʽ�����
			if(!flag){
				lastword = "",curword = "";
				num = 0;
				for(int i = it->second.start+it->second.len;num < 5 && i < ulen;i++){
					curword = UnicodeToStr(uni[i]);
					if(m_ContactTag.find(lastword+curword) != m_ContactTag.end()
								|| m_ContactTag.find(curword) != m_ContactTag.end() ){
						flag = true;
						break;
					}
					lastword = curword;
					num++;
				}
			}
			if(flag){
				if(it->second.flag)
				  info.abnormal_contact++;
				else
				  info.normal_contact++;
			}
			else
			{
				if(it->second.flag)
				  info.sus_abnormal_contact++;
				else
				  info.sus_normal_contact++;
			}
		}
	}
	/*	cout<<"abnormal_contact:"<<info.abnormal_contact<<endl;
		cout<<"normal_contact:"<<info.normal_contact<<endl;
		cout<<"sus_abcontact:"<<info.sus_abnormal_contact<<endl;
		cout<<"sus_norcontact:"<<info.sus_normal_contact<<endl;*/
	char out[slen*2];
	tlen = uniToBytes(uni,ulen,out,slen*2+1,"UTF-8");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	sContent = string(out);
	return 0;
}


/*****************************
 * �ڲ��ӿ�
 * **************************/
bool CMBTool::LoadEmotion(const char* sFile)
{
	if("" == sFile)
	  return false;

	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can not  open file "<<sFile<<endl;
		return false;
	}
	string line;
	map<string,int> wordlist;
	map<string,int>::iterator it;
	while(getline(fin,line))
	{
		if(line.size() < 1)
		  continue;
		it = wordlist.find(line);
		if(it == wordlist.end())
		{
			m_Emotion.insert(map<string,int>::value_type(line,1));
		}
	}
	fin.close();
	cerr<<"finish load mini blog emotion:"<<m_Emotion.size()<<endl;
	return true;
}


bool CMBTool::LoadNickNameEndTag(const char* sFile)
{
	if("" == sFile)
	  return false;
	ifstream fin;
	fin.open(sFile);
	if(!fin.is_open())
	{
		cerr<<"can not  open file "<<sFile<<endl;
		return false;
	}
	char text[1024]="";
	map<string,int>::iterator it;
	while(!fin.eof())
	{
		if(fin.getline(text,1024).good()==false)
		  break;
		int tLen = strlen(text);
		if(tLen < 1)
		  continue;
		it = m_NickNameEndTag.find(text);
		if(it == m_NickNameEndTag.end())
		{
			m_NickNameEndTag.insert(map<string,int>::value_type(text,1));
		}
	}
	fin.close();
	cerr<<"finish load nick name end tag:"<<m_NickNameEndTag.size()<<endl;
	return true;
}

bool CMBTool::LoadUrlStartTag(const char* sFile)
{
	if("" == sFile)
	  return false;
	ifstream fin;
	fin.open(sFile);
	if(!fin.is_open())
	{
		cerr<<"can not  open file "<<sFile<<endl;
		return false;
	}
	char text[1024]="";
	map<string,int>::iterator it;
	while(!fin.eof())
	{
		if(fin.getline(text,1024).good()==false)
		  break;
		int tLen = strlen(text);
		if(tLen < 1)
		  continue;
		it = m_UrlStartTag.find(text);
		if(it == m_UrlStartTag.end())
		{
			m_UrlStartTag.insert(map<string,int>::value_type(text,1));
		}
	}
	fin.close();
	cerr<<"finish load url start tag:"<<m_UrlStartTag.size()<<endl;
	return true;
}

int CMBTool::GetCharUnit(const char *src,char &len,int remainlen,char charset)
{
	if((unsigned char)(*src) < 128)
	{
		len = 1;
		return 1;
	}
	if(0 == charset)
	{
		if(remainlen>1)
		{
			len =2;
			return 2;
		}
		len = 1;
		return 2;
	}
	char i = 1;
	unsigned char c;
	int irelen = remainlen>6?6:remainlen;
	while(i < irelen)
	{
		c = *(src+i);
		if(!(c & 128))
		{
			break;
		}
		else if( c >= 192)
		{
			break;
		}
		else
		{}
		i++;
	}
	len = i;
	return 2;
}

bool CMBTool::LoadComplex2Simple(const char *sFile)
{
	if(sFile == NULL)
	  return false;
	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<sFile<<endl;
		return false;
	}
	char buf[1024]="";
	char *first = NULL;
	char *second = NULL;
	unsigned short uni1[4],uni2[4];
	int iret1 = 0,iret2 = 0;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		first = strtok_r(buf,"\t",&second);
		if(first == NULL || second == NULL)
		  continue;
		iret1 = bytesToUni(first,strlen(first),uni1,strlen(first)+1,"UTF-8");
		iret2 = bytesToUni(second,strlen(second),uni2,strlen(second)+1,"UTF-8");
		if(iret1!=1 || iret2!=1)
		  continue;
		m_Complex2Simple[uni1[0]] = uni2[0];
	}
	cerr<<"finish load Complex2Simple:"<<m_Complex2Simple.size()<<endl;
	return true;
}

bool CMBTool::LoadAbnormalNum(const char *sFile)
{
	if(sFile == NULL)
	  return false;
	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<sFile<<endl;
		return false;
	}
	char buf[1024]="";
	char *first = NULL;
	char *second = NULL;
	unsigned short uni1[4],uni2[4];
	int iret1 = 0,iret2 = 0;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		first = strtok_r(buf,"\t",&second);
		if(first == NULL || second == NULL)
		  continue;
		iret1 = bytesToUni(first,strlen(first),uni1,strlen(first)+1,"UTF-8");
		iret2 = bytesToUni(second,strlen(second),uni2,strlen(second)+1,"UTF-8");
		if(iret1!=1 || iret2!=1)
		  continue;
		m_AbnormalNum[uni1[0]] = uni2[0];
	}
	cerr<<"finish load AbnormalNum:"<<m_AbnormalNum.size()<<endl;
	return true;
}

bool CMBTool::LoadOddChar(const char* sFile)
{
	if(sFile == NULL)
	  return false;
	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<sFile<<endl;
		return false;
	}
	char buf[1024]="";
	unsigned short uni1[4];
	int iret1 = 0,iret2 = 0;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		if(strlen(buf) < 1)
		  continue;
		iret1 = bytesToUni(buf,strlen(buf),uni1,strlen(buf)+1,"UTF-8");
		if(iret1!=1 )
		  continue;
		m_OddChar[uni1[0]] = 1;
	}
	cerr<<"finish load OddChar:"<<m_OddChar.size()<<endl;
	return true;
}


bool CMBTool::LoadJapChar(const char* sFile)
{
	if(sFile == NULL)
	  return false;
	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<sFile<<endl;
		return false;
	}
	char buf[1024]="";
	unsigned short uni1[4];
	int iret1 = 0,iret2 = 0;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		if(strlen(buf) < 1)
		  continue;
		iret1 = bytesToUni(buf,strlen(buf),uni1,strlen(buf)+1,"UTF-8");
		if(iret1!=1 )
		  continue;
		m_JapChar[uni1[0]] = 1;
	}
	cerr<<"finish load Japnese char:"<<m_JapChar.size()<<endl;
	return true;
}


bool CMBTool::LoadChiChar(const char* sFile)
{
	if(sFile == NULL)
	  return false;
	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<sFile<<endl;
		return false;
	}
	char buf[1024]="";
	unsigned short uni1[4];
	int iret1 = 0,iret2 = 0;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		if(strlen(buf) < 1)
		  continue;
		iret1 = bytesToUni(buf,strlen(buf),uni1,strlen(buf)+1,"UTF-8");
		if(iret1!=1 )
		  continue;
		m_ChiChar[uni1[0]] = 1;
	}
	cerr<<"finish load Chinese simple char:"<<m_ChiChar.size()<<endl;
	return true;
}

bool CMBTool::LoadContactTag(const char* sFile)
{
	if("" == sFile)
	  return false;
	ifstream fin;
	fin.open(sFile);
	if(!fin.is_open())
	{
		cerr<<"can not  open file "<<sFile<<endl;
		return false;
	}
	char text[1024]="";
	map<string,int>::iterator it;
	while(!fin.eof())
	{
		if(fin.getline(text,1024).good()==false)
		  break;
		int tLen = strlen(text);
		if(tLen < 1)
		  continue;
		it = m_ContactTag.find(text);
		if(it == m_ContactTag.end())
		{
			m_ContactTag.insert(map<string,int>::value_type(text,1));
		}
	}
	fin.close();
	cerr<<"finish load contact tag :"<<m_ContactTag.size()<<endl;
	return true;
}


bool CMBTool::LoadPunction(const char* sFile)
{
	if(sFile == NULL)
	  return false;
	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<sFile<<endl;
		return false;
	}
	char buf[1024]="";
	char *first = NULL;
	char *second = NULL;
	unsigned short uni1[4];
	string line;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		first = strtok_r(buf,"\t",&second);
		if(first == NULL || second == NULL)
		  continue;
		int iret = bytesToUni(first,strlen(first),uni1,strlen(first)+1,"UTF-8");
		if(iret != 1)
		  continue;
		m_Punction[uni1[0]] = atoi(second);
	}
	fin.close();
	cerr<<"finish load punctuation:"<<m_Punction.size()<<endl;
	return true;
}

bool CMBTool::LoadHanzi2Pinyin(const char *sFile)
{
	if(sFile == NULL)
	  return false;
	ifstream fin(sFile);
	if(!fin.is_open())
	{
		cerr<<"can't open file:"<<sFile<<endl;
		return false;
	}
	char buf[1024]="";
	char *first = NULL;
	char *second = NULL;
	unsigned short uni1[4];
	string line;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		first = strtok_r(buf,"\t",&second);
		if(first == NULL || second == NULL)
		  continue;
		int iret = bytesToUni(first,strlen(first),uni1,strlen(first)+1,"UTF-8");
		if(iret != 1)
		  continue;
		m_Hanzi2Pinyin[uni1[0]] = string(second);
	}
	fin.close();
	cerr<<"finish load Hanzi2Pinyin:"<<m_Hanzi2Pinyin.size()<<endl;
	return true;
}



string CMBTool::UnicodeToStr(unsigned short code)
{
	char buf[128];
	unsigned short sbuf[1];
	sbuf[0] = code;
	int rlen = 0;
	if((rlen = uniToBytes(sbuf, 1, buf, 128, "UTF-8")) > 0)
	{
		buf[rlen] = 0;
		return string(buf);
	}
	return "";
}

string CMBTool::UnicodeToStr(unsigned short* code, int size)
{
	int buf_size = size*2+1;
	char* buf = new char[buf_size];
	int rlen = 0;
	if((rlen = uniToBytes(code, size, buf, buf_size, "UTF-8")) > 0)
	{
		buf[rlen] = 0;
		string res(buf);
		delete [] buf;
		return res;
	}
	delete [] buf;
	return "";
}
