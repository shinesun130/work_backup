/*
 * xgboost_service_all.cpp
 *
 *  Created on: 2017年1月4日
 *      Author: huinan1
 */

#include <stdlib.h>
#include <stdio.h>
#include <string>
#include <iostream>
#include <pthread.h>
#include <assert.h>
#include <dlfcn.h>
#include "modulecommon.h"
#include "parsejson.h"
#include "StringTool.h"
#include "parseDataConf.h"
#include "loadmodel.h"

using namespace std;

struct module_thread_data
{
    JsonTree_t *ptree;
    JsonText_t *ptext;
};

struct parameter
{
    int solver_type;

    /* these are for training only */
    double eps; /* stopping criteria */
    double C;
    int nr_weight;
    int *weight_label;
    double* weight;
    double p;
};

struct model
{
    struct parameter param;
    int nr_class; /* number of classes */
    int nr_feature;
    double *w;
    int *label; /* label of each class */
    double bias;
};

typedef struct model* (*LOAD_MODEL)(const char*);
typedef struct model* (*PREDICT)(const struct model*,
        const std::map<int, double>&);
typedef struct model* (*PREDICT_LEAF)(const struct model*,
        const std::map<int, double>&, vector<float>&);

class XgboostPredModule
{
public:
    XgboostPredModule() :
            customModel_(NULL), binModel_(NULL), loadBinModel_(true), load_model_(
            NULL), predict_(NULL), predict_leaf_(NULL)
    {
    }
    ;

    ~XgboostPredModule()
    {
        if (loadBinModel_)
        {
            delete binModel_;
            binModel_ = NULL;
        } else
        {
            delete customModel_;
            customModel_ = NULL;
        }
    }

    void init_module(const char * data_dir, logger_t logger)
    {
        cerr << "initing global data from:" << data_dir << endl;

        string loadModelConf = string(data_dir) + "/loadModel.conf";

        ifstream fin(loadModelConf.c_str());
        if (!fin.is_open())
        {
            cerr << "can't open file: " << loadModelConf << endl;
        }

        string line = "";
        // first line is label info
        getline(fin, line);
        line = line.substr(line.find("=") + 1);
        if (line == "false")
        {
            loadBinModel_ = false;
        }

        string modelFile = "";

        if (loadBinModel_)
        {
            string funFile = string(data_dir) + "/gbdt.so";
            init_module_func(funFile.c_str());
            modelFile = string(data_dir) + "/bin.model";
            binModel_ = (*load_model_)(modelFile.c_str());
        } else
        {
            modelFile = string(data_dir) + "/custom.model";
            customModel_ = (new XgboostModel())->build(modelFile);
        }

        configFile_ = data_dir;
        logger_ = logger;
        cerr << "glabal data init success!" << endl;
    }

    void predict_leaf(const map<int, double>& feature2Value,
            vector<float>& comb_feature)
    {
        if (loadBinModel_)
        {
            (*predict_leaf_)(binModel_, feature2Value, comb_feature);
        } else
        {
            customModel_->get_feature_comb(feature2Value, comb_feature);
        }
    }

public:
    string configFile_;
    logger_t logger_;

    //default load bin model
    bool loadBinModel_;

private:
    void init_module_func(const char* func_file)
    {

        void *handle;
        char *error;

        handle = dlopen(func_file, RTLD_LAZY);
        if (!handle)
        {
            fprintf(stderr, "dlopen %s\n", dlerror());
            exit(EXIT_FAILURE);
        }
        dlerror();

        *(void **) (&(load_model_)) = dlsym(handle, "load_model");
        if ((error = dlerror()) != NULL)
        {
            fprintf(stderr, "dlsym %s\n", error);
            exit(EXIT_FAILURE);
        }

        *(void **) (&(predict_)) = dlsym(handle, "predict");
        if ((error = dlerror()) != NULL)
        {
            fprintf(stderr, "dlsym %s\n", error);
            exit(EXIT_FAILURE);
        }

        *(void **) (&(predict_leaf_)) = dlsym(handle, "predict_leaf");
        if ((error = dlerror()) != NULL)
        {
            fprintf(stderr, "dlsym %s\n", error);
            exit(EXIT_FAILURE);
        }

        dlclose(handle);
    }

private:
    XgboostModel* customModel_;
    model* binModel_;

    // used by predict bin model
    LOAD_MODEL load_model_;
    PREDICT predict_;
    PREDICT_LEAF predict_leaf_;
};

void* module_load(const char * data_dir, logger_t logger)
{
    cerr << "initing global data from:" << data_dir << endl;

    XgboostPredModule* module = new XgboostPredModule();
    module->init_module(data_dir, logger);
    return (void*) module;
}

int module_unload(void* plug)
{
    XgboostPredModule *module = (XgboostPredModule*) plug;
    delete module;
    return 0;
}

void *module_thread_data_create(void* plug)
{
    module_thread_data* thread_data = (module_thread_data*) malloc(
            sizeof(module_thread_data));
    assert(thread_data != NULL);
    thread_data->ptree = CreateJsonTree();
    assert(thread_data->ptree != NULL);
    thread_data->ptext = CreateJsonText(1000);
    assert(thread_data->ptext != NULL);
    return thread_data;
}

void module_thread_data_release(void*plug, void *thread_data)
{
    module_thread_data* t_data = (module_thread_data*) thread_data;
    if (t_data->ptree != NULL)
    {
        FreeJsonTree(t_data->ptree);
        t_data->ptree = NULL;
        FreeJsonText(t_data->ptext);
        t_data->ptext = NULL;
    }
    free(thread_data);
}

int ParseJsonInput(module_thread_data *workData, map<string, string>&tField,
        char *input, int srcLen)
{
    int ret;
    JsonTree_t *ptree = workData->ptree;
    PairNode_t *ppair;
    ret = ParseJson(input, srcLen, ptree);
    if (ret <= 0)
        return -1;
    if (ptree->rootType != V_PAIR_ARRAY)
        return -2;
    map<string, string>::iterator it;
    tField.clear();
    ForEachPairNode(ptree, 0, ppair)
    {
        if (ppair->keyStr == NULL || ppair->pStr == NULL
                || (ppair->v_type != V_STR && ppair->v_type != V_VALUE_STR))
            return -3;
#ifdef DEBUG2
        fprintf(stderr,"parseJson:%s-->%s\n",ppair->keyStr,ppair->pStr);
#endif
        it = tField.find(ppair->keyStr);
        if (it == tField.end())
            tField.insert(
                    map<string, string>::value_type(ppair->keyStr,
                            ppair->pStr));
    }
    return 0;
}

void GenResult(char *resultStr, int &resultLen, map<string, string>& resMap)
{
    map<string, string>::iterator sit;
    string resstr = "{";
    for (sit = resMap.begin(); sit != resMap.end(); sit++)
    {
        resstr += "\"" + sit->first + "\":\"" + sit->second + "\",";
    }
    string res = resstr.substr(0, resstr.size() - 1) + "}";
#ifdef DEBUG
    cerr<<res<<"#"<<endl;
#endif
    strcpy(resultStr, res.c_str());
    resultLen = res.length();
}

int module_processor(void* module, const char *input, int intput_space_size,
        char *output, int output_space_size, void *thread_data)
{
#ifdef DEBUG
    cerr<<"input:"<<input<<endl;
#endif

    strcpy(output, input);
    XgboostPredModule* workModule = (XgboostPredModule*) module;
    module_thread_data* workData = (module_thread_data*) thread_data;
    strcpy(output, "default result");
    map<string, string> dataField;
    map<string, string> rMap;
    map<string, string>::iterator sit;
    char Log[65535];
    memcpy(Log, input, intput_space_size);
    int iret = ParseJsonInput(workData, dataField, Log, intput_space_size);
    if (iret < 0)
    {
        rMap.insert(
                map<string, string>::value_type("error", "parse input failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }

    map<string, DataConf> featureMap;

    bool parser = CDataConfParser::parseDataConf(featureMap,
            workModule->configFile_ + "/data.conf");

    if (!parser)
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "parse data.conf failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }

    map<int, double> feature2Value;
    bool getInstance = CDataConfParser::getInstance(featureMap, dataField,
            feature2Value);

    if (!getInstance)
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "get instance failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }

    vector<float> comb_feature;
    workModule->predict_leaf(feature2Value, comb_feature);

    string combFeature = "";
    ostringstream stream;
    if (workModule->loadBinModel_)
    {
        for (int i = 0; i < comb_feature.size(); i++)
        {
            stream << comb_feature[i];
            stream << ",";
        }
    } else
    {

        for (int i = 0; i < comb_feature.size(); i++)
        {
            if (comb_feature[i] > 0)
            {
                stream << i;
                stream << ",";
            }
        }

    }

    combFeature = stream.str();
    if (combFeature.empty())
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "get predict feature failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }
    combFeature = combFeature.substr(0, combFeature.size() - 1);

    rMap.insert(map<string, string>::value_type("featureComb", combFeature));
    GenResult(output, output_space_size, rMap);

    return output_space_size;
}

/*
 int main(){
 logger_t logger;
 void* module = module_load(".", logger);
 XgboostPredModule* gt = (XgboostPredModule*)module;
 vector<float> comb_feature;
 std::map<int, double> nodes;
 nodes[0] = 29;
 nodes[1] = 8000;
 nodes[2] = 32000;
 nodes[3] = 32;
 nodes[4] = 8;
 nodes[5] = 32;
 nodes[7] = 1;
 gt->predict_leaf(nodes, comb_feature);
 if( gt->loadBinModel_ ){
 for (int i = 0; i < comb_feature.size(); i++)
 {
 cout << comb_feature[i];
 cout << ",";
 }
 }else
 {

 for (int i = 0; i < comb_feature.size(); i++)
 {
 if (comb_feature[i] > 0)
 {
 cout << i;
 cout << ",";
 }
 }

 }
 }
 */
