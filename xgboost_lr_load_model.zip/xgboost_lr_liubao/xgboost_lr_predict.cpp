#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <iostream>
#include <pthread.h>
#include <assert.h>
#include <map>
#include <set>
#include <dlfcn.h>
#include "modulecommon.h"
#include "parsejson.h"
#include "StringTool.h"
#include "linear.h"
#include "tron.h"
#include "feature.h"
#include "parseDataConf.h"
#include "loadmodel.h"
using namespace std;

#define MAX_ATTR 1024

struct module_thread_data
{
    JsonTree_t *ptree;
    JsonText_t *ptext;
    struct feature_node *x;
};

typedef struct model* (*LOAD_MODEL)(const char*);
typedef struct model* (*PREDICT)(const struct model*,
        const std::map<int, double>&);
typedef struct model* (*PREDICT_LEAF)(const struct model*,
        const std::map<int, double>&, vector<float>&);

class XgboostLRModule
{
public:
    XgboostLRModule() :
            customModel_(NULL), binModel_(NULL), lrModel_(NULL), loadBinModel_(
            true), load_model_(
            NULL), predict_(NULL), predict_leaf_(NULL)
    {
    }
    ;

    ~XgboostLRModule()
    {
        if (loadBinModel_)
        {
            delete binModel_;
            binModel_ = NULL;
        } else
        {
            delete customModel_;
            customModel_ = NULL;
        }
        delete lrModel_;
        lrModel_ = NULL;
    }

    void init_xgboost_module(const char * data_dir, logger_t logger)
    {
        string loadModelConf = string(data_dir) + "/loadModel.conf";

        ifstream fin(loadModelConf.c_str());
        if (!fin.is_open())
        {
            cerr << "can't open file: " << loadModelConf << endl;
        }

        string line = "";
        // first line is label info
        getline(fin, line);
        line = line.substr(line.find("=") + 1);
        if (line == "false")
        {
            loadBinModel_ = false;
        }

        string modelFile = "";

        if (loadBinModel_)
        {
            string funFile = string(data_dir) + "/gbdt.so";
            init_module_func(funFile.c_str());
            modelFile = string(data_dir) + "/bin.model";
            binModel_ = (*load_model_)(modelFile.c_str());
        } else
        {
            modelFile = string(data_dir) + "/custom.model";
            customModel_ = (new XgboostModel())->build(modelFile);
        }

    }

    void init_lr_module(const char * data_dir, logger_t logger)
    {
        configFile_ = data_dir;
        char file[1024];
        sprintf(file, "%s/interact_predict.mdl", data_dir);
        lrModel_ = load_model(file);
        if (NULL == lrModel_)
        {
            cerr << "load interact model failed!" << endl;
        }
        feature_manager = new FeatureManager();
        sprintf(file, "%s/feature.map", data_dir);
        if (!feature_manager->Init(file))
        {
            cerr << "init feature map file failed" << endl;
        }
    }

    void init_module(const char * data_dir, logger_t logger)
    {
        cerr << "initing global data from:" << data_dir << endl;

        init_xgboost_module(data_dir, logger);
        init_lr_module(data_dir, logger);

        configFile_ = data_dir;
        logger_ = logger;
        cerr << "glabal data init success!" << endl;
    }

    void predict_leaf(const map<int, double>& feature2Value,
            vector<float>& leafNodes)
    {
        if (loadBinModel_)
        {
            (*predict_leaf_)(binModel_, feature2Value, leafNodes);
        } else
        {
            customModel_->predict_leaf(feature2Value, leafNodes);
        }
    }

    void lrGenInstance(map<string, string>& tFields,
            set<pair<int, double> >& feature_set)
    {
        feature_manager->GenInstance(tFields, feature_set);
    }

    string getConfig()
    {
        return configFile_;
    }

public:
    XgboostModel* customModel_;
    // xgboost bin model
    model* binModel_;
    // LR model
    model* lrModel_;

private:
    void init_module_func(const char* func_file)
    {
        void *handle;
        char *error;

        handle = dlopen(func_file, RTLD_LAZY);
        if (!handle)
        {
            fprintf(stderr, "dlopen %s\n", dlerror());
            exit(EXIT_FAILURE);
        }
        dlerror();

        *(void **) (&(load_model_)) = dlsym(handle, "load_model");
        if ((error = dlerror()) != NULL)
        {
            fprintf(stderr, "dlsym %s\n", error);
            exit(EXIT_FAILURE);
        }

        *(void **) (&(predict_)) = dlsym(handle, "predict");
        if ((error = dlerror()) != NULL)
        {
            fprintf(stderr, "dlsym %s\n", error);
            exit(EXIT_FAILURE);
        }

        *(void **) (&(predict_leaf_)) = dlsym(handle, "predict_leaf");
        if ((error = dlerror()) != NULL)
        {
            fprintf(stderr, "dlsym %s\n", error);
            exit(EXIT_FAILURE);
        }

        dlclose(handle);
    }

private:
    // used by predict bin model
    LOAD_MODEL load_model_;
    PREDICT predict_;
    PREDICT_LEAF predict_leaf_;

    FeatureManager* feature_manager;
    map<long, string>* source;

    // config para
    string configFile_;
    logger_t logger_;

    //default load bin model
    bool loadBinModel_;
};

void* module_load(const char * data_dir, logger_t logger)
{
    cerr << "initing global data from:" << data_dir << endl;

    XgboostLRModule* module = new XgboostLRModule();
    module->init_module(data_dir, logger);

    cerr << "glabal data init success!" << endl;
    return (void*) module;
}

int module_unload(void* plug)
{
    XgboostLRModule *module = (XgboostLRModule*) plug;
    delete module;
    return 0;
}

void *module_thread_data_create(void* plug)
{
    module_thread_data* thread_data = (module_thread_data*) malloc(
            sizeof(module_thread_data));
    assert(thread_data != NULL);
    thread_data->ptree = CreateJsonTree();
    assert(thread_data->ptree != NULL);
    thread_data->ptext = CreateJsonText(1000);
    assert(thread_data->ptext != NULL);
    thread_data->x = (struct feature_node *) malloc(
    MAX_ATTR * sizeof(struct feature_node));
    XgboostLRModule* module = (XgboostLRModule*) plug;
    return thread_data;
}

void module_thread_data_release(void*plug, void *thread_data)
{
    module_thread_data* t_data = (module_thread_data*) thread_data;
    if (t_data->ptree != NULL)
    {
        FreeJsonTree(t_data->ptree);
        t_data->ptree = NULL;
        FreeJsonText(t_data->ptext);
        t_data->ptext = NULL;
        free(t_data->x);
        t_data->x = NULL;
    }
    free(thread_data);
}

int ParseJsonInput(module_thread_data *workData, map<string, string>&tField,
        char *input, int srcLen)
{
    int ret;
    JsonTree_t *ptree = workData->ptree;
    PairNode_t *ppair;
    ret = ParseJson(input, srcLen, ptree);
    if (ret <= 0)
        return -1;
    if (ptree->rootType != V_PAIR_ARRAY)
        return -2;
    map<string, string>::iterator it;
    tField.clear();
    ForEachPairNode(ptree, 0, ppair)
    {
        if (ppair->keyStr == NULL || ppair->pStr == NULL
                || (ppair->v_type != V_STR && ppair->v_type != V_VALUE_STR))
            return -3;
#ifdef DEBUG2
        fprintf(stderr,"parseJson:%s-->%s\n",ppair->keyStr,ppair->pStr);
#endif
        it = tField.find(ppair->keyStr);
        if (it == tField.end())
            tField.insert(
                    map<string, string>::value_type(ppair->keyStr,
                            ppair->pStr));
    }
    return 0;
}

void GenResult(char *resultStr, int &resultLen, map<string, string>& resMap)
{
    map<string, string>::iterator sit;
    string resstr = "{";
    for (sit = resMap.begin(); sit != resMap.end(); sit++)
    {
        resstr += "\"" + sit->first + "\":\"" + sit->second + "\",";
    }
    string res = resstr.substr(0, resstr.size() - 1) + "}";
#ifdef DEBUG
    cerr<<res<<"#"<<endl;
#endif
    strcpy(resultStr, res.c_str());
    resultLen = res.length();
}

int do_predict(XgboostLRModule* workModule, module_thread_data *workData,
        set<pair<int, double> >& input, double *prob_estimates)
{
    struct model* model_ = workModule->lrModel_;
    struct feature_node *fnode = workData->x;
    int nr_feature = get_nr_feature(model_);
    int n = 0, i = 0;
    if (model_->bias >= 0)
        n = nr_feature + 1;
    else
        n = nr_feature;
    int cur_index = 0;
    cerr << "all features" << endl;
    set<pair<int, double> >::iterator it;
    for (it = input.begin(); it != input.end(); it++)
    {
        fnode[cur_index].index = it->first;
        fnode[cur_index].value = it->second;
        cerr << it->first << ":" << it->second << endl;
        cur_index++;
    }
    //cerr << endl;
    if (model_->bias >= 0)
    {
        fnode[cur_index].index = n;
        fnode[cur_index].value = model_->bias;
        cur_index++;
    }
    fnode[cur_index].index = -1;
    double predict_label = predict_probability(model_, fnode, prob_estimates);
    int labels[2];
    get_labels(model_, labels);
    for (int j = 0; j < model_->nr_class; j++)
    {
        char key[24], value[24];
        cerr << labels[j] << ":" << prob_estimates[j] << endl;
    }
    return 0;
}

bool xgboost_predict(XgboostLRModule* workModule,
        map<string, string>& dataField, vector<float>& leafNodes, char *output,
        int& output_space_size)
{
    map<string, DataConf> featureMap;

    bool parser = CDataConfParser::parseDataConf(featureMap,
            workModule->getConfig() + "/data.conf");

    map<string, string> rMap;
    if (!parser)
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "parse data.conf failed"));
        GenResult(output, output_space_size, rMap);
        return false;
    }

    map<int, double> feature2Value;
    bool getInstance = CDataConfParser::getInstance(featureMap, dataField,
            feature2Value);

    if (!getInstance)
    {
        rMap.insert(
                map<string, string>::value_type("error",
                        "get instance failed"));
        GenResult(output, output_space_size, rMap);
        return false;
    }

    workModule->predict_leaf(feature2Value, leafNodes);
    return true;
}

int module_processor(void* module, const char *input, int intput_space_size,
        char *output, int output_space_size, void *thread_data)
{
#ifdef DEBUG
    cerr<<"input:"<<input<<endl;
#endif
    strcpy(output, input);
    XgboostLRModule* workModule = (XgboostLRModule*) module;
    module_thread_data *workData = (module_thread_data *) thread_data;
    strcpy(output, "default result");
    map<string, string> tField;
    map<string, string> rMap;
    map<string, string>::iterator sit;
    char Log[65535];
    memcpy(Log, input, intput_space_size);
    int iret = ParseJsonInput(workData, tField, Log, intput_space_size);
    if (iret < 0)
    {
        rMap.insert(
                map<string, string>::value_type("error", "parse input failed"));
        GenResult(output, output_space_size, rMap);
        return output_space_size;
    }

    // xgboost predict to get combine feature
    vector<float> leafNodes;
    if (!xgboost_predict(workModule, tField, leafNodes, output,
            output_space_size))
    {
        return output_space_size;
    }

    set<pair<int, double> > feature_set;
    workModule->lrGenInstance(tField, feature_set);
    set<pair<int, double> >::iterator it;

    cerr << "lr features" << endl;
    for (it = feature_set.begin(); it != feature_set.end(); it++)
    {
        cerr << it->first << ":" << it->second << endl;
    }

    cerr << "xgboost features" << endl;
    // add xgboost feature to lr
    int xgboostFeatureStartIndex = workModule->lrModel_->nr_feature;
    for (int i = 0; i < leafNodes.size(); i++)
    {
        feature_set.insert(
                make_pair(xgboostFeatureStartIndex + (int) leafNodes[i], 1));
        cerr << xgboostFeatureStartIndex + (int) leafNodes[i] << ": 1" << endl;
    }

    cerr << endl;
    double prob_estimates[2];
    do_predict(workModule, workData, feature_set, prob_estimates);
    int labels[2];
    get_labels(workModule->lrModel_, labels);
    for (int j = 0; j < workModule->lrModel_->nr_class; j++)
    {
        char key[24], value[24];
        sprintf(value, "%f", prob_estimates[j]);
        sprintf(key, "%d", labels[j]);
        rMap.insert(
                map<string, string>::value_type(string(key), string(value)));
    }
    GenResult(output, output_space_size, rMap);
    return output_space_size;
}

