/*
 * loadmodel.cpp
 *
 *  Created on: 2016年12月16日
 *      Author: huinan1
 */

#include <vector>
#include "loadmodel.h"

using namespace std;

// construct a intermediate node
Node* Node::asIntermediateNode(int feature, int indexInTree, double threshold,
        int yesIndex, int noIndex, int missingIndex, string desc)
{
    this->isLeaf = false;
    this->indexInTree = indexInTree;
    this->feature = feature;
    this->threshold = threshold;

    this->yesIndex = yesIndex;
    this->noIndex = noIndex;
    this->missingIndex = missingIndex;

    this->desc = desc;

    return this;
}

// construct a leaf node
Node* Node::asLeaf(double value, int indexInTree, string desc)
{
    this->isLeaf = true;
    this->indexInTree = indexInTree;
    this->value = value;

    this->desc = desc;

    return this;
}

// get the next node index for given instance
int Node::nextNode(const map<int, double>& featureIndex2Value)
{
    if (isLeaf)
    {
        cerr << "node is leaf!" << endl;
        return -1;
    }

    if (featureIndex2Value.find(this->feature) == featureIndex2Value.end())
    {
        return missingIndex;
    } else if (featureIndex2Value.find(this->feature)->second
            < (this->threshold))
    {
#ifdef DEBUG
        cout << "feature index: " << this->feature << endl;
        cout << "yes" << endl;
        cout << "value: " << featureIndex2Value.find(this->feature)->second
        << endl;
        cout << "threshold: " << this->threshold << endl;
#endif
        return yesIndex;
    } else
    {
#ifdef DEBUG
        cout << "no" << endl;
        cout << "feature index: " << this->feature << endl;
        cout << "value: " << featureIndex2Value.find(this->feature)->second
        << endl;
        cout << "threshold: " << this->threshold << endl;
#endif
        return noIndex;
    }
}

string Node::getDesc()
{
    return this->desc;
}

Tree::Tree(int depth)
{
    this->leafNum = 0;
    this->maxNodeIndex = 0;
    // resize nodes size to max node size for given tree depth, some node may don't have value
    (this->nodes).resize(pow2(depth + 1) - 1);

    for (unsigned i = 0; i < this->nodes.size(); i++)
    {
        this->nodes[i] = NULL;
    }
}

Tree::~Tree()
{
    for (vector<Node*>::iterator nodeIter = this->nodes.begin();
            nodeIter != this->nodes.end(); ++nodeIter)
    {
        if (*nodeIter != NULL)
        {
            delete (*nodeIter);
            *nodeIter = NULL;
        }
    }
    this->nodes.clear();
}

vector<Node*> Tree::getNodes()
{
    return nodes;
}

// get the predict value
double Tree::predict(const map<int, double>& featureIndex2Value)
{
    return findLeaf(featureIndex2Value)->getValue();
}

// get leaf description
string Tree::apply(const map<int, double>& featureIndex2Value)
{
    return findLeaf(featureIndex2Value)->getDesc();
}

// find leaf node by given instance
Node* Tree::findLeaf(const map<int, double>& featureIndex2Value)
{
    Node* node = nodes[0];

    int nextNodeIndex = 0;
    while (!node->isLeafNode())
    {
        // debug info
#ifdef DEBUG
        cout << "node index: " << node->getIndex() << " node threshold: "
        << node->getThresh() << endl;
#endif
        nextNodeIndex = node->nextNode(featureIndex2Value);
        if (nextNodeIndex == -1)
        {
            cerr << "next node index is not found!" << endl;
            return NULL;
        }
        node = nodes[nextNodeIndex];
    }

    return node;
}

// generate node by node message
void Tree::genNode(string nodeMsg)
{
    if (toIntermediateNode(nodeMsg) || toLeaf(nodeMsg))
    {
        return;
    } else
    {
        cerr << "can't parse node: " + nodeMsg << endl;
    }
}

// convert node message to leaf node, add the node to tree
bool Tree::toLeaf(string nodeMsg)
{
    vector<string> index2Info = StringTool::SplitString(nodeMsg, ":");
    if (index2Info.size() != 2)
    {
        cout << "Error invalid node message:" << nodeMsg;
        exit(1);
    }
    StringTool::TrimAll(index2Info[0]);
    StringTool::TrimAll(index2Info[1]);
    if (index2Info[1].find("leaf") != string::npos)
    {
        int index = atoi(index2Info[0].c_str());
        double value = atof(
                (index2Info[1].substr(index2Info[1].find("=") + 1)).c_str());

        nodes[index] = (new Node())->asLeaf(value, index, nodeMsg);

        // keep leaf number for generate leaf combine feature in the future
        this->leafNum += 1;

        if (index > this->maxNodeIndex)
        {
            this->maxNodeIndex = index;
        }

        this->leafIndex.push_back(index);

        return true;
    } else
    {
        return false;
    }
}

// convert node message to intermediate node, add the node to tree
bool Tree::toIntermediateNode(string nodeMsg)
{
    vector<string> index2Info = StringTool::SplitString(nodeMsg, ":");
    if (index2Info.size() != 2)
    {
        cout << "Error invalid node message:" << nodeMsg;
        exit(1);
    }
    StringTool::TrimAll(index2Info[0]);
    StringTool::TrimAll(index2Info[1]);
    if (index2Info[1].find("leaf") == string::npos)
    {
        vector<string> featureInfo = StringTool::SplitString(nodeMsg, ",");
        if (featureInfo.size() != 3)
        {
            cout << "Error invalid node message:" << nodeMsg;
            exit(1);
        }
        int index = atoi(index2Info[0].c_str());
        int featureIndexStart = featureInfo[0].find("f");
        int featureIndexThresholdSplit = featureInfo[0].find("<");
        string featureIndexStr = featureInfo[0].substr(featureIndexStart + 1,
                featureIndexThresholdSplit - featureIndexStart - 1);
        StringTool::TrimAll(featureIndexStr);

        // feature index and value, xgboost feature index start from 1
        int featureIndex = atoi(featureIndexStr.c_str());
        string featureThresholdStr = featureInfo[0].substr(
                featureIndexThresholdSplit + 1,
                featureInfo[0].find("]") - featureIndexThresholdSplit - 1);
        double featureThreshold = atof(featureThresholdStr.c_str());

        // yes node info
        string yesFeatureNodeIndexStr = featureInfo[0].substr(
                featureInfo[0].find("=") + 1);
        StringTool::TrimAll(yesFeatureNodeIndexStr);
        int yesFeatureNodeIndex = atoi(yesFeatureNodeIndexStr.c_str());

        // no node info
        string noFeatureNodeIndexStr = featureInfo[1].substr(
                featureInfo[1].find("=") + 1);
        StringTool::TrimAll(noFeatureNodeIndexStr);
        int noFeatureNodeIndex = atoi(noFeatureNodeIndexStr.c_str());

        // missing node info
        string missingFeatureNodeIndexStr = featureInfo[2].substr(
                featureInfo[2].find("=") + 1);
        StringTool::TrimAll(missingFeatureNodeIndexStr);
        int missingFeatureNodeIndex = atoi(missingFeatureNodeIndexStr.c_str());

        nodes[index] = (new Node())->asIntermediateNode(featureIndex, index,
                featureThreshold, yesFeatureNodeIndex, noFeatureNodeIndex,
                missingFeatureNodeIndex, nodeMsg);

        if (index > this->maxNodeIndex)
        {
            this->maxNodeIndex = index;
        }

        return true;
    } else
    {
        return false;
    }
}

// generate tree by given description
Tree* Tree::parse(vector<string> dumps)
{
    for (vector<string>::iterator dump = dumps.begin(); dump != dumps.end();
            ++dump)
    {
        this->genNode(*dump);
    }

    return this;
}

int Tree::getLeafNum()
{
    return this->leafNum;
}

XgboostModel::XgboostModel()
{
    this->eachTreeNodesNum = 0;
    this->totalNodesNum = 0;
    this->treeDepth = 0;
    this->treesNum = 0;
}

XgboostModel::~XgboostModel()
{
    for (vector<Tree*>::iterator tree = this->trees.begin();
            tree != this->trees.end(); ++tree)
    {
        delete (*tree);
        *tree = NULL;
    }
    this->trees.clear();
}

XgboostModel* XgboostModel::build(string customModelFile)
{
    vector<vector<string> > allTreesDesc;
    vector<string> eachTreeDesc;

    ifstream treeFileHler(customModelFile.c_str());

    if (!treeFileHler.is_open() || treeFileHler.eof())
    {
        cerr << "Error open file or file is empty" << customModelFile;
        exit(1);
    }

    char buffer[1000];

    treeFileHler.getline(buffer, 1000);

    parseTreesNumsAndDepth(buffer);

    // split and extract each tree's node description
    // for each tree, generate a vector<string> for storing it's node description
    while (!treeFileHler.eof())
    {
        treeFileHler.getline(buffer, 1000);
        string line = buffer;
        // find a new tree starting flag
        if (line.find("booster") != string::npos)
        {
            if (!eachTreeDesc.empty())
            {
                allTreesDesc.push_back(eachTreeDesc);
            }
            eachTreeDesc.clear();
        } else if (!line.empty())
        {
            eachTreeDesc.push_back(line);
        }
    }

    treeFileHler.close();

    // for last tree
    if (!eachTreeDesc.empty())
    {
        allTreesDesc.push_back(eachTreeDesc);
    }

    // check tree size is same with model description
    if (allTreesDesc.size() != this->treesNum)
    {
        cerr << "tree size: expected " << this->treesNum << ", actual "
                << allTreesDesc.size();
        exit(1);
    }

    // parse each tree from it's description
    for (int i = 0; i < allTreesDesc.size(); ++i)
    {
        this->trees.push_back((new Tree(treeDepth))->parse(allTreesDesc[i]));
    }

    return this;
}

// parse tree brief description
void XgboostModel::parseTreesNumsAndDepth(string parameters)
{
    if (parameters.find("numRound") == string::npos)
    {
        cout << parameters << endl;
        cout << "Tree parameters are missing, please add it in first line."
                << endl;
    }
    vector<string> parts = StringTool::SplitString(parameters, ",");
    if (parts.size() != 2)
    {
        cout << "Tree parameters are invalid, please add it in first line."
                << endl;
    }
    vector<string> treeNumInfo = StringTool::SplitString(parts[0], ":");
    vector<string> treeDepthInfo = StringTool::SplitString(parts[1], ":");
    StringTool::TrimAll(treeNumInfo[1]);
    StringTool::TrimAll(treeDepthInfo[1]);
    treesNum = atoi(treeNumInfo[1].c_str());
    // given depth is the real depth - 1
    treeDepth = atoi(treeDepthInfo[1].c_str()) + 1;
    this->eachTreeNodesNum = (int) pow(2, treeDepth) - 1;
    cout << "each tree node: " << this->eachTreeNodesNum << endl;
    this->totalNodesNum = this->eachTreeNodesNum * treesNum;
    cout << "total tree num: " << this->totalNodesNum << endl;
}

// get predict probability
double XgboostModel::predict_probability(
        const map<int, double>& featureIndex2Value)
{
    double res = 0;

    for (vector<Tree*>::iterator tree = trees.begin(); tree != trees.end();
            ++tree)
    {
        res += (*tree)->predict(featureIndex2Value);
    }

    return sigmod(res);
}

/*void XgboostModel::get_predict_leaf_index(
 const map<int, double>& featureIndex2Value, vector<int>& leaf_index)
 {
 leaf_index.clear();
 leaf_index.resize(this->trees.size(), 0);
 int i = 0;
 for (vector<Tree*>::iterator tree = this->trees.begin();
 tree != this->trees.end(); ++tree)
 {
 int predictLeafIndex =
 ((*tree)->findLeaf(featureIndex2Value))->getIndex();
 leaf_index[i] = predictLeafIndex;
 i++;
 }
 }

 void XgboostModel::get_one_hot_feature(
 const map<int, double>& featureIndex2Value,
 vector<int>& one_hot_feature)
 {
 one_hot_feature.clear();
 vector<int> prevNodeNumInTree;
 vector<int> predictLeafIndexes;
 int totalNodesNum = 0;
 prevNodeNumInTree.push_back(0);

 for (vector<Tree*>::iterator treeIter = this->trees.begin();
 treeIter != this->trees.end(); ++treeIter)
 {
 int nodesNumInTree = (*treeIter)->getMaxNodeNum();
 totalNodesNum += nodesNumInTree;
 prevNodeNumInTree.push_back(nodesNumInTree + prevNodeNumInTree.back());
 int predictLeafIndex =
 ((*treeIter)->findLeaf(featureIndex2Value))->getIndex();
 predictLeafIndexes.push_back(predictLeafIndex);
 }

 one_hot_feature.resize(totalNodesNum, 0);

 for (int i = 0; i < predictLeafIndexes.size(); ++i)
 {
 one_hot_feature[prevNodeNumInTree[i] + predictLeafIndexes[i]] = 1;
 }
 }
 */

void XgboostModel::predict_leaf(const map<int, double>& featureIndex2Value,
        vector<float>& leafNodes)
{
    leafNodes.clear();

    int ithTree = 0;
    for (vector<Tree*>::iterator tree = this->trees.begin();
            tree != this->trees.end(); ++tree)
    {
        int predictLeafIndex =
                ((*tree)->findLeaf(featureIndex2Value))->getIndex();
        leafNodes.push_back(ithTree * getEachTreeNodesNum() + predictLeafIndex);
        ithTree++;
    }
}

vector<string> XgboostModel::calcDecisionPath(
        const map<int, double>& featureIndex2Value)
{
    vector<string> path;

    ostringstream stream;
    stream << predict_probability(featureIndex2Value);

    path.push_back("total score: " + stream.str());

    stream.str("");

    int i = 0;
    for (vector<Tree*>::iterator tree = trees.begin(); tree != trees.end();
            ++tree)
    {
        stream << i;
        path.push_back(
                "Tree " + stream.str() + ", leaf: "
                        + (*tree)->apply(featureIndex2Value));
        stream.str("");
        i++;
    }

    return path;
}

