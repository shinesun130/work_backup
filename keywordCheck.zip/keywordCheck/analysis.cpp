#include <stdio.h>
#include <stdlib.h>
#include <string>
#include <map>
#include <iostream>
#include <fstream>
#include <iterator>
#include <vector>
#include "touni.h"
#include "fromuni.h"
#include "analysis.h"
#include "normalize_str.h"
using namespace std;

int splitStr2Vec(char *src,vector<string> &vv,const char *ch);
map<unsigned short,unsigned short> complex2simple;//unicode��ʽ�ķ������Ӧ��
//map<string,int>����Դ��ͨ��װ�غ���
int loadMapResource(const char *file,map<string,int> &rMap,int type)
{
	ifstream fin;
	fin.open(file);
	if(!fin.is_open())
	{
		cout<<file<<" can not be opened!"<<endl;
		return -1;
	}
	char buffer[1024];
	char *head=NULL;
	char *tail=NULL;
	map<string,int>::iterator it;
	rMap.clear();
	while(!fin.eof())
	{
		if(fin.getline(buffer,1024).good()==false)
			break;
		if(type==1)//ֻ��1������
		{
			it=rMap.find(buffer);
			if(it==rMap.end())
				rMap.insert(map<string,int>::value_type(buffer,1));
		}
		else if(type==2)//��2������
		{
			head=strtok_r(buffer,"\t",&tail);
			if(head==NULL||tail==NULL)
				continue;
			it=rMap.find(head);
			if(it==rMap.end())
				rMap.insert(map<string,int>::value_type(head,atoi(tail)));
		}
	}
	fin.close();
	fprintf(stderr,"finish loading %s:%d\n",file,rMap.size());
	return 0;
}
/////////////////////////////////////////////////////////////////
//ͨ�õ�װ��map<string,string>�ͺ���
int loadStrStrMap(const char *file,map<string,string> &rMap)
{
	ifstream fin;
	fin.open(file);
	if(!fin.is_open())
	{
		cout<<file<<" can not be opened!"<<endl;
		return -1;
	}
	char buffer[1024];
	char *head=NULL;
	char *tail=NULL;
	map<string,string>::iterator it;
	rMap.clear();
	while(!fin.eof())
	{
		if(fin.getline(buffer,1024).good()==false)
			break;
		head=strtok_r(buffer,"\t",&tail);
		if(head==NULL||tail==NULL)
			continue;
		it=rMap.find(head);
		if(it==rMap.end())
			rMap.insert(map<string,string>::value_type(head,tail));
	}
	fin.close();
	fprintf(stderr,"finish loading %s --> %d\n",file,rMap.size());
	return 0;
}
/************************************************
 * date:2010.05.27
 * author:guibin
 * version:2.0
 * describe:ȥ�����еı�����
 * labelRate �������ܳ���
 * disturbRate ���ŷ��ı���
 * flags:00000001 �������ֵı��﷽ʽ��һ��
 *       00000010 Ĩ�����еı�����
 *       00000100 ȥ�����ּ���ı�����
 * ************************************************/
int rubout(const char *src,char *out,coreData *data,int rank)
{
	if(src == NULL || out == NULL)
		return -1;
	vector<string> ch;
	int chlen=0,len=0;
	int hanziNum = 0,borderHanzi = 0;//���ּ����ں��ֵı�������
	int frontType = 0;//��һ���ַ�������
	string temp,sret,front;
	char tmp[4]="";
	vector<int> chType;//�ַ����͵ı�ʶ
	map<string,int>::iterator it;
	map<string,string>::iterator sit;
	len=strlen(src);
	unsigned short uni[len+1];
	int num = bytesToUni(src, len, uni, len+1, "GBK");
	for(int i=0;i<num;i++)
	{
		memset(tmp,0,4);
		chlen = uniToBytes(uni+i,1,tmp,2,"GBK");
		if(chlen <= 0)
		{
			fprintf(stderr,"something wrong\n");
			continue;
		}
		tmp[chlen]='\0';
		temp = tmp;
		ch.push_back(temp);
		it = data->interpunction.find(ch[i]);
		if(it != data->interpunction.end())
		{
			if(frontType == 0)
				borderHanzi ++;
			chType.push_back(-1);//���Ϊ-1
			frontType = -1;
			continue;
		}
		it = data->hanzi.find(ch[i]);//����
		if(it != data->hanzi.end())
		{
			hanziNum ++;
			chType.push_back(0);//����Ϊ0
			frontType = 0;
			continue;
		}
		if(ch[i].length()==1)
		{
			frontType = 2;
			char c = ch[i].c_str()[0];
			if(c >= '0' && c <= '9')
				chType.push_back(1);//����
			else if((c >= 'a' && c <= 'z')||(c>='A' && c<= 'Z'))
				chType.push_back(2);//Ӣ��
			else
				chType.push_back(-1);//����δ��¼�ı�����
			continue;
		}
		frontType = 3;
		chType.push_back(3);//���������Ϊ3
	}
#ifdef DEBUG
	if(hanziNum > 0)
		fprintf(stderr,"border hanzi rate:%f\n",(borderHanzi*1.0/hanziNum));
#endif
	if(hanziNum == 0 || (borderHanzi*1.0/hanziNum) < 0.5)
	{
		strcpy(out,src);
		return 0;
	}
	num=ch.size();sret.clear();
	int conValueChNum=0;//����������Ӣ�ĺͺ��ֵĳ���
#ifdef DEBUG
	fprintf(stderr,"@ch:");
#endif
	for(int i=0;i<num && i<chType.size();i++)
	{
#ifdef DEBUG
		fprintf(stderr,"%s:%d\t",ch[i].c_str(),chType[i]);
#endif
		if(chType[i] == 0)//����
		{
			sret += ch[i];
			conValueChNum++;
		}
		else //����
		{
			if(chType[i] == -1)//��㣬��ѡ���Ա���
			{
				//���ֲ������ÿո����ָ��
				if(conValueChNum >= 2 && i>0 && ((chType[i-1]==0 && ch[i]!=" ")||chType[i-1]==2))
					sret += ch[i];
				conValueChNum = 0;
				continue;
			}
			if(chType[i] == 1)//���� ���ּз��е�����ȥ��
			{
				if(rank == 4 && ((i>=2 && chType[i-2]==0)||(i>=1 && chType[i-1]==0)) && ((i+1<num && chType[i+   1]==0)||(i+2<num && chType[i+2]==0)))
					continue;
				sret += ch[i];
				continue;
			}
			if(chType[i] == 2)//Ӣ�� ���ּз��е�Ӣ����ĸȥ��
			{
				conValueChNum ++;
				if(rank == 4 && ((i>=2 && chType[i-2]==0)||(i>=1 && chType[i-1]==0)) && ((i+   1<num && chType[i+1]==0)||(i+2<num && chType[i+2]==0)))
					continue;
				sret += ch[i];
				continue;
			}
			if(chType[i]==3)//����
				sret += ch[i];
		}
	}
	strcpy(out,sret.c_str());
	return 0;
}
///////////////////////////////////////////////////////////////
MATCHENTRY * loadMachine(const char *file,map<string,int> &wordSet,map<string,vector<COMBINE_INFO> > &combineWord)
{
	MATCHENTRY *machine_ww = NULL;
	if(!(machine_ww = strMatchInit(2)))
	{
		fprintf(stderr,"Init machine err!\n");
		return NULL;
	}
	ifstream fin;
	fin.open(file);
	if(!fin.is_open())
	{
		fprintf(stderr,"%s can not be opened!\n",file);
		return NULL;
	}
	char text[1024]="",word[1024]="";
	char *pos = NULL;
	int tLen = 0,iret = 0,vnum = 0;
	map<string,int>::iterator it,it2;
	vector<string> vv;
	COMBINE_INFO comInfo;
	vector<COMBINE_INFO> comVec;
	map<string,vector<COMBINE_INFO> >::iterator vit;
	while(!fin.eof())
	{
		if(fin.getline(text,1024).good()==false)
		  break;
		iret = TextNormalization(text,strlen(text),word,1024,11);
		if(iret < 0)
		{
			fprintf(stderr,"word:%s normailization failed!\n",text);
			strcpy(word,text);
		}
#ifdef DEBUG
		fprintf(stderr,"standard:%s\n",word);
#endif
		pos = strstr(word,":)");
		if(pos == NULL || pos == word)//+v ���������
		{
			it = wordSet.find(word);
			if(it == wordSet.end())
			{
				wordSet.insert(map<string,int>::value_type(string(word),1));
				Addword(word,0,machine_ww,0);
			}
			else
			{
				if(it->second == 0)
				  it->second = 1;
			}
		}
		else // if(strstr(word,"+") != NULL) ��ϴ�
		{
			splitStr2Vec(word,vv,":)");
			vnum = vv.size();
			if(vnum < 2)
			  continue;
			if(vnum == 2 && vv[0] == vv[1])//���� ������+��������������� �� A+A
			{
				it = wordSet.find(vv[0]);
				if(it == wordSet.end())
				  wordSet.insert(map<string,int>::value_type(vv[0],1));
				Addword(vv[0].c_str(),0,machine_ww,0);
				continue;
			}
			for(int i = 0;i < vnum;i++)
			{
				if(wordSet.find(vv[i]) == wordSet.end())
				{
					wordSet.insert(map<string,int>::value_type(vv[i],0));
					Addword(vv[i].c_str(),0,machine_ww,0);
				}
			}
			sort(vv.begin(),vv.end(),compareFun1);
			comInfo.wordvec = vv;
			vit = combineWord.find(vv[0]);
			if(vit != combineWord.end())
			{
				vit->second.push_back(comInfo);
			}
			else
			{
				comVec.clear();
				comVec.push_back(comInfo);
				combineWord.insert(map<string,vector<COMBINE_INFO> >::value_type(vv[0],comVec));
			}
		}//��ϴ�
	}
	fin.close();
	Prepare(0, machine_ww);
	return machine_ww;
}
///////////////////////////////////////////////////////////////
//����ԭʼ�ı�����һ���ı��ĵ��ַ���������
//flags == 1 ����������մ���,ǰ����ǰ��ķ������Ӧ����װ�����
int CreateChFormatIndex(const char *src,char *standard,map<int,string> &FormatIndex,int flags)
{
	if(src == NULL || standard == NULL)
	  return -1;
	int tLen1 = strlen(src),tLen2 = strlen(standard);
	if(tLen1 >= 65535 || tLen2 >= 65535)
	  return -1;
#ifdef DEBUG
	fprintf(stderr,"@complex:%s\n",standard);
#endif
	char tmp[4]="";
	bool fanflag = false;//�ı����Ƿ���ڷ�����
	unsigned short uni1[65536],uni2[65536];
	int ulen1 = 0, ulen2 = 0;
	ulen1 = bytesToUni(src,tLen1,uni1,tLen1+1,"GBK");
	ulen2 = bytesToUni(standard,tLen2,uni2,tLen2+1,"GBK");
	if(ulen1 != ulen2)
	{
#ifdef DEBUG
		fprintf(stderr,"src != standard,off-normal\n");
#endif
		return -2;
	}
	map<unsigned short,unsigned short>::iterator it;
	for(int i=0;i<tLen1;i++)
	{
		if(flags == 1)//��Ҫ���������Ӧ
		{
			it = complex2simple.find(uni2[i]);
			if(it != complex2simple.end())
			{
				uni2[i] = it->second;
				fanflag = true;
			}
		}
		if(uni1[i] != uni2[i])
		{
			memset(tmp,0,4);
			uniToBytes(uni1+i,1,tmp,2,"GBK");
			FormatIndex[i] = tmp;
		}
	}
	if(flags == 1 && fanflag == true)//��Ҫ��������ת��������ȷʵ���ڷ����ַ�
	{
		tLen2 = uniToBytes(uni2,ulen2,standard,ulen2*2+1,"GBK");
		if(tLen2 >= ulen2)
		  standard[tLen2] = '\0';
#ifdef DEBUG
		fprintf(stderr,"@simple:%s-->%d\n",standard,tLen2);
#endif
	}
	return 0;
}
////////////////////////////////////////////////////////////////////////////////
//20101229�ַ����ķ�����ת��
int transComplex2simple(char *src,int slen,char *out,int olen)
{
	if(src == NULL || out == NULL || olen < slen)
	  return -1;
	unsigned short uni[slen+1];
	int ulen = 0,tlen = 0;
	ulen = bytesToUni(src,slen,uni,slen+1,"GBK");
	if(ulen <= 0)//û�гɹ�ת�����ַ� 
	  return -2;
	for(int i=0;i<ulen;i++)
	{
		if(complex2simple.find(uni[i]) != complex2simple.end())
		  uni[i] = complex2simple[uni[i]];
	}
	tlen = uniToBytes(uni,ulen,out,olen,"GBK");
	if(tlen <= 0)
	  return -3;
	out[tlen] = '\0';
	return 0;
}
//////////////////////////////////////////////////////////////////////////////////
//���ط����ֵ������ֵĶ�Ӧ��unicode��ʽ
int loadComplex2simple(const char *path)
{
	if(path == NULL)
	  return -1;
	char file[1024]="";
	sprintf(file,"%s/simplified_complex.txt",path);
	ifstream fin;
	fin.open(file);
	if(!fin.is_open())
	{
		fprintf(stderr,"%s can not be opened!\n",file);
		return -2;
	}
	char buf[1024]="";
	char *first = NULL;
	char *second = NULL;
	unsigned short uni1[4],uni2[4];
	int iret1 = 0,iret2 = 0;
	while(!fin.eof())
	{
		if(fin.getline(buf,1024).good()==false)
		  break;
		first = strtok_r(buf,"\t",&second);
		if(first == NULL || second == NULL)
		  continue;
		iret1 = bytesToUni(first,strlen(first),uni1,strlen(first)+1,"GBK");
		iret2 = bytesToUni(second,strlen(second),uni2,strlen(second)+1,"GBK");
		if(iret1!=1 || iret2!=1)
		  continue;
		complex2simple[uni1[0]] = uni2[0];
	}
	fprintf(stderr,"finish loading complex2simple:%d\n",complex2simple.size());
	return 0;
}
////////////////////////////////////////////////////////////////////////////
//�ؼ���ʶ����
int findBlackWord(char *text,coreData *cdata,vector<pair<string,int> > &watchWord)
{
	if(text == NULL || cdata->blackList == NULL)
	  return -1;
	FindAllUntilNull(text,0,cdata->blackList);
	watchWord.clear();
	pair<string,int> pp;
	map<string,int>::iterator it;
	char *pos = NULL;
	char *word = NULL;
	char buf[1024]="";
	char breakpointCh = '\0';
	int uLen = 0,tLen = strlen(text);
	int unipos = 0;
	unsigned short uni[tLen+1],tmpuni[1024];
	uLen = bytesToUni(text,tLen,uni,tLen+1,"GBK");
	for(int i = 0; i< cdata->blackList->wordsnum; i++)
	{
		if(cdata->blackList->wordlist[i].findnum > 0)
		{
			word = (char*)(cdata->blackList->wordlist[i].word);
			pp.second = cdata->blackList->wordlist[i].findnum;
			cdata->blackList->wordlist[i].findnum = 0;
			if(word == NULL)
			  continue;
			if(tLen < 1024)
			  strcpy(buf,text);
			else
			  strncpy(buf,text,1023);
			pos = strstr(buf,word);
			if(pos == NULL)
			  continue;

			breakpointCh = *pos;
			*pos = '\0';
			unipos = bytesToUni(buf,strlen(buf),tmpuni,1024,"GBK");
			*pos = breakpointCh;
			if(unipos >= 1 && unipos < uLen)
			{
				if(tmpuni[unipos-1] != uni[unipos-1])
				{
					char single[4]="";
					uniToBytes(tmpuni+unipos-1,1,single,2,"GBK");
#ifdef DEBUG
					fprintf(stderr,"%s split:%s is err:tmpuni[%d]:%s\n\n",text,word,unipos-1,single);
#endif
					continue;
				}
			}
			pp.first = word;
			watchWord.push_back(pp);
		}
	}
	sort(watchWord.begin(),watchWord.end(),compareFun2);
	return 0;
}
///////////////////////////////////////////////////////////////////
//������1
bool compareFun1(const string &str1,const string &str2)
{
	return str1 > str2;
}
///////////////////////////////////////////////////////////////////
//������2 
bool compareFun2(const pair<string,int> &pp1,const pair<string,int> &pp2)
{
	return pp1.first > pp2.first;
}
///////////////////////////////////////////////////////////////////
//�ַ������ָ��
int splitStr2Vec(char *src,vector<string> &vv,const char *ch)
{
	vv.clear();
	if(src == NULL)
	  return -1;
#ifdef DEBUG
	cerr<<"src:"<<src<<endl;
#endif
	char *body = src;
	char *head = NULL;
	char *tail = NULL;
#ifdef DEBUG
	cerr<<"split:";
#endif
	while(body != NULL)
	{
		head = strtok_r(body,ch,&tail);
		if(head != NULL)
		{
#ifdef DEBUG
			cerr<<head<<"\t";
#endif
			vv.push_back(head);
		}
		else
		  break;
		if(tail == NULL)
		  break;
		body = tail;
	}
#ifdef DEBUG
	cerr<<endl;
#endif
	return 0;
}
/////////////////////////////////////////////////////////////////////////////
//20110419 �ַ�����һ������
int TextNormalization(char *src,int srcLen,char *out,int outLen,int flag)
{
	if(src == NULL || out == NULL)
	  return -1;
	if(srcLen >= 65534 && strlen(src) >= 65534)
	{
		src[65534] = '\0';
		srcLen = 65534;
	}
	int iret = 0;
	unsigned char control = 0;
	if(testbit(flag,0))
	  control += 4;
	if(testbit(flag,1))
	  control += 2;
	char text[65536] = "";
	//��Сд��ȫ���ת������
	if(control > 0)
	  iret = normalize_str(src,srcLen,text,srcLen+1,control);
	if(iret <= 0)//��һ��ʧ�� || ����Ҫ��Сд�����ת��
	  strcpy(text,src);
	if(testbit(flag,3))//������
	  transComplex2simple(text,strlen(text),out,outLen);
	else
	{
		strcpy(out,text);
		outLen = strlen(out);
	}
	return 0;
}

int KeywordCheck(string content,coreData *cdata)
{
	if(content.size() < 2)
	  return 0;
	char text[8192],bak[8192];
	strcpy(bak,content.c_str());
	int iret =  TextNormalization(bak,content.length(),text,8192,11);
	if(iret < 0)
	{
		strcpy(text,content.c_str());
	}

	vector<pair<string,int> > watchWord;
	iret = findBlackWord(text,cdata,watchWord);
	int watchNum = watchWord.size();
	int combineNum = 0,vsize = 0;
	int coverNum = 0,groupWordnum = 0;
	map<string,int>::iterator lit;
	map<string,vector<COMBINE_INFO> >::iterator vit;
	if(watchNum > 0)
	{
		for(int i=0;i<watchNum;i++)
		{
			lit = cdata->wordSet.find(watchWord[i].first);
			if(lit != cdata->wordSet.end() && lit->second == 1)
			  return 1;
			else //��Ϲؼ��ʼ��
			{
				vit = cdata->combineWord.find(watchWord[i].first);
				if(vit != cdata->combineWord.end())
				{
					combineNum = vit->second.size();
					for(int ci = 0;ci < combineNum;ci++)//�ôʵĶ������Ⱥ��
					{
						coverNum = 0;
						groupWordnum = vit->second[ci].wordvec.size();
						for(int vi = 1;vi<groupWordnum;vi++)
						{
							for(int j=i+1;j<watchNum;j++)
							{
								if(watchWord[j].first == vit->second[ci].wordvec[vi])
								{
									coverNum ++;
									break;
								}
							}
							if(coverNum < vi)//�Ѿ�Ѱ��ʧ��
							  break;
						}
						if((coverNum+1) == groupWordnum)//�ҵ���ϴ�
						{
							return 2;
						}
					}

				}
			}
		}
	}
	return 0;
}
