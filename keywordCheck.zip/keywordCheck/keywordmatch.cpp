#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <vector>
#include <string>
#include <algorithm>
#include "analysis.h"
#include "strmatch.h"
#include "StringTool.h"

using namespace std;

coreData * loadCoreData(const char *path);

int main(int argc,char* argv[])
{
	if(argc != 4)
	{
		cerr<<"Usage:<resource> <infile> <outfile>"<<endl;
		return -1;
	}
    
	coreData *data = loadCoreData(argv[1]);
	if(data == NULL)
	{
		cerr<<"Load resource failed!"<<endl;
		return -1;
	}
    
	ifstream fin(argv[2]);
	if(!fin.is_open())
	{
		cerr<<"Can't open file "<<argv[2]<<endl;
		return -1;
	}
	ofstream fout(argv[3]);
	if(!fout.is_open())
	{
		cout<<"Can't open "<<argv[3]<<endl;
		return -1;
	}
	string line;
	while(getline(fin,line))
	{
		if(line.size() == 0)
		  continue;
		vector<string> vecData = StringTool::SplitString(line.c_str(),"\t");
		if(vecData.size() < 3)
		  continue;
		vector<string> appvec = StringTool::SplitString(vecData[2].substr(0,200),"|");
		if(data->appWhiteList.find(appvec[3]) != data->appWhiteList.end())
		  continue;
		int num = atoi(vecData[1].c_str());
		if(num > 10 && KeywordCheck(vecData[0],data) > 0)
		{
            fout<<line<<endl;
		}
	}
	fin.close();
	return 0;
}

coreData * loadCoreData(const char *path)
{
	coreData *data = new coreData;
	fprintf(stderr,"begin coreData loading!\n");
	char file[1024] = "";
	int iret = 0;
    
	//���庺�ֱ�
	sprintf(file,"%s/simpleCh.txt",path);
	iret = loadMapResource(file,data->hanzi,1);
	if(iret != 0)
	{
		fprintf(stderr,"%s Init failed!\n",file);
		return NULL;
	}

	//�����ű�
	sprintf(file,"%s/interpunction.txt",path);
	iret = loadMapResource(file,data->interpunction,1);
	if(iret != 0)
	{
		fprintf(stderr,"%s Init failed!\n",file);
		return NULL;
	}

	//������
	sprintf(file,"%s/blackList.txt",path);
	data->blackList = loadMachine(file,data->wordSet,data->combineWord);
	if(data->blackList == NULL)
	{
		fprintf(stderr,"%s Init failed!\n",file);
		return NULL;
	}

	//app������
	sprintf(file,"%s/appWhiteList.txt",path);
	iret = loadMapResource(file,data->appWhiteList,1);
	if(iret < 0)
	{
		fprintf(stderr,"%s Init failed!\n",file);
		return NULL;
	}

	fprintf(stderr,"coreData loading sucess!\n\n");
	return data;
}
