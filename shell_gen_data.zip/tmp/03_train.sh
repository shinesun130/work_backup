HOT_WEIBO_MODEL_TABLE_NAME='huinan1_hot_weibo_model'
HOT_WEIBO_TRAIN_TABLE_NAME='binbin7_hot_weibo_train_binary'
HOT_WEIBO_TEST_TABLE_NAME='binbin7_hot_weibo_train_binary_test'

function create_partition_table_without_row_format(){
	    TABLE=$1
		FIELDS=$2
		PARTITIONS=$3
		echo "to create internal partition table $TABLE"
		odpscmd -e "
		CREATE TABLE IF NOT EXISTS $TABLE ($FIELDS) PARTITIONED BY ($PARTITIONS);
"
}

function create_partition(){
	    TABLE=$1
		PARTITIONS=$2
		echo "to create table partition $TABLE $PARTITIONS"
		odpscmd -e "
		ALTER TABLE $TABLE ADD IF NOT EXISTS PARTITION($PARTITIONS);
"
}

function ps_train(){
	    version_part=$1
		test_version=$2
		create_partition_table_without_row_format "$HOT_WEIBO_MODEL_TABLE_NAME" "key bigint, value double" "version string"
		version_test_part=inter_weight_50_$version_part
		create_partition "$HOT_WEIBO_MODEL_TABLE_NAME" "version='$version_test_part'"
		odpscmd -e "
		param_server -i ${HOT_WEIBO_TRAIN_TABLE_NAME}/version=$version_part,${HOT_WEIBO_TEST_TABLE_NAME}/version=$test_version -o $HOT_WEIBO_MODEL_TABLE_NAME/version=$version_test_part -a Owlqn -extrastr {\"worker_num\":100,\"worker_memory\":18000,\"server_num\":150,\"server_memory\":4096,\"worker_high_water_mark\":\"15\",\"worker_low_water_mark\":\"5\",\"checkpoint.dir\":\"/20181021/huinan1_hot_mblog_${version_test_part}_checkpoint_path/\",\"algorithm.class.conf\":\"{\\\"l2_weight\\\":1.5,\\\"tolerance\\\":1.0E-5,\\\"model_size\\\":3345752,\\\"l1_weight\\\":0.5,\\\"iteration_limit\\\":50,\\\"feature_columns\\\":[2],\\\"label_columns\\\":[3,4],\\\"enable_train_auc\\\":true,\\\"enable_test_auc\\\":true}\"};
"
}

cate_id='all_cates'
np_rate='original'
s_dt=$1
e_dt=$2
#train_name=${s_dt}'_'${e_dt}'_'${cate_id}'_'${np_rate}'_clk_0815_feed'
#train_version=20181011_20181014_all_cates_original_clk_1022_feed
#train_version=20181021_20181025_all_cates_original_clk_1023_feed_clean_v5
#train_version=20181020_20181113_all_cates_original_clk_1015_feed_beauty
#train_version=20181009_20181026_all_cates_original_clk_1105_feed_click_num_beauty
train_version=20181009_20181028_all_cates_original_clk_1108_feed_inter_weight
#test_version=20181027_20181028_all_cates_original_clk_1105_feed_click_num_beauty
test_version=20181103_20181104_all_cates_original_clk_1108_feed_inter_weight
#train_version=20180920_20181014_all_cates_original_clk_1022_feed_ori
#test_version=20181015_20181015_all_cates_original_clk_1022_feed_test
ps_train $train_version $test_version 


