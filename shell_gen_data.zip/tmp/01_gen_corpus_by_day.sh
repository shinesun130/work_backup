#!/bin/sh
HOT_WEIBO_READ_TABLE_NAME='binbin7_self3_hot_weibo_read'
HOT_WEIBO_READ_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_read'

HOT_WEIBO_ACTION_TABLE_NAME='binbin7_self3_hot_weibo_action'
HOT_WEIBO_ACTION_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_action'

HOT_WEIBO_CLICK_TABLE_NAME='binbin7_self3_hot_weibo_click'
HOT_WEIBO_CLICK_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_click'

HOT_WEIBO_CLICK_RATE_TABLE_NAME='binbin7_self3_hot_weibo_click_rate'
HOT_WEIBO_CLICK_RATE_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_click_rate'

HOT_WEIBO_CLICK_RATE_HOUR_TABLE_NAME='binbin7_self3_hot_weibo_click_rate_hour'
HOT_WEIBO_CLICK_RATE_HOUR_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_click_rate_hour'

HOT_WEIBO_CLICK_RATE_24_HOUR_TABLE_NAME='binbin7_self3_hot_weibo_click_rate_24_hour'
HOT_WEIBO_CLICK_RATE_24_HOUR_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_click_rate_24_hour'

HOT_WEIBO_ABILITY_TABLE_NAME='binbin7_self3_hot_weibo_ability'
HOT_WEIBO_ABILITY_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_ability'

HOT_WEIBO_INTE_TABLE_NAME='binbin7_self3_hot_weibo_inte'
HOT_WEIBO_INTE_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_inte'

HOT_WEIBO_INFO_TABLE_NAME='binbin7_self3_hot_weibo_info'
HOT_WEIBO_INFO_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_info'

HOT_WEIBO_CORPUS_TABLE_NAME='binbin7_self3_hot_weibo_corpus_24'
HOT_WEIBO_CORPUS_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_corpus_24'


#HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME='binbin7_self3_hot_weibo_corpus_24_data_clean'

HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME='binbin7_hot_mblog_corpus_24_data_clean'
HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_self3_hot_weibo_corpus_24_data_clean/'

function create_external_table(){
    TABLE=$1
    FIELDS=$2
    DIR=$3
    echo "to create external table $TABLE"
    odpscmd -e "
        DROP TABLE $TABLE;
        CREATE EXTERNAL TABLE IF NOT EXISTS $TABLE ($FIELDS)  
        ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'  
        location '$DIR'; "
}

function create_partition_table_without_row_format(){
    TABLE=$1
    FIELDS=$2
    PARTITIONS=$3
    echo "to create internal partition table $TABLE" 
    odpscmd -e "
        CREATE TABLE IF NOT EXISTS $TABLE ($FIELDS)  
        PARTITIONED BY ($PARTITIONS);
    "
}

function create_table_like_other_table(){
    TABLE_TO_CREATE=$1
    TABLE_SOURCE=$2
    DIR=$3
    echo "to create table $TABLE_TO_CREATE like table $TABLE_SOURCE"
    odpscmd -e "CREATE TABLE IF NOT EXISTS $TABLE_TO_CREATE LIKE $TABLE_SOURCE;"
    echo "created table $TABLE_TO_CREATE"
}

function get_latest_partition(){
    table_name=$1
    dt_name=$2
    y_dt_name=`date +%Y%m%d -d "$dt_name 1 days ago"`
    parts=`odpscmd -e "show partitions $table_name"`
    dt_max='20160101'
    for dt in ${parts[@]};
    do
        dt_r=`echo $dt | awk -F'=' '{print $2}'`
		if [ ${#dt_r} -ne 8 ];
		then
			continue
		fi
        if [ $dt_r -ge $y_dt_name ];
        then
            break
        else
            dt_max=$dt_r
        fi
    done
    echo $dt_max
}

function create_external_partition_table(){
    TABLE=$1
    FIELDS=$2
    PARTITIONS=$3
    DIR=$4
    echo "to create external partition table $TABLE" 
    odpscmd -e "
        CREATE EXTERNAL TABLE IF NOT EXISTS $TABLE ($FIELDS)  
        PARTITIONED BY ($PARTITIONS)
        ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'  
        location '$DIR'; 
                    "
}

function create_partition(){
    TABLE=$1
    PARTITIONS=$2
    echo "to create table partition $TABLE $PARTITIONS"
    odpscmd -e "
        ALTER TABLE $TABLE ADD IF NOT EXISTS PARTITION($PARTITIONS);
                    "
}

function create_hot_weibo_read_table(){
    read_fields='mid string, duration string, uid string, born string, gender string, area_id string,
                 user_tags string, doc_tags string, 
                 author_id string, expo_time string, network_type string,  
                 recommend_source string, recommend_base_level string, category string, 
                 first_level_inte_weight string,
                 second_level_inte_weight string, third_level_inte_weight string, 
                 effect_weight string,
                 pic_weight string, article_weight string, video_weight string,
                 obj_weight string, user_weight string, 
                 ret_num string, cmt_num string, like_num string,
                 ret_num_recent string, cmt_num_recent string, like_num_recent string,
                 total_read_num string, expose_num string, act_num string, 
                 inter_act_num string, expose_num_recent string, act_num_recent string,  
                 inter_act_num_recent string, hot_ret_num string, hot_cmt_num string, 
                 hot_like_num string, hot_ret_num_recent string, hot_cmt_num_recent string,
                 hot_like_num_recent string, article_read_num string, miaopai_view_num string,
                 time_born_gender_action_list string, extend string, extend2 string, extend3 string'
    read_partitions='dt string, hour string'
    create_partition_table_without_row_format "$HOT_WEIBO_READ_TABLE_NAME" \
                                    "$read_fields" "$read_partitions" \
                                    "$HOT_WEIBO_READ_TABLE_LOCATION"
}

function create_hot_weibo_action_table(){
    action_fields='uid string, mid string, target_id string, action string, isautoplay string'
    action_partitions='dt string, hour string'
    create_partition_table_without_row_format "$HOT_WEIBO_ACTION_TABLE_NAME" \
                                    "$action_fields" "$action_partitions" \
                                    "$HOT_WEIBO_ACTION_TABLE_LOCATION"
}

function create_hot_weibo_click_table(){
    click_fields='is_click string, actions string, isautoplay string, 
                 mid string, duration string, uid string, born string, gender string, area_id string,
                 user_tags string, doc_tags string, 
                 author_id string, expo_time string, network_type string,  
                 recommend_source string, recommend_base_level string, category string, 
                 first_level_inte_weight string,
                 second_level_inte_weight string, third_level_inte_weight string, 
                 effect_weight string,
                 pic_weight string, article_weight string, video_weight string,
                 obj_weight string, user_weight string, 
                 ret_num string, cmt_num string, like_num string,
                 ret_num_recent string, cmt_num_recent string, like_num_recent string,
                 total_read_num string, expose_num string, act_num string, 
                 inter_act_num string, expose_num_recent string, act_num_recent string,  
                 inter_act_num_recent string, hot_ret_num string, hot_cmt_num string, 
                 hot_like_num string, hot_ret_num_recent string, hot_cmt_num_recent string,
                 hot_like_num_recent string, article_read_num string, miaopai_view_num string,
                 time_born_gender_action_list string, extend string, extend2 string, extend3 string'
    click_partitions='dt string, hour string'
    create_partition_table_without_row_format "$HOT_WEIBO_CLICK_TABLE_NAME" \
                                    "$click_fields" "$click_partitions" \
                                    "$HOT_WEIBO_CLICK_TABLE_LOCATION"
}

function create_hot_weibo_click_rate_table(){
    click_rate_fields='mid string, expo string, click string, rate string'
    click_rate_partitions='dt string'
    create_partition_table_without_row_format "$HOT_WEIBO_CLICK_RATE_TABLE_NAME" \
                                    "$click_rate_fields" "$click_rate_partitions" \
                                    "$HOT_WEIBO_CLICK_RATE_TABLE_LOCATION"
}

function create_hot_weibo_click_rate_hour_table(){
    click_rate_hour_fields='mid string, expo string, click string, rate string'
    click_rate_hour_partitions='dt string, hour string'
    create_partition_table_without_row_format "$HOT_WEIBO_CLICK_RATE_HOUR_TABLE_NAME" \
                                    "$click_rate_hour_fields" "$click_rate_hour_partitions" \
                                    "$HOT_WEIBO_CLICK_RATE_HOUR_TABLE_LOCATION"
}

function create_hot_weibo_click_rate_24_hour_table(){
    click_rate_hour_fields='mid string, expo string, click string, rate string'
    click_rate_hour_partitions='dt string, hour string'
    create_partition_table_without_row_format "$HOT_WEIBO_CLICK_RATE_24_HOUR_TABLE_NAME" \
                                    "$click_rate_hour_fields" "$click_rate_hour_partitions" \
                                    "$HOT_WEIBO_CLICK_RATE_24_HOUR_TABLE_LOCATION"
}

function create_hot_weibo_ability_table(){
    ability_fields='uid string, category string, tag string, obj string'
    create_external_table "$HOT_WEIBO_ABILITY_TABLE_NAME" \
                                    "$ability_fields" \
                                    "$HOT_WEIBO_ABILITY_TABLE_LOCATION"
}

function create_hot_weibo_inte_table(){
    inte_fields='uid string, category string, tag string, obj string'
    create_external_table "$HOT_WEIBO_INTE_TABLE_NAME" \
                                    "$inte_fields"  \
                                    "$HOT_WEIBO_INTE_TABLE_LOCATION"
}

function create_hot_weibo_info_table(){
    info_fields="
            mid string, text_len string, created_at string, \
            pic_num string, gif_num string, long_pic_num string, \
            title_num string, at_num string, emoji_num string, \
            topic_num string, puncs_num string, eng_num string, \
            url_num string, article_num string, video_num string, obj_num string, \
            ret_num string, cmt_num string, like_num string, \
            content_category string, content_tag string, content_obj string, \
            user_uid string, user_category string, user_tag string, user_obj string, \
            user_c_level string, user_level string, verified_type string, \
            fans_count string, friends_count string, gender string, \
            city string, location string, text string
            "
    create_external_table "$HOT_WEIBO_INFO_TABLE_NAME" \
                                    "$info_fields"  \
                                    "$HOT_WEIBO_INFO_TABLE_LOCATION"
}

function create_hot_weibo_corpus_table(){
    corpus_fields='is_click string, actions string, isautoplay string, 
                 mid string, duration string, uid string, born string, gender string, area_id string,
                 user_tags string, doc_tags string, 
                 author_id string, expo_time string, network_type string,  
                 recommend_source string, recommend_base_level string, category string, 
                 first_level_inte_weight string,
                 second_level_inte_weight string, third_level_inte_weight string, 
                 effect_weight string,
                 pic_weight string, article_weight string, video_weight string,
                 obj_weight string, user_weight string, 
                 ret_num string, cmt_num string, like_num string,
                 ret_num_recent string, cmt_num_recent string, like_num_recent string,
                 total_read_num string, expose_num string, act_num string, 
                 inter_act_num string, expose_num_recent string, act_num_recent string,  
                 inter_act_num_recent string, hot_ret_num string, hot_cmt_num string, 
                 hot_like_num string, hot_ret_num_recent string, hot_cmt_num_recent string,
                 hot_like_num_recent string, article_read_num string, miaopai_view_num string,
                 all_group_msg string, hour_group_msg string, extend string,
                 extend2 string, extend3 string
                 '
    corpus_partitions='dt string, hour string'
    create_partition_table_without_row_format "$HOT_WEIBO_CORPUS_TABLE_NAME" \
                                    "$corpus_fields"  "$corpus_partitions"\
                                    "$HOT_WEIBO_CORPUS_TABLE_LOCATION"
}

function gen_hot_weibo_read_with_dura_table(){
    read_dt=$1
    read_hour=$2
    create_hot_weibo_read_table
    read_part="dt=$read_dt, hour=$read_hour"
    create_partition $HOT_WEIBO_READ_TABLE_NAME "$read_part"
    odpscmd -e "
        add file extract_expo_msg.py;
        insert overwrite table 
            $HOT_WEIBO_READ_TABLE_NAME partition($read_part) 
        select
            transform(b.*, a.durations)
            using 
                'python2.6 extract_expo_msg.py'
            as( mid, duration, uid, born, gender, area_id, 
                user_tags, doc_tags, author_id, time, network_type,
                recommend_source, recommend_base_level, category, 
                first_level_inte_weight, second_level_inte_weight, 
                third_level_inte_weight, effect_weight, pic_weight, 
                article_weight, video_weight, obj_weight, user_weight, 
                ret_num, cmt_num, like_num, 
                ret_num_recent, cmt_num_recent, like_num_recent, 
                total_read_num, expose_num, act_num, inter_act_num, 
                expose_num_recent, act_num_recent,  inter_act_num_recent, 
                hot_ret_num, hot_cmt_num, hot_like_num, 
                hot_ret_num_recent, hot_cmt_num_recent, hot_like_num_recent,
                article_read_num, miaopai_view_num, time_born_gender_action_list, extend )
        from 
        (
            select
                uid, mid, concat_ws(',', collect_set( duration )) as durations
            from
                ods_tblog_client_read_log 
            where
                dt='$read_dt' and hour='$read_hour' 
            group by
                uid, mid
        ) a
        join
            ods_tblog_hotmblog_exposure_storage b
        on
            b.dt='$read_dt' and b.hour='$read_hour' and
            a.uid=b.uid  and a.mid=b.id
    "
}


function gen_hot_weibo_read_day_table(){
    read_dt=$1
    create_hot_weibo_read_table
    read_part="dt='total_$read_dt', hour='00'"
    create_partition $HOT_WEIBO_READ_TABLE_NAME "$read_part"
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_READ_TABLE_NAME partition($read_part) 
        select
            a.mid, avg(a.duration), a.group_id,
            a.uid, a.from_val, a.rid
        from 
            ods_tblog_client_read_log a
        join
            ods_tblog_expo b
        on 
            a.uid=b.uid 
            and cast(a.duration as int) > 200
            and a.dt=$read_dt 
            and b.dt=$read_dt
            and b.appid=6
            and b.interface_id=900
        where 
            find_in_set(a.mid, b.mid_list) > 0 
            and (find_in_set('containerid=>102803', b.extend2) > 0  
                or find_in_set('containerid=>230509', b.extend2) > 0 )
        group by 
            a.mid, a.group_id, a.uid, a.from_val, a.rid
    "
}

function update_duration_hot_weibo_read_table(){
    read_dt=$1
    read_hour=$2
    read_part="dt=$read_dt, hour=$read_hour"
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_READ_TABLE_NAME partition($read_part) 
        select
            a.mid, avg(a.duration), a.group_id,
            a.uid, a.from_val, a.rid
        from 
            ods_tblog_client_read_log a
        join
            $HOT_WEIBO_CLICK_TABLE_NAME b
        on 
            a.uid=b.uid 
            and a.mid=b.mid
            and a.dt=$read_dt and a.hour=$read_hour 
            and b.dt=$read_dt and b.hour=$read_hour
        group by 
            a.mid, a.group_id, a.uid, a.from_val, a.rid
    "
}


function gen_hot_weibo_action_day_table(){
    action_dt=$1
    create_hot_weibo_action_table
    action_part="dt='total_$action_dt', hour='00'"
    create_partition $HOT_WEIBO_ACTION_TABLE_NAME "$action_part"
    odpscmd -e "
        add file extract_mid.py;
        insert overwrite table 
            $HOT_WEIBO_ACTION_TABLE_NAME partition($action_part) 
        select
            a.*
        from 
            (
                select
                    transform(uid, target_id, action, extend)  
                    using 'python2.6 extract_mid.py'
                    as (n_uid, n_mid, n_target_id, n_action)
                from 
                    ods_wls_encode_bhv
                where
                    dt=$action_dt
            )a
                
        join
            $HOT_WEIBO_READ_TABLE_NAME b
        on 
            a.n_uid=b.uid 
            and a.n_mid=b.mid
            and b.dt=$action_dt
    "
}

function gen_hot_weibo_click_day_table(){
    click_dt=$1
    create_hot_weibo_click_table
    click_part="dt='total_$click_dt', hour='00'"
    create_partition $HOT_WEIBO_CLICK_TABLE_NAME "$click_part"
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_CLICK_TABLE_NAME partition($click_part) 
        select
            distinct a.uid, a.mid, a.duration, CASE WHEN b.mid is not NULL THEN 1 ELSE 0 END
        from 
        (
            select
                *
            from
                $HOT_WEIBO_READ_TABLE_NAME
            where
                dt=$click_dt
        )a
        left outer join
            $HOT_WEIBO_ACTION_TABLE_NAME b
        on 
            a.uid=b.uid 
            and a.mid=b.mid
            and b.dt=$click_dt 
    "
}

function gen_hot_weibo_click_rate_table(){
    click_rate_dt=$1
    create_hot_weibo_click_rate_table
    click_rate_part="dt=$click_rate_dt"
    create_partition $HOT_WEIBO_CLICK_RATE_TABLE_NAME "$click_rate_part"
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_CLICK_RATE_TABLE_NAME partition($click_rate_part) 
        select
            b.mid, b.expo, b.click, b.click/b.expo
        from 
            (
                select
                    mid, 
                    count(is_click) as expo,
                    sum(is_click) as click 
                from
                    $HOT_WEIBO_CLICK_TABLE_NAME
                where
                    dt = $click_rate_dt
                group by
                    mid
            )b
    "
}

function gen_hot_weibo_click_rate_hour_table(){
    click_rate_dt=$1
    click_rate_hour=$2
    create_hot_weibo_click_rate_hour_table
    click_rate_part="dt=$click_rate_dt, hour=$click_rate_hour"
    create_partition $HOT_WEIBO_CLICK_RATE_HOUR_TABLE_NAME "$click_rate_part"
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_CLICK_RATE_HOUR_TABLE_NAME partition($click_rate_part) 
        select
            b.mid, b.expo, b.click, b.click/b.expo
        from 
            (
                select
                    mid, 
                    count(is_click) as expo,
                    sum(is_click) as click 
                from
                    $HOT_WEIBO_CLICK_TABLE_NAME
                where
                    dt = $click_rate_dt and hour=$click_rate_hour
                group by
                    mid
            )b
    "
}

function gen_hot_weibo_click_rate_24_hour_table(){
    click_rate_dt=$1
    click_rate_hour=$2
    create_hot_weibo_click_rate_24_hour_table
    click_rate_part="dt=$click_rate_dt, hour=$click_rate_hour"
    create_partition $HOT_WEIBO_CLICK_RATE_24_HOUR_TABLE_NAME "$click_rate_part"
    click_begin_day=`date +%Y%m%d%H -d "$click_rate_dt $click_rate_hour -1 days"`
    click_begin_dt=${click_begin_day:0:8}
    click_begin_hour=${click_begin_day:8:2}
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_CLICK_RATE_24_HOUR_TABLE_NAME partition($click_rate_part) 
        select
            a.mid, b.total_expo, b.total_click, b.total_click/b.total_expo
        from 
        (
            select
                mid
            from
                $HOT_WEIBO_CLICK_RATE_HOUR_TABLE_NAME
            where
                dt = $click_rate_dt and hour = $click_rate_hour
        )a
        left outer join
        (
            select
                mid, 
                sum(expo) as total_expo,
                sum(click) as total_click 
            from
                $HOT_WEIBO_CLICK_RATE_HOUR_TABLE_NAME
            where
                (dt = $click_rate_dt and hour < $click_rate_hour) \
                or (dt = $click_begin_dt and hour >= $click_begin_hour)
            group by
                mid
        )b
        on a.mid=b.mid
    "
}

function gen_hot_weibo_ability_table(){
    ability_dt=$1
    create_hot_weibo_ability_table
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_ABILITY_TABLE_NAME 
        select
            distinct substr(a.from_id, 6) as uid, a.category, b.tag, c.obj
        from 
            (
                select 
                    from_id, concat_ws(',', collect_set(\
                            concat_ws('@', to_id, cast(weight as string)))) as category
                from 
                    mds_user_ability_category
                where
                    dt=$ability_dt
                group by from_id
            )a
        left outer join
            (
                select 
                    from_id, concat_ws(',', collect_set(\
                            concat_ws('@', to_id, cast(weight as string)))) as tag
                from 
                    mds_user_ability_tag
                where
                    dt=$ability_dt
                group by from_id
            )b
        on 
            a.from_id=b.from_id
        left outer join
            (
                select 
                    from_id, concat_ws(',', collect_set(\
                            concat_ws('@', to_id, cast(weight as string)))) as obj
                from 
                    mds_user_ability_obj
                where
                    dt=$ability_dt
                group by from_id
            )c
        on 
            a.from_id=c.from_id
    "
}

function gen_hot_weibo_inte_table(){
    inte_dt=$1
    create_hot_weibo_inte_table
    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_INTE_TABLE_NAME 
        select
            distinct substr(a.from_id, 6) as uid, a.category, b.tag, c.obj
        from 
            (
                select 
                    from_id, concat_ws(',', collect_set(\
                            concat_ws('@', to_id, cast(weight as string)))) as category
                from 
                    mds_user_inte_category
                where
                    dt=$inte_dt
                group by from_id
            )a
        left outer join
            (
                select 
                    from_id, concat_ws(',', collect_set(\
                            concat_ws('@', to_id, cast(weight as string)))) as tag
                from 
                    mds_user_inte_tag
                where
                    dt=$inte_dt
                group by from_id
            )b
        on 
            a.from_id=b.from_id
        left outer join
            (
                select 
                    from_id, concat_ws(',', collect_set(\
                            concat_ws('@', to_id, cast(weight as string)))) as obj
                from 
                    mds_user_inte_obj
                where
                    dt=$inte_dt
                group by from_id
            )c
        on 
            a.from_id=c.from_id
    "
}

function gen_hot_weibo_info_table(){
    create_hot_weibo_info_table
    odpscmd -e "
        set mapred.reduce.tasks=100;
        add file category_ability_info;
        add file get_status.py;
        insert overwrite table 
            $HOT_WEIBO_INFO_TABLE_NAME 
        select
            base_info.mid, base_info.text_len, base_info.created_at, \
            base_info.pic_num, base_info.gif_num, base_info.long_pic_num, \
            base_info.title_num, base_info.at_num, base_info.emoji_num, \
            base_info.topic_num, base_info.puncs_num, base_info.eng_num, \
            base_info.url_num, base_info.article_num, base_info.video_num, base_info.obj_num, \
            base_info.ret_num, base_info.cmt_num, base_info.like_num, \
            base_info.content_category, base_info.content_tag, base_info.content_obj, \
            base_info.uid, user_abi.category, user_abi.tag, user_abi.obj, \
            user_label.label, base_info.user_level, base_info.verified_type, base_info.fans_count, \
            base_info.friends_count, base_info.gender, base_info.city, base_info.location, base_info.text \
        from
        (
            select
                transform(read_table.mid) 
                using 'python2.6 get_status.py category_ability_info' 
                as ( \
                    mid, text_len, created_at, \
                    pic_num, gif_num, long_pic_num, \
                    title_num, at_num, emoji_num, \
                    topic_num, puncs_num, eng_num, \
                    url_num, article_num, video_num, obj_num, \
                    ret_num, cmt_num, like_num, \
                    content_category, content_tag, content_obj, \
                    uid, user_level, verified_type, fans_count, \
                    friends_count, gender, city, location, text \
                )
            from 
                (
                    select
                        distinct mid
                    from
                        $HOT_WEIBO_READ_TABLE_NAME
                ) read_table
        ) base_info
        left outer join
            (
                select 
                    distinct uid, label
                from 
                    tmp_wangliang8_head_user

            ) user_label
        on
            base_info.uid=user_label.uid
        left outer join
            $HOT_WEIBO_ABILITY_TABLE_NAME user_abi
        on
            base_info.uid=user_abi.uid
            
    "
}


function gen_hot_weibo_test_user_corpus_table(){
    corpus_dt=$1
    corpus_hour=$2
    create_hot_weibo_corpus_table
    corpus_part="dt='test_user_$corpus_dt', hour='$corpus_hour'"
    create_partition $HOT_WEIBO_CORPUS_TABLE_NAME "$corpus_part"

    pre_1_day=`date +%Y%m%d%H -d "$corpus_dt $corpus_hour -1 hour"`
    pre_1_dt=${pre_1_day:0:8}
    pre_1_hour=${pre_1_day:8:2}

    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_CORPUS_TABLE_NAME partition($corpus_part) 
        select
            user_inte.uid, user_inte.category, user_inte.tag, \
            user_inte.obj, NULL, NULL, NULL,\
            NULL, NULL, \
            click_24_rate.expo, click_24_rate.click, click_24_rate.rate, \
            click_1_rate.expo, click_1_rate.click, click_1_rate.rate, \
            weibo_info.mid, weibo_info.text_len, weibo_info.created_at, \
            weibo_info.pic_num, weibo_info.gif_num, weibo_info.long_pic_num, \
            weibo_info.title_num, weibo_info.at_num, weibo_info.emoji_num, \
            weibo_info.topic_num, weibo_info.puncs_num, weibo_info.eng_num, \
            weibo_info.url_num, weibo_info.article_num, weibo_info.video_num, weibo_info.obj_num, \
            weibo_info.ret_num, weibo_info.cmt_num, weibo_info.like_num, \
            weibo_info.content_category, weibo_info.content_tag, weibo_info.content_obj, \
            weibo_info.user_uid, weibo_info.user_category, weibo_info.user_tag, weibo_info.user_obj, \
            weibo_info.user_c_level, weibo_info.user_level, weibo_info.verified_type, weibo_info.fans_count, \
            weibo_info.friends_count, weibo_info.gender, weibo_info.city, weibo_info.location, weibo_info.text \
        from
        (
            select
                *
            from 
                $HOT_WEIBO_INTE_TABLE_NAME
            where
                uid=1216532917
        ) user_inte
        left outer join
        (
            select
                distinct mid
            from
                $HOT_WEIBO_CLICK_TABLE_NAME 
            where
                dt=$corpus_dt and hour=$corpus_hour
        ) click_table
        join
            $HOT_WEIBO_INFO_TABLE_NAME weibo_info
        on
            click_table.mid=weibo_info.mid
        left outer join
            $HOT_WEIBO_CLICK_RATE_24_HOUR_TABLE_NAME click_24_rate
        on
            click_table.mid=click_24_rate.mid
            and click_24_rate.dt=$corpus_dt and click_24_rate.hour=$corpus_hour
        left outer join
            $HOT_WEIBO_CLICK_RATE_HOUR_TABLE_NAME click_1_rate
        on
            click_table.mid=click_1_rate.mid
            and click_1_rate.dt=$pre_1_dt and click_1_rate.hour=$pre_1_hour
    "
}

function gen_hot_weibo_corpus_day_table(){
    corpus_dt=$1
    create_hot_weibo_corpus_table
    corpus_part="dt='total_$corpus_dt', hour='00'"
    create_partition $HOT_WEIBO_CORPUS_TABLE_NAME "$corpus_part"

    odpscmd -e "
        insert overwrite table 
            $HOT_WEIBO_CORPUS_TABLE_NAME partition($corpus_part) 
        select
            click_table.uid, user_inte.category, user_inte.tag, \
            user_inte.obj, NULL, NULL, NULL,\
            click_table.duration, click_table.is_click, 
            NULL, NULL, NULL, \
            NULL, NULL, NULL, \
            weibo_info.mid, weibo_info.text_len, weibo_info.created_at, \
            weibo_info.pic_num, weibo_info.gif_num, weibo_info.long_pic_num, \
            weibo_info.title_num, weibo_info.at_num, weibo_info.emoji_num, \
            weibo_info.topic_num, weibo_info.puncs_num, weibo_info.eng_num, \
            weibo_info.url_num, weibo_info.article_num, weibo_info.video_num, weibo_info.obj_num, \
            weibo_info.ret_num, weibo_info.cmt_num, weibo_info.like_num, \
            weibo_info.content_category, weibo_info.content_tag, weibo_info.content_obj, \
            weibo_info.user_uid, weibo_info.user_category, weibo_info.user_tag, weibo_info.user_obj, \
            weibo_info.user_c_level, weibo_info.user_level, weibo_info.verified_type, weibo_info.fans_count, \
            weibo_info.friends_count, weibo_info.gender, weibo_info.city, weibo_info.location, weibo_info.text \
        from
            $HOT_WEIBO_CLICK_TABLE_NAME click_table
        join
            $HOT_WEIBO_INFO_TABLE_NAME weibo_info
        on
            click_table.mid=weibo_info.mid
            and click_table.dt='total_$corpus_dt' 
        left outer join
            $HOT_WEIBO_INTE_TABLE_NAME user_inte
        on
            click_table.uid=user_inte.uid
    "
}

function create_hot_weibo_corpus_data_clean_table(){

    create_table_like_other_table $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME $HOT_WEIBO_CORPUS_TABLE_NAME $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_LOCATION
}

function data_clean_strategy_3(){
    
    # fliter samples with auto-play
    # fliter samples generated by users who do not click a weibo in a single day
    # fliter samples generated by users who refresh more than 50 times in a single day
    
    input_table_name=$1
    dt_name=$2
    output_table_name=$3
    #odpscmd -e "select b.u from (select uid as u, count(distinct expo_time) as e, sum(is_click) as i from $input_table_name where dt = '$dt_name' and (isautoplay is null or isautoplay = 0) group by uid )b where b.i > 0 and b.e <= 50" > $uid_fliter_config_file 
    odpscmd -e "
            set odps.sql.groupby.skewindata=true;
            insert overwrite table 
                $output_table_name partition(dt=$dt_name, hour=$dt_name) 
            select 
                a.is_click, a.actions, a.isautoplay, a.mid, a.duration, a.uid, a.born, a.gender, a.area_id, a.user_tags, a.doc_tags, a.author_id, a.expo_time, a.network_type, a.recommend_source, a.recommend_base_level, a.category, a.first_level_inte_weight, a.second_level_inte_weight, a.third_level_inte_weight, a.effect_weight, a.pic_weight, a.article_weight, a.video_weight, a.obj_weight, a.user_weight, a.ret_num, a.cmt_num, a.like_num, a.ret_num_recent, a.cmt_num_recent, a.like_num_recent, a.total_read_num, a.expose_num, a.act_num, a.inter_act_num, a.expose_num_recent, a.act_num_recent, a.inter_act_num_recent, a.hot_ret_num, a.hot_cmt_num, a.hot_like_num, a.hot_ret_num_recent, a.hot_cmt_num_recent, a.hot_like_num_recent, a.article_read_num, a.miaopai_view_num, a.all_group_msg, a.hour_group_msg, a.extend, a.extend2, a.extend3 
            from
            (
                select
                    uid, mid, max(is_click) as max_click
                from
                    $input_table_name
                where 
                    dt = '$dt_name' 
                group by uid, mid
            )b 
            join
                (select * from $input_table_name where dt ='$dt_name' ) a
            on
                a.uid=b.uid
                and a.mid=b.mid
                and a.is_click=b.max_click
            inner join
            (
                    select 
                        c.u as uid_persist 
                    from 
                        (
                            select 
                                uid as u, count(distinct expo_time) as e, sum(is_click) as i 
                            from 
                                $input_table_name 
                            where 
                                dt = '$dt_name' group by uid 
                        )c
                    where 
                        c.i > 0 and c.e <= 50
            )d
            on
                a.uid=d.uid_persist;
            select sum(is_click), count(*), sum(is_click)/count(*) from $output_table_name where dt='$dt_name'; 
            "

}


function interate_gen_click_day_table(){
    start_dt=$1
    end_dt=$2
    while [ $start_dt -lt $end_dt ]
    do
        cur_day=$start_dt
        gen_hot_weibo_read_day_table $cur_day
        gen_hot_weibo_action_day_table $cur_day
        gen_hot_weibo_click_day_table $cur_day

        start_dt=`date +%Y%m%d -d "$cur_day 1 days" `
    done
}

function interate_gen_click_rate_table(){
    start_dt=$1
    end_dt=$2
    while [ $start_dt -lt $end_dt ]
    do

        gen_hot_weibo_click_rate_table $start_dt

        start_dt=`date +%Y%m%d -d "$start_dt 1 days"`
    done
}

function interate_gen_click_rate_hour_table(){
    start_dt=$1
    end_dt=$2
    start_dt=`date +%Y%m%d%H -d "$start_dt"`
    end_dt=`date +%Y%m%d%H -d "$end_dt"`
    while [ $start_dt -lt $end_dt ]
    do
        cur_day=${start_dt:0:8}
        cur_hour=${start_dt:8:2}

        gen_hot_weibo_click_rate_hour_table $cur_day $cur_hour

        start_dt=`date +%Y%m%d%H -d "$cur_day $cur_hour 1 hour"`
    done
}

function interate_gen_click_rate_24_hour_table(){
    start_dt=$1
    end_dt=$2
    start_dt=`date +%Y%m%d%H -d "$start_dt"`
    end_dt=`date +%Y%m%d%H -d "$end_dt"`
    while [ $start_dt -lt $end_dt ]
    do
        cur_day=${start_dt:0:8}
        cur_hour=${start_dt:8:2}

        gen_hot_weibo_click_rate_24_hour_table $cur_day $cur_hour

        start_dt=`date +%Y%m%d%H -d "$cur_day $cur_hour 1 hour"`
    done
}

function interate_gen_corpus_table(){
    start_dt=$1
    end_dt=$2
    start_dt=`date +%Y%m%d%H -d "$start_dt"`
    end_dt=`date +%Y%m%d%H -d "$end_dt"`
    while [ $start_dt -lt $end_dt ]
    do
        cur_day=${start_dt:0:8}
        cur_hour=${start_dt:8:2}

        if [ $cur_hour -ge "07" ]  && [ $cur_hour -le "23" ];then
            gen_hot_weibo_corpus_table $cur_day $cur_hour
        fi

        start_dt=`date +%Y%m%d%H -d "$cur_day $cur_hour 1 hour"`
    done
}

function interate_gen_corpus_day_table(){
    start_dt=$1
    end_dt=$2
    while [ $start_dt -lt $end_dt ]
    do
        cur_day=$start_dt

        gen_hot_weibo_corpus_day_table $cur_day

        start_dt=`date +%Y%m%d -d "$cur_day 1 days"`
    done
}


# 入口函数
function interate_gen_click_table(){
    start_dt=$1
    end_dt=$2
    start_dt=`date +%Y%m%d%H -d "$start_dt"`
    end_dt=`date +%Y%m%d%H -d "$end_dt"`
    while [ $start_dt -lt $end_dt ]
    do
        cur_day=${start_dt:0:8}
        cur_hour=${start_dt:8:2}

        if [ $cur_hour -ge "07" ] && [ $cur_hour -le "23" ];then
        gen_hot_weibo_read_table $cur_day $cur_hour
        gen_hot_weibo_action_table $cur_day $cur_hour
        gen_hot_weibo_click_table $cur_day $cur_hour
        gen_hot_weibo_corpus_table $cur_day $cur_hour
        data_clean $cur_day
            start_dt=`date +%Y%m%d%H -d "$cur_day $cur_hour 24 hour"`
            continue
        fi

        start_dt=`date +%Y%m%d%H -d "$cur_day $cur_hour 1 hour"`
    done
}

# 从热门微博曝光日志中取些数据
function gen_hot_weibo_read_table(){
    read_dt=$1
    read_hour=$2
    create_hot_weibo_read_table
    read_part="dt=$read_dt, hour=$read_hour"
    create_partition $HOT_WEIBO_READ_TABLE_NAME "$read_part"
    odpscmd -e "
        add jar target/genHotWeiboCorpus_binbin7.jar -f;
        create function binbin7_extract_expo_msg as 'ExtractExpoMsg' using 'genHotWeiboCorpus_binbin7.jar' -f;
        insert overwrite table
            $HOT_WEIBO_READ_TABLE_NAME partition($read_part)
        select
	    id,
	    '' duration,
	    uid,
	    '' born,
	    '' gender,
	    area_id,
	    '[]' user_tags,
	    '[]' doc_tags,
	    author_id,
	    TIME,
	    network_type,
	    recommend_source,
	    recommend_base_level,
	    category,
	    first_level_inte_weight,
	    second_level_inte_weight,
	    third_level_inte_weight,
	    effect_weight,
	    pic_weight,
	    article_weight,
	    video_weight,
	    obj_weight,
	    user_weight,
	    ret_num,
	    cmt_num,
	    like_num,
	    ret_num_recent,
	    cmt_num_recent,
	    like_num_recent,
	    total_read_num,
	    expose_num,
	    act_num,
	    inter_act_num,
	    expose_num_recent,
	    act_num_recent,
	    inter_act_num_recent,
	    hot_ret_num,
	    hot_cmt_num,
	    hot_like_num,
	    hot_ret_num_recent,
	    hot_cmt_num_recent,
	    hot_like_num_recent,
	    article_read_num,
	    miaopai_view_num,
	    time_born_gender_action_list,
	    extend,
            extend2,
            extend3
	FROM
	(
	SELECT * FROM
	    ods_tblog_hotmblog_exposure_storage
	WHERE
	    dt='$read_dt' and uid not in ('3655689037','') and category_id = '' and recommend_source < 100
	) exposure_storage
	lateral view binbin7_extract_expo_msg(extend) v1 as total_read_num, inter_act_num, inter_act_num_recent, hot_ret_num, hot_cmt_num, hot_like_num, hot_ret_num_recent, hot_cmt_num_recent, hot_like_num_recent, time_born_gender_action_list, recommend_base_level;
        "
}

# join 无线打码日志生成带label的数据, 所有在无线打码日志中出现的uid mid
function gen_hot_weibo_action_table(){
    action_dt=$1
    action_hour=$2
    create_hot_weibo_action_table
    action_part="dt=$action_dt, hour=$action_hour"
    create_partition $HOT_WEIBO_ACTION_TABLE_NAME "$action_part"
    #and ( action<>799  or (action=799 and extend like '%|isautoplay:0||%') )
	#action in ('91', '1423', '7', '41','54','55','127','128','749','3','381','658','659','4','336','932','933','6') or (action ='799' and ((from_val>='1065000000' and split_part(split_part(extend,'valid_play_duration:', 2),'|', 1)>3000) or (from_val<'1065000000' and split_part(split_part(extend,'playduration:', 2),'|', 1)>3000)))
    odpscmd -e "
        INSERT OVERWRITE TABLE
            $HOT_WEIBO_ACTION_TABLE_NAME partition($action_part)
		select
		    a.*
		from
		(
			SELECT
				*
			FROM
			(
				SELECT
					uid,
					CASE
					WHEN
						(substr(target_id, 1, 1) == '3' OR substr(target_id, 1, 1) == '4')
						AND length(target_id) == 16
					THEN
						target_id
					WHEN
						REGEXP_EXTRACT(extend, 'mid[:=]([0-9]+)', 1) != ''
					THEN
						REGEXP_EXTRACT(extend, 'mid[:=]([0-9]+)', 1)
					END
					AS mid,
					target_id,
					CASE WHEN
						action in ('91', '1423', '7', '41','54','55','127','128','749','3','381','658','659','4','336','932','933','6') or (action ='799' and ((from_val>='1065000000' and split_part(split_part(extend,'valid_play_duration:', 2),'|', 1)>3000) or (from_val<'1065000000' and split_part(split_part(extend,'playduration:', 2),'|', 1)>3000)))
					THEN
						action
					ELSE
						'invalid action'
					END
					AS ac,
					CASE
					WHEN
						instr(extend, 'isautoplay:1') == 0 or extend is null
					THEN
						0
					ELSE
						1
					END
					AS isautoplay
				FROM
					hotweibo_ods_wls_encode_bhv
				WHERE
					dt=$action_dt
			) tmp
			WHERE
				mid IS NOT NULL and ac != 'invalid action'
		) a
		join
		(
		    select uid, mid from $HOT_WEIBO_READ_TABLE_NAME where dt=$action_dt
		) b
		on
		    a.uid=b.uid
			and a.mid=b.mid;
        "
}

# join 转发和点赞表，生成点击表
function gen_hot_weibo_click_table(){
    click_dt=$1
    click_hour=$2
    create_hot_weibo_click_table
    ods_dim_appkey_dt=`get_latest_partition "ods_dim_appkey" "$click_dt"`
    echo "ods_dim_appkey: "$ods_dim_appkey_dt
    click_part="dt=$click_dt, hour=$click_hour"
    create_partition $HOT_WEIBO_CLICK_TABLE_NAME "$click_part"
# HOT_WEIBO_READ_TABLE_NAME='binbin7_self3_hot_weibo_read'
    odpscmd -e "
		set odps.stage.mapper.jvm.mem = 512;
	    set odps.stage.reducer.jvm.mem = 1024;
        insert overwrite table
            $HOT_WEIBO_CLICK_TABLE_NAME partition($click_part)
        select
            case when b.mid is not null or ret.mid is not null or like.mid is not null then 1 else 0 end,
			concat(b.actions, case when ret.mid is not null then ',3add' else '' end, case when like.mid is not null then ',6add' else '' end), b.isautoplay,
            a.mid, a.duration, a.uid, born, gender, area_id,
            user_tags, doc_tags, author_id, expo_time, network_type,
            recommend_source, recommend_base_level, category,
            first_level_inte_weight, second_level_inte_weight,
            third_level_inte_weight, effect_weight, pic_weight,
            article_weight, video_weight, obj_weight, user_weight,
            ret_num, cmt_num, like_num,
            ret_num_recent, cmt_num_recent, like_num_recent,
            total_read_num, expose_num, act_num, inter_act_num,
            expose_num_recent, act_num_recent,  inter_act_num_recent,
            hot_ret_num, hot_cmt_num, hot_like_num,
            hot_ret_num_recent, hot_cmt_num_recent, hot_like_num_recent,
            article_read_num, miaopai_view_num, time_born_gender_action_list, extend,
            extend2, extend3
        from
        (
            select
                *
            from
                $HOT_WEIBO_READ_TABLE_NAME
            where
                dt=$click_dt
        )a
        left outer join
        (
            select
			uid, mid, wm_concat(',', case when action is null then 'null' else action end) as actions, isautoplay
            from
                $HOT_WEIBO_ACTION_TABLE_NAME
            where
                dt=$click_dt
            group by
                uid, mid, isautoplay
        )b
        on
            a.uid=b.uid
            and a.mid=b.mid
		left outer join
		(
			select
			distinct d.uid,d.mid
			from
			(
				select appid
				from
				ods_dim_appkey
				where dt=${ods_dim_appkey_dt}
				and is_weibo='1'
				and app_class_code='2'
			)c
			join
			(
				select oper_src_id,parentmid as mid,uid
				from mds_bhv_pubblog
				where dt=${click_dt}
				and is_transmit = 1
				and length(uid)<13
			)d
			on c.appid=d.oper_src_id
		) ret
		on
		a.uid = ret.uid and a.mid = ret.mid
		left outer join
		(
		select
		distinct h.uid,h.mid
		from
		(
			select
			appid
			from ods_dim_appkey
			where dt=${ods_dim_appkey_dt}
			and is_weibo='1' and app_class_code='2'
		)g
		join
		(
			select
			oper_src_id,uid,object_id as mid
			from mds_bhv_like
			where dt=${click_dt}
			and mode='1'
			and object_type='status'
			and length(uid)<13
		)h
		on g.appid=h.oper_src_id
		) like
		on
		a.uid = like.uid and a.mid = like.mid
    "
}

# join 上性别年龄特征 生成行为表
function gen_hot_weibo_corpus_table(){
    corpus_dt=$1
    corpus_hour=$2
    create_hot_weibo_corpus_table
    corpus_part="dt=$corpus_dt, hour=$corpus_hour"
    create_partition $HOT_WEIBO_CORPUS_TABLE_NAME "$corpus_part"

    odpscmd -e "
        add jar target/genHotWeiboCorpus_binbin7.jar -f;
        create function binbin7_extract_group_click as 'ExtractGroupClick' using 'genHotWeiboCorpus_binbin7.jar' -f;
        insert overwrite table
            $HOT_WEIBO_CORPUS_TABLE_NAME partition($corpus_part)
        select
			is_click,
			actions,
			isautoplay,
			mid,
			duration,
			uid,
			tmp1.age_orig,
			tmp1.formated_gender,
			area_id,
			user_tags,
			doc_tags,
			author_id,
			expo_time,
			network_type,
			recommend_source,
			recommend_base_level,
			category,
			first_level_inte_weight,
			second_level_inte_weight,
			third_level_inte_weight,
			effect_weight,
			pic_weight,
			article_weight,
			video_weight,
			obj_weight,
			user_weight,
			ret_num,
			cmt_num,
			like_num,
			ret_num_recent,
			cmt_num_recent,
			like_num_recent,
			total_read_num,
			expose_num,
			act_num,
			inter_act_num,
			expose_num_recent,
			act_num_recent,
			inter_act_num_recent,
			hot_ret_num,
			hot_cmt_num,
			hot_like_num,
			hot_ret_num_recent,
			hot_cmt_num_recent,
			hot_like_num_recent,
			article_read_num,
			miaopai_view_num,
			all_group_msg,
			hour_group_msg,
			extend,
			extend2,
			extend3
	FROM
	    (
		SELECT
		    *,
		    CASE
			WHEN tmp.formated_gender == 'm' THEN 0
			WHEN tmp.formated_gender == 'f' THEN 1
			ELSE 2
		    END AS gender_index
		FROM
		    (
			SELECT
			    *,
			    CASE
				WHEN click_table.gender_orig == '1' THEN 'm'
				WHEN click_table.gender_orig == '2' THEN 'f'
				ELSE click_table.gender_orig
			    END AS formated_gender,
			    CASE
				WHEN click_table.age_orig == 'all' THEN 5
				WHEN click_table.age_orig == '70s' THEN 0
				WHEN click_table.age_orig == '80s' THEN 1
				WHEN click_table.age_orig == '90s' THEN 2
				WHEN click_table.age_orig == '00s' THEN 3
				ELSE 4
			    END AS born_index
			FROM
            (
                select
                    click_table_tmp.*, born_gender_table.age as age_orig, born_gender_table.gender as gender_orig
                from
			    (
				    select
					    tmp_click_table.uid, born_table.age, gender_table.gender
				    from
				    (
						select
							distinct uid
						from
							$HOT_WEIBO_CLICK_TABLE_NAME
						where
							dt = $corpus_dt
				    ) tmp_click_table
				    left outer join
					    bigdata_mds_user_bornyear_mining born_table
				    on
					    tmp_click_table.uid = born_table.uid
				    left outer join
					    bigdata_mds_user_gender_mining gender_table
				    on
					    tmp_click_table.uid = gender_table.uid
				)born_gender_table
				right outer join
				(
				    select
					    *
				    from
					    $HOT_WEIBO_CLICK_TABLE_NAME
				    where
					    dt = $corpus_dt

				)click_table_tmp
				on
				    born_gender_table.uid = click_table_tmp.uid

             ) click_table
			WHERE
			    ( instr(is_click, 'None') == 0 or is_click is null)
				AND (instr(actions, 'None') == 0 or actions is null)
				AND (instr(isautoplay, 'None') == 0 or isautoplay is null)
				AND instr(mid, 'None') == 0
				AND (instr(duration, 'None') == 0 or duration is null)
				AND (instr(uid, 'None') == 0 or uid is null)
				AND (instr(area_id, 'None') == 0 or area_id is null)
				AND instr(user_tags, 'None') == 0
				AND instr(doc_tags, 'None') == 0
				AND (instr(author_id, 'None') == 0 or author_id is null)
				AND (instr(expo_time, 'None') == 0 or expo_time is null)
				AND (instr(network_type, 'None') == 0 or network_type is null)
				AND (instr(recommend_source, 'None') == 0 or recommend_source is null)
				AND (instr(recommend_base_level, 'None') == 0 or recommend_base_level is null)
				AND (instr(category, 'None') == 0 or category is null)
				AND (instr(first_level_inte_weight, 'None') == 0 or first_level_inte_weight is null)
				AND (instr(second_level_inte_weight, 'None') == 0 or second_level_inte_weight is null)
				AND (instr(third_level_inte_weight, 'None') == 0 or third_level_inte_weight is null)
				AND (instr(effect_weight, 'None') == 0 or effect_weight is null)
				AND (instr(pic_weight, 'None') == 0 or pic_weight is null)
				AND (instr(article_weight, 'None') == 0 or article_weight is null)
				AND (instr(video_weight, 'None') == 0 or video_weight is null)
				AND (instr(obj_weight, 'None') == 0 or obj_weight is null)
				AND (instr(user_weight, 'None') == 0 or user_weight is null)
				AND (instr(ret_num, 'None') == 0 or ret_num is null)
				AND (instr(cmt_num, 'None') == 0 or cmt_num is null)
				AND (instr(like_num, 'None') == 0 or like_num is null)
				AND (instr(ret_num_recent, 'None') == 0 or ret_num_recent is null)
				AND (instr(cmt_num_recent, 'None') == 0 or cmt_num_recent is null)
				AND (instr(like_num_recent, 'None') == 0 or like_num_recent is null)
				AND (instr(total_read_num, 'None') == 0 or total_read_num is null)
				AND (instr(expose_num, 'None') == 0 or expose_num is null)
				AND (instr(act_num, 'None') == 0 or act_num is null)
				AND (instr(inter_act_num, 'None') == 0 or inter_act_num is null)
				AND (instr(expose_num_recent, 'None') == 0 or expose_num_recent is null)
				AND (instr(act_num_recent, 'None') == 0 or act_num_recent is null)
				AND (instr(inter_act_num_recent, 'None') == 0 or inter_act_num_recent is null)
				AND (instr(hot_ret_num, 'None') == 0 or hot_ret_num is null)
				AND (instr(hot_cmt_num, 'None') == 0 or hot_cmt_num is null)
				AND (instr(hot_like_num, 'None') == 0 or hot_like_num is null)
				AND (instr(hot_ret_num_recent, 'None') == 0 or hot_ret_num_recent is null)
				AND (instr(hot_cmt_num_recent, 'None') == 0 or hot_cmt_num_recent is null)
				AND (instr(hot_like_num_recent, 'None') == 0 or hot_like_num_recent is null)
				AND (instr(article_read_num, 'None') == 0 or article_read_num is null)
				AND (instr(miaopai_view_num, 'None') == 0  or miaopai_view_num is null)
				AND (instr(time_born_gender_action_list, 'None') == 0 or time_born_gender_action_list is null)
				AND (instr(extend, 'None') == 0 or extend is null)
				AND (instr(age_orig, 'None') == 0 or age_orig is null)
				AND (instr(gender_orig, 'None') == 0 or gender_orig is null)
		    ) tmp
	    ) tmp1
		lateral view binbin7_extract_group_click(tmp1.born_index, tmp1.gender_index, tmp1.time_born_gender_action_list) tmp2 AS all_group_msg, hour_group_msg
	;
	select sum(is_click), count(*), sum(is_click)/count(*) from $HOT_WEIBO_CORPUS_TABLE_NAME where dt=$corpus_dt;
    "
	echo "finish gen_hot_weibo_corpus_table "
}

function data_clean(){

        input_table=$HOT_WEIBO_CORPUS_TABLE_NAME
        input_dt=$1
        output_table=$HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME
        create_hot_weibo_corpus_data_clean_table
        partition_name="dt=$input_dt, hour=$input_dt"
        create_partition $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME "$partition_name"
        #data_clean_strategy_2 $input_table $input_dt $output_table
        #data_clean_strategy_3 $input_table $input_dt $output_table
        data_clean_strategy_4 $input_table $input_dt $output_table

}

function data_clean_strategy_4(){

    # fliter samples with auto-play
    # fliter samples generated by users who do not click a weibo in a single day
    # fliter samples generated by users who refresh more than 100 times in a single day

    input_table_name=$1
    dt_name=$2
    output_table_name=$3
    odpscmd -e "
            set odps.sql.groupby.skewindata=true;
            insert overwrite table
                $output_table_name partition(dt=$dt_name, hour=$dt_name)
            select
                a.is_click, a.actions, a.isautoplay, a.mid, a.duration, a.uid, a.born, a.gender, a.area_id, a.user_tags, a.doc_tags, a.author_id, a.expo_time, a.network_type, a.recommend_source, a.recommend_base_level, a.category, a.first_level_inte_weight, a.second_level_inte_weight, a.third_level_inte_weight, a.effect_weight, a.pic_weight, a.article_weight, a.video_weight, a.obj_weight, a.user_weight, a.ret_num, a.cmt_num, a.like_num, a.ret_num_recent, a.cmt_num_recent, a.like_num_recent, a.total_read_num, a.expose_num, a.act_num, a.inter_act_num, a.expose_num_recent, a.act_num_recent, a.inter_act_num_recent, a.hot_ret_num, a.hot_cmt_num, a.hot_like_num, a.hot_ret_num_recent, a.hot_cmt_num_recent, a.hot_like_num_recent, a.article_read_num, a.miaopai_view_num, a.all_group_msg, a.hour_group_msg, a.extend, a.extend2, a.extend3
            from
            (
                select
                    uid, mid, max(is_click) as max_click
                from
                    $input_table_name
                where
                    dt = '$dt_name'
                group by uid, mid
            )b
            join
                (select * from $input_table_name where dt ='$dt_name' ) a
            on
                a.uid=b.uid
                and a.mid=b.mid
                and a.is_click=b.max_click
            inner join
            (
                    select
                        c.u as uid_persist
                    from
                        (
                            select
                                uid as u, count(distinct expo_time) as e, sum(is_click) as i
                            from
                                $input_table_name
                            where
                                dt = '$dt_name' group by uid
                        )c
                    where
                        c.i > 0 and c.e <= 100
            )d
            on
                a.uid=d.uid_persist;
            select sum(is_click), count(*), sum(is_click)/count(*) from $output_table_name where dt='$dt_name';
            "
		 echo "finish data_clean"
}

interate_gen_click_table $1 $2
