#!/bin/sh
startdate=`date -d "$1" +%Y-%m-%d`
enddate=`date -d "$2" +%Y-%m-%d`
rm table.txt 
rm -f tmp_log
mkdir tmp_log
dir=tmp_log
while [[ $startdate < $enddate  ]]
do
    echo "########$startdate########"
	echo "**************************" >> table.txt;
	echo "$startdate" >> table.txt;
	t=`date -d "$startdate" +%Y%m%d`
    odpscmd -e "desc ods_tblog_hotmblog_exposure_storage partition(dt=$t, hour='07')" &> $dir/log1;
	declare -i flag=1
	text=$dir/log1
    if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
    if [ $flag -eq 0 ] ; then 
	echo "ods_tblog_hotmblog_exposure_storage" >> table.txt;
	fi

	odpscmd -e "desc hotweibo_ods_wls_encode_bhv partition(dt=$t)" &> $dir/log2;
     text=$dir/log2
	 flag=1
     if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	 if [ $flag -eq 0 ] ; then
	 echo "hotweibo_ods_wls_encode_bhv" >> table.txt;
	 fi
	odpscmd -e "desc bigdata_mds_user_bornyear_mining" &> $dir/log3;
	 text=$dir/log3
     flag=1
	 if grep "FAILED" $text || grep "Size: 0" $text; then flag=0; fi
	 if [ $flag -eq 0 ] ; then
	 echo "bigdata_mds_user_bornyear_mining" >> table.txt;
	 fi
	odpscmd -e "desc bigdata_mds_user_gender_mining" &> $dir/log4;
	 text=$dir/log4
	 flag=1
	 if grep "FAILED" $text || grep "Size: 0" $text; then flag=0; fi
	 if [ $flag -eq 0 ] ; then
	 echo "bigdata_mds_user_gender_mining" >> table.txt;
	 fi
    odpscmd -e "desc ods_dim_appkey partition(dt=$t)" &> $dir/log5;
	text=$dir/log5
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "ods_dim_appkey" >> table.txt;
	fi
	odpscmd -e "desc mds_bhv_pubblog partition(dt=$t)" &> $dir/log6;
	text=$dir/log6
	flag=1
    if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "mds_bhv_pubblog" >> table.txt;
	fi
	odpscmd -e "desc mds_bhv_cmtblog partition(dt=$t)" &> $dir/log7;
	text=$dir/log7
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "mds_bhv_cmtblog" >> table.txt;
	fi
	odpscmd -e "desc mds_bhv_like partition(dt=$t)" &> $dir/log8;
	text=$dir/log8
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "mds_bhv_like" >> table.txt;
	fi
	odpscmd -e "desc mds_bas_user_usagefreq partition(dt=$t)" &> $dir/log9;
	text=$dir/log9
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "mds_bas_user_usagefreq" >> table.txt;
	fi
	odpscmd -e "desc hot_mblog_recommend_mblog_info partition(dt=$t)" &> $dir/log10;
	text=$dir/log10
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "hot_mblog_recommend_mblog_info" >> table.txt;
	fi
	odpscmd -e "desc hot_mblog_user_intimacy_plat partition(dt=$t)" &> $dir/log11;
	text=$dir/log11
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "hot_mblog_user_intimacy_plat" >> table.txt;
	fi
	odpscmd -e "desc user_long_interest_modified_for_hotmblog partition(dt=$t)" &> $dir/log12;
	text=$dir/log12
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "user_long_interest_modified_for_hotmblog" >> table.txt;
	fi
	odpscmd -e "desc users_short_interest_in_interest_based_reading partition(dt=$t)" &> $dir/log13;
	text=$dir/log13
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "users_short_interest_in_interest_based_reading" >> table.txt;
	fi
	odpscmd -e "desc bigdata_vf_user_device_type partition(user_type=0, dt=$t)" &> $dir/log14;
	text=$dir/log14
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "bigdata_vf_user_device_type" >> table.txt;
	fi
	odpscmd -e "desc binbin7_self3_ods_tblog_real_read partition(dt=$t)" &> $dir/log15;
	text=$dir/log15
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "binbin7_self3_ods_tblog_real_read" >> table.txt;
	fi
	odpscmd -e "desc mds_strategy_feed_user_rate partition(dt=$t)" &> $dir/log16;
	text=$dir/log16
	flag=1
	if grep "FAILED" $text || grep "PartitionSize: 0" $text; then flag=0; fi
	if [ $flag -eq 0 ] ; then
	echo "mds_strategy_feed_user_rate" >> table.txt;
	fi
	    
	    startdate=`date -d "+1 day $startdate" +%Y-%m-%d`
done
