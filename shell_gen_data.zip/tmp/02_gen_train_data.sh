#!/bin/bash
HOT_WEIBO_CORPUS_TABLE_NAME='binbin7_self3_hot_mblog_corpus_24'
HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME='binbin7_hot_mblog_corpus_24_data_clean'
HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_mblog_corpus_24_data_clean/'
HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE='binbin7_hot_mblog_corpus_24_merge_attributes'
HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_mblog_corpus_24_merge_user_doc_attributes/'
HOT_WEIBO_BASE_FEATURES_TABLE='hot_mblog_base_features_table'
#HOT_WEIBO_BASE_FEATURES_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/hot_mblog_base_features_table/'
HOT_WEIBO_REAL_READ_EXPOSE_TABLE='binbin7_self3_ods_tblog_real_read'
HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE='binbin7_hot_mblog_real_base_features'
HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_mblog_real_base_features/'
#libsvm 数据
HOT_WEIBO_LIBSVM_TABLE_NAME='binbin7_hot_weibo_libsvm_base'
#HOT_WEIBO_LIBSVM_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_weibo_libsvm_base/'
HOT_WEIBO_TRAIN_TABLE_NAME='binbin7_hot_weibo_train_binary'
HOT_WEIBO_TRAIN_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_weibo_train_binary/'
HOT_WEIBO_TRAIN_LIBSVM_TABLE_NAME='binbin7_hot_weibo_train_libsvm'
HOT_WEIBO_TRAIN_LIBSVM_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_weibo_train_libsvm/'
HOT_WEIBO_TEST_TABLE_NAME='binbin7_hot_weibo_train_binary_test'
HOT_WEIBO_TEST_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_weibo_train_binary_test/'
HOT_WEIBO_MODEL_TABLE_NAME='binbin7_hot_weibo_model'
HOT_WEIBO_FM_TABLE_NAME='binbin7_hot_weibo_train_fm'
HOT_WEIBO_FM_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_weibo_train_fm/'
HOT_WEIBO_FM_SHUJIA_TABLE_NAME='binbin7_hot_weibo_train_fm_shujia'
HOT_WEIBO_FM_SHUAJIA_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_weibo_train_fm/'
HOT_WEIBO_FM_SHUJIA_TEST_TABLE_NAME='binbin7_hot_weibo_train_fm_shujia_test'
HOT_WEIBO_FM_SHUAJIA_TEST_TABLE_LOCATION='/user/weibo_bigdata_text/binbin7/corpus/binbin7_hot_weibo_train_fm/'

function create_partition(){
	TABLE=$1
		PARTITIONS=$2
		echo "to create table partition $TABLE $PARTITIONS"
		odpscmd -e "
		ALTER TABLE $TABLE ADD IF NOT EXISTS PARTITION($PARTITIONS);
	"
}

function create_partition_table(){
	TABLE=$1
		FIELDS=$2
		PARTITIONS=$3
		echo "to create internal partition table $TABLE" 
		odpscmd -e "
		CREATE TABLE IF NOT EXISTS $TABLE ($FIELDS)  
		PARTITIONED BY ($PARTITIONS)
		ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'; 
	"
}

function create_table(){
	TABLE=$1
		FIELDS=$2
		echo "to create internal table $TABLE" 
		odpscmd -e "
		CREATE TABLE IF NOT EXISTS $TABLE ($FIELDS) ; 
	"
}

function create_partition_table_without_row_format(){
	TABLE=$1
		FIELDS=$2
		PARTITIONS=$3
		echo "to create internal partition table $TABLE" 
#echo "
		odpscmd -e "
		CREATE TABLE IF NOT EXISTS $TABLE ($FIELDS) PARTITIONED BY ($PARTITIONS);
	"
}

function create_external_partition_table(){
	TABLE=$1
		FIELDS=$2
		PARTITIONS=$3
		DIR=$4
		echo "to create external partition table $TABLE" 
		odpscmd -e "
		CREATE EXTERNAL TABLE IF NOT EXISTS $TABLE ($FIELDS)  
		PARTITIONED BY ($PARTITIONS)
		ROW FORMAT DELIMITED FIELDS TERMINATED BY '\t'  
		location '$DIR'; 
	"
}

function create_external_partition_table_depart_cva(){
	TABLE=$1
		FIELDS=$2
		PARTITIONS=$3
		DIR=$4
		echo "to create external partition table $TABLE" 
		odpscmd -e "
		CREATE EXTERNAL TABLE IF NOT EXISTS $TABLE ($FIELDS)  
		PARTITIONED BY ($PARTITIONS)
		ROW FORMAT DELIMITED FIELDS TERMINATED BY ''  
		location '$DIR'; 
	"
		echo "created external partition table $TABLE" 
}

function create_external_table_like_other_table(){
	TABLE_TO_CREATE=$1
		TABLE_SOURCE=$2
		DIR=$3
		echo "to create external table $TABLE_TO_CREATE like table $TABLE_SOURCE"
		odpscmd -e "CREATE EXTERNAL TABLE IF NOT EXISTS $TABLE_TO_CREATE LIKE $TABLE_SOURCE LOCATION '$DIR'"
		echo "created external table $TABLE_TO_CREATE"
}

function create_table_like_other_table(){
	TABLE_TO_CREATE=$1
		TABLE_SOURCE=$2
		DIR=$3
		echo "to create table $TABLE_TO_CREATE like table $TABLE_SOURCE"
		odpscmd -e "CREATE TABLE IF NOT EXISTS $TABLE_TO_CREATE LIKE $TABLE_SOURCE;"
		echo "created table $TABLE_TO_CREATE"
}

function is_2partition_exists(){
	partition_one_name=$1
		partition_two_name=$2
		table_name=$3
		result=$(odpscmd -e "show partitions $table_name" | grep "$partition_one_name" | grep "$partition_two_name")
		if [ "$result" != "" ];then
			echo "true"
		else
			echo "false"
				fi
}

function create_hot_weibo_libsvm_table(){
#train_fields='
#            is_like string,
#            l_inter_category_weight string, l_inter_tag_weight string, l_inter_obj_weight string,
#            n_inter_category_weight string, n_inter_tag_weight string, n_inter_obj_weight string,
#            abi_inter_category_weight string, abi_inter_tag_weight string, abi_inter_obj_weight string,
#            mid_rate string,
#            text_len string, pic_num string, gif_num string, long_pic_num string,
#            title_num string, at_num string, emoji_num string,
#            topic_num string, puncs_num string, eng_num string,
#            url_num string, article_num string, video_num string, obj_num string,
#            ret_num string, cmt_num string, like_num string,
#            c_level string, user_level string, verified_type string,
#            fans_count string, friends_count string
#            '
	train_fields='
		is_click bigint, features string, 
				 pic_num string, mblog_long_pic_num string, mblog_gif_num string, article_num string, video_num string, obj_num string, 
				 actions string, isautoplay string,
				 uid string, mid string,
				 born string, gender string,
				 first_level_match_tag string, second_level_match_tag string, third_level_match_tag string, duration string
					 '
					 train_partitions='dt string'
					 create_partition_table_without_row_format "$HOT_WEIBO_LIBSVM_TABLE_NAME" "$train_fields" "$train_partitions" "$HOT_WEIBO_LIBSVM_TABLE_LOCATION"
}

function create_hot_weibo_train_table(){
#train_fields='pos bigint, neg bigint, features string'
	train_fields='group_id bigint, features_len bigint, features_id_list string, positive bigint, negative bigint'
		train_partitions='version string'
		create_partition_table_without_row_format "$HOT_WEIBO_TRAIN_TABLE_NAME" "$train_fields" "$train_partitions" "$HOT_WEIBO_TRAIN_TABLE_LOCATION"
}

function create_hot_weibo_train_libsvm_table(){
	train_fields='label bigint, features_list string, uid string, mid string'
		train_partitions='version string'
		create_partition_table_without_row_format "$HOT_WEIBO_TRAIN_LIBSVM_TABLE_NAME" "$train_fields" "$train_partitions" "$HOT_WEIBO_TRAIN_LIBSVM_TABLE_LOCATION"
}

function create_hot_weibo_fm_table(){
	train_fields='label bigint, features_list string'
		train_partitions='version string'
		create_partition_table_without_row_format "$HOT_WEIBO_FM_TABLE_NAME" "$train_fields" "$train_partitions" "$HOT_WEIBO_FM_TABLE_LOCATION"
}
function create_hot_weibo_test_table(){
#train_fields='pos bigint, neg bigint, features string'
	train_fields='group_id bigint, features_len bigint, features_id_list string, positive bigint, negative bigint, uid string, mid string'
		train_partitions='version string'
		create_partition_table_without_row_format "$HOT_WEIBO_TEST_TABLE_NAME" "$train_fields" "$train_partitions" "$HOT_WEIBO_TEST_TABLE_LOCATION"
}


function create_hot_weibo_merge_user_and_doc_properties(){
	feature_fields='
		is_click string, actions string, isautoplay string, mid string, duration string,
				 uid string, born string, gender string, area_id string, 
				 user_tags string, doc_tags string, author_id string, expo_time string, network_type string, 
				 recommend_source string, recommend_base_level string, category string, 
				 first_level_inte_weight string, second_level_inte_weight string, 
				 third_level_inte_weight string, effect_weight string, pic_weight string, 
				 article_weight string, video_weight string, obj_weight string, user_weight string, 
				 ret_num string, cmt_num string, like_num string, 
				 ret_num_recent string, cmt_num_recent string, like_num_recent string, 
				 total_read_num string, expose_num string, act_num string, inter_act_num string, 
				 expose_num_recent string, act_num_recent string,  inter_act_num_recent string, 
				 hot_ret_num string, hot_cmt_num string, hot_like_num string, 
				 hot_ret_num_recent string, hot_cmt_num_recent string, hot_like_num_recent string,
				 article_read_num string, miaopai_view_num string, all_group_msg string, hour_group_msg string, extend string,
				 extend2 string, extend3 string, 
				 user_long_interests string, user_short_interests string, user_intimacy string, user_tags_click_rate string,  
				 author_base_attributes string, author_user_attraction string,
				 mid_base_attributes string, mid_topic_tags string, mid_key_word_tags string, 
				 uid_extend string, author_extend string, mid_extend string'
					 feature_partitions='dt string'
					 create_partition_table_without_row_format \
					 "$HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE" "$feature_fields" "$feature_partitions" "$HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE_LOCATION"
}

function create_hot_weibo_base_features_table(){
	train_fields='
		is_click string, actions string, isautoplay string, 
				 uid string, born string, gender string, area_id string, province_id string, 
				 mid string, duration string, recommend_source string, recommend_base_level string, category string, effect_weight string, pic_num string, mblog_long_pic_num string, 
				 mblog_gif_num string, article_weight string, video_weight string, obj_weight string, content_form string, mblog_level string, mblog_topic_num string, text_len string,  
				 ret_num string, cmt_num string, like_num string, 
				 ret_num_recent string, cmt_num_recent string, like_num_recent string, 
				 total_read_num string, expose_num string, act_num string, inter_act_num string, 
				 expose_num_recent string, act_num_recent string,  inter_act_num_recent string, 
				 hot_ret_num string, hot_cmt_num string, hot_like_num string, 
				 hot_ret_num_recent string, hot_cmt_num_recent string, hot_like_num_recent string,
				 group_expose_num string, group_act_num string, group_inter_act_num string, 
				 group_ret_num string, group_cmt_num string, group_like_num string, 
				 group_expose_num_recent string, group_act_num_recent string, group_inter_act_num_recent string, 
				 group_ret_num_recent string, group_cmt_num_recent string, group_like_num_recent string, 
				 mid_click_rate string, mid_inter_act_rate string, mid_click_num_rate string, 
				 mid_group_click_rate string, mid_group_inter_act_rate string, mid_group_click_num_rate string, 
				 inter_count string, hot_inter_count string, 
				 article_read_num string, miaopai_view_num string, 
				 second_level_valid_tag string, third_level_valid_tag string, 
				 topic_valid_tag string, key_word_valid_tag string, 
				 author_id string, author_verified_type string, author_user_class string, author_user_property string, 
				 author_followers_num string, author_property_and_verified_type string, author_user_weight string,  
				 first_level_inte_weight string, second_level_inte_weight string, third_level_inte_weight string, 
				 first_level_match_tag string, second_level_match_tag string, third_level_match_tag string, 
				 user_second_match_tag_value string, mblog_second_match_tag_value string, 
				 user_third_match_tag_value string, mblog_third_match_tag_value string, 
				 user_author_intimacy string, is_match_long_interest string, is_match_short_interest string, 
				 first_level_inte_group_ctr string, second_level_inte_group_ctr string, third_level_inte_group_ctr string,  
				 expo_time string, network_type string, is_match_location string, province_group_ctr string, 
				 author_user_ability_tags string, is_match_author_ability string, mid_duration_all string, mid_duration_uv string, mid_duration_avg string,
				 rank_num string, reader_device string, reader_lgn_all string, 
				 author_iar_month string, author_clickr_month string, author_iar_week string, author_clickr_week string, author_lgn_all string,
				 expose_time_day_slot string, expose_time_week_slot string, is_holiday string,
					 mid_feed_expo string, mid_feed_clk string, mid_feed_clk_rate string
					 '
					 train_partitions='dt string'
					 create_partition_table_without_row_format "$HOT_WEIBO_BASE_FEATURES_TABLE" "$train_fields" "$train_partitions" "$HOT_WEIBO_BASE_FEATURES_TABLE_LOCATION"
}


function get_latest_partition(){
	table_name=$1
	dt_name=$2
	interval=$3
	y_dt_name=`date +%Y%m%d -d "$dt_name $interval days ago"`
	parts=`odpscmd -e "show partitions $table_name"`
	dt_max='20160101'
	for dt in ${parts[@]};
	do
		dt_r=`echo $dt | awk -F'=' '{print $2}'`
		if [ $dt_r -gt $y_dt_name ];
	    then
		    break
		else
			dt_max=$dt_r
		fi
	done
	echo $dt_max
}


function create_hot_weibo_corpus_data_clean_table(){

	create_table_like_other_table $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME $HOT_WEIBO_CORPUS_TABLE_NAME $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_LOCATION
}

function data_clean_strategy_2(){

# fliter samples with auto-play
# fliter samples generated by users who do not click a weibo in a single day
# fliter samples generated by users who refresh more than 50 times in a single day

	input_table_name=$1
		dt_name=$2
		output_table_name=$3
		uid_fliter_config_file='uid_to_preserve_'$input_table_name'_'$dt_name
		is_config_file_exists=`is_file_exists $uid_fliter_config_file`
		if [ "$is_dis_file_exists" == "true" ];then
			echo "current uid fliter config file: $uid_fliter_config_file exists !"
		else
			odpscmd -e "select b.u from (select uid as u, count(distinct expo_time) as e, sum(is_click) as i from $input_table_name where dt = '$dt_name' and (isautoplay is null or isautoplay = 0) group by uid )b where b.i > 0 and b.e <= 50" > $uid_fliter_config_file 
				fi

				odpscmd -e "
				add file generate_sample_with_fliter.py;
	add file $uid_fliter_config_file; 
	create external table if not exists $output_table_name like $input_table_name location '/user/weibo_bigdata_text/binbin7/corpus/$output_table_name'; 
	set mapreduce.map.memory.mb=4096; 
	insert overwrite table 
		$output_table_name 
		partition
		(dt='$dt_name', hour='$output_hour_name') 
		select 
		transform(a.*) 
		using 'python generate_sample_with_fliter.py $uid_fliter_config_file' 
		as 
		(is_click, actions, isautoplay, mid, duration, uid, born, gender, area_id, user_tags, doc_tags, author_id, expo_time, network_type, recommend_source, recommend_base_level, category, first_level_inte_weight, second_level_inte_weight, third_level_inte_weight, effect_weight, pic_weight, article_weight, video_weight, obj_weight, user_weight, ret_num, cmt_num, like_num, ret_num_recent, cmt_num_recent, like_num_recent, total_read_num, expose_num, act_num, inter_act_num, expose_num_recent, act_num_recent, inter_act_num_recent, hot_ret_num, hot_cmt_num, hot_like_num, hot_ret_num_recent, hot_cmt_num_recent, hot_like_num_recent, article_read_num, miaopai_view_num, all_group_msg, hour_group_msg, extend) 
		from $input_table_name a 
		where 
		a.dt = '$dt_name' and (a.isautoplay is null or a.isautoplay = 0)
		"

}

function data_clean_strategy_3(){

# fliter samples with auto-play
# fliter samples generated by users who do not click a weibo in a single day
# fliter samples generated by users who refresh more than 50 times in a single day

	input_table_name=$1
		dt_name=$2
		output_table_name=$3
#odpscmd -e "select b.u from (select uid as u, count(distinct expo_time) as e, sum(is_click) as i from $input_table_name where dt = '$dt_name' and (isautoplay is null or isautoplay = 0) group by uid )b where b.i > 0 and b.e <= 50" > $uid_fliter_config_file 
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
	insert overwrite table 
		$output_table_name partition(dt=$dt_name, hour=$dt_name) 
		select 
		a.is_click, a.actions, a.isautoplay, a.mid, a.duration, a.uid, a.born, a.gender, a.area_id, a.user_tags, a.doc_tags, a.author_id, a.expo_time, a.network_type, a.recommend_source, a.recommend_base_level, a.category, a.first_level_inte_weight, a.second_level_inte_weight, a.third_level_inte_weight, a.effect_weight, a.pic_weight, a.article_weight, a.video_weight, a.obj_weight, a.user_weight, a.ret_num, a.cmt_num, a.like_num, a.ret_num_recent, a.cmt_num_recent, a.like_num_recent, a.total_read_num, a.expose_num, a.act_num, a.inter_act_num, a.expose_num_recent, a.act_num_recent, a.inter_act_num_recent, a.hot_ret_num, a.hot_cmt_num, a.hot_like_num, a.hot_ret_num_recent, a.hot_cmt_num_recent, a.hot_like_num_recent, a.article_read_num, a.miaopai_view_num, a.all_group_msg, a.hour_group_msg, a.extend
		from
		(
		 select
		 uid, mid, max(is_click) as max_click
		 from
		 $input_table_name
		 where 
		 dt = '$dt_name' 
		 group by uid, mid
		)b 
		join
		(select * from $input_table_name where dt ='$dt_name' ) a
		on
		a.uid=b.uid
		and a.mid=b.mid
		and a.is_click=b.max_click
		inner join
		(
		 select 
		 c.u as uid_persist 
		 from 
		 (
		  select 
		  uid as u, count(distinct expo_time) as e, sum(is_click) as i 
		  from 
		  $input_table_name 
		  where 
		  dt = '$dt_name' group by uid 
		 )c
		 where 
		 c.i > 0 and c.e <= 50
		)d
		on
		a.uid=d.uid_persist;
	select sum(is_click), count(*), sum(is_click)/count(*) from $output_table_name where dt='$dt_name'; 
	"

}

function data_clean_strategy_4(){

# fliter samples with auto-play
# fliter samples generated by users who do not click a weibo in a single day
# fliter samples generated by users who refresh more than 100 times in a single day

	input_table_name=$1
		dt_name=$2
		output_table_name=$3
#odpscmd -e "select b.u from (select uid as u, count(distinct expo_time) as e, sum(is_click) as i from $input_table_name where dt = '$dt_name' and (isautoplay is null or isautoplay = 0) group by uid )b where b.i > 0 and b.e <= 50" > $uid_fliter_config_file 
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
	insert overwrite table 
		$output_table_name partition(dt=$dt_name, hour=$dt_name) 
		select 
		a.is_click, a.actions, a.isautoplay, a.mid, a.duration, a.uid, a.born, a.gender, a.area_id, a.user_tags, a.doc_tags, a.author_id, a.expo_time, a.network_type, a.recommend_source, a.recommend_base_level, a.category, a.first_level_inte_weight, a.second_level_inte_weight, a.third_level_inte_weight, a.effect_weight, a.pic_weight, a.article_weight, a.video_weight, a.obj_weight, a.user_weight, a.ret_num, a.cmt_num, a.like_num, a.ret_num_recent, a.cmt_num_recent, a.like_num_recent, a.total_read_num, a.expose_num, a.act_num, a.inter_act_num, a.expose_num_recent, a.act_num_recent, a.inter_act_num_recent, a.hot_ret_num, a.hot_cmt_num, a.hot_like_num, a.hot_ret_num_recent, a.hot_cmt_num_recent, a.hot_like_num_recent, a.article_read_num, a.miaopai_view_num, a.all_group_msg, a.hour_group_msg, a.extend, a.extend2, a.extend3 
		from
		(
		 select
		 uid, mid, max(is_click) as max_click
		 from
		 $input_table_name
		 where 
		 dt = '$dt_name' 
		 group by uid, mid
		)b 
		join
		(select * from $input_table_name where dt ='$dt_name' ) a
		on
		a.uid=b.uid
		and a.mid=b.mid
		and a.is_click=b.max_click
		inner join
		(
		 select 
		 c.u as uid_persist 
		 from 
		 (
		  select 
		  uid as u, count(distinct expo_time) as e, sum(is_click) as i 
		  from 
		  $input_table_name 
		  where 
		  dt = '$dt_name' group by uid 
		 )c
		 where 
		 c.i > 0 and c.e <= 100
		)d
		on
		a.uid=d.uid_persist;
	select sum(is_click), count(*), sum(is_click)/count(*) from $output_table_name where dt='$dt_name'; 
	"

}



function data_clean(){

		input_table=$HOT_WEIBO_CORPUS_TABLE_NAME
		input_dt=$1
		output_table=$HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME
		create_hot_weibo_corpus_data_clean_table
		partition_name="dt=$input_dt, hour=$input_dt"
		create_partition $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME "$partition_name"
#data_clean_strategy_2 $input_table $input_dt $output_table
#data_clean_strategy_3 $input_table $input_dt $output_table
		data_clean_strategy_4 $input_table $input_dt $output_table

}

function gen_equ_freq_discrete_array_string(){
		count=$1
		array_str="array("
		rate=`echo "scale=4; 1/$count" | bc`
		count_max=`echo "$count - 1" | bc`
		rate_current=0
		split_str=","
		for(( i=0 ; i<$count_max;i++ ))
			do
				rate_current=`awk 'BEGIN{printf "%.4f\n", "'$rate'"+"'$rate_current'" }'`
#echo array_str
					if [ $i -eq 0 ]
						then
							array_str=${array_str}${rate_current}
					else
						array_str=${array_str}${split_str}${rate_current}
#echo "None of the condition met"
			fi
				done
				array_str=${array_str}")"
				echo $array_str

}

function gen_discrete_temp_table(){
		dt_name=$1
		sub_dt_name=$2
		classify_name=${dt_name}'_'${sub_dt_name}
		create_discrete_temp_table
		train_part="classify='$classify_name'"
		is_exists=`is_partition_exists $classify_name $HOT_WEIBO_DISCRETE_CONFIG_FILE_TABLE`
		if [ "$is_exists" == "true" ];then
			echo "partition:$classify_name of table :$HOT_WEIBO_DISCRETE_CONFIG_FILE_TABLE exists!"
		else
			create_partition $HOT_WEIBO_DISCRETE_CONFIG_FILE_TABLE "$train_part"
				echo "********************************** to generate temp table for discrete (partition: classify='$classify_name', table_name: '$HOT_WEIB
				O_DISCRETE_CONFIG_FILE_TABLE') **********************************"
				hive -e "
				add file gen_train_corpus_0823_discrete_file.py; 
	insert overwrite table
		$HOT_WEIBO_DISCRETE_CONFIG_FILE_TABLE partition($train_part)
		select
		transform(a.*)
		using 'python2.6 gen_train_corpus_0823_discrete_file.py'
		from 
		$HOT_WEIBO_CORPUS_TABLE_FOR_EACH_CATE_NAME a
		where 
		a.dt = '$dt_name' and a.hour = '$sub_dt_name';
	"
		echo "********************************** generating temp table for discrete (partition: classify='$classify_name', table_name: '$HOT_WEIBO
		_DISCRETE_CONFIG_FILE_TABLE') was done! **********************************"
		fi
}


function get_each_fea_distribution(){

		s_dt=$1
		e_dt=$2
		declare -A feature_dis_cnt
		feature_dis_cnt=([0]=10 [1]=10 [2]=10 [3]=27 [4]=27 [10]=13 [11]=17)
		discrete_config_file_part=$s_dt'_'$e_dt
		ind=0
		echo "********************************** to generate equal-freq discrete file:$discrete_config_file **********************************"
		for key in $(echo ${!feature_dis_cnt[*]})
			do
				echo "key is $key and value is ${feature_dis_cnt[$key]}"
					if [ "${feature_dis_selection[$key]}" == "freq" ];
			then
				gen_discrete_temp_table $dt_one_cate_name $sub_dt_one_cate_name
				discrete_array_string=`gen_equ_freq_discrete_array_string ${feature_dis_cnt[$key]}`
				if [ $ind -eq 0 ];
			then
				echo "********************************** to generate percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} **********************************"
				odpscmd -e "select '$key', percentile_approx(cast(a.feature as double), ${discrete_array_string}, 50000) from (select split(features, '\t')[$key] as feature from $HOT_WEIBO_DISCRETE_CONFIG_FILE_TABLE where classify = '$classify_name')a " > $discrete_config_file
				echo "********************************** generating percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} was done ! **********************************"
				let ind++
				else
					echo "********************************** to generate percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} **********************************"
						odpscmd -e "select '$key', percentile_approx(cast(a.feature as double), ${discrete_array_string}, 50000) from (select split(features, '\t')[$key] as feature from $HOT_WEIBO_DISCRETE_CONFIG_FILE_TABLE where classify = '$classify_name')a " >> $discrete_config_file
						echo "********************************** generating percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} was done ! **********************************"
						fi
					else
						if [ $ind -eq 0 ];
			then
				echo "********************************** to generate percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} **********************************"
#echo "${key}    $(cat `pwd`'/'${classify_name}'_'${key})" > $discrete_config_file
				echo "$(cat `pwd`'/ylb_discrete_features_config')" > $discrete_config_file
				echo "********************************** generating percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} was done ! **********************************"
				let ind++
						else
							echo "********************************** to generate percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} **********************************"
#echo "${key}    $(cat `pwd`'/'${classify_name}'_'${key})" >> $discrete_config_file
								echo "********************************** generating percentile of feature: $key with count:${feature_dis_cnt[$key]} using equal ${feature_dis_selection[$key]} was done ! **********************************"
								fi
								fi
								done
								echo "********************************** generate equal-freq discrete file:$discrete_config_file successfully ! **********************************"

} 

function create_hot_weibo_real_read_table(){

	create_table_like_other_table $HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE $HOT_WEIBO_BASE_FEATURES_TABLE $HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE_LOCATION
}


function gen_hot_weibo_real_read_for_deep(){
		dt=$1
		res_dt=$dt'_256_64_res'
		odpscmd -e "
		create table if not exists $HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE like binbin7_hot_mblog_real_base_features;
	insert overwrite table $HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE partition(dt=$dt) select 
		b.is_click, 
		b.actions, 
		b.isautoplay, 
		b.uid, 
		b.born, 
		b.gender, 
		b.area_id, 
		b.province_id, 
		b.mid, 
		b.duration, 
		b.recommend_source, 
		b.recommend_base_level, 
		b.category, 
		b.effect_weight, 
		b.pic_num, 
		b.mblog_long_pic_num, 
		b.mblog_gif_num, 
		b.article_weight, 
		b.video_weight, 
		b.obj_weight, 
		b.content_form, 
		b.mblog_level, 
		b.mblog_topic_num, 
		b.text_len,  
		b.ret_num, 
		b.cmt_num, 
		b.like_num, 
		b.ret_num_recent, 
		b.cmt_num_recent, 
		b.like_num_recent, 
		b.total_read_num, 
		b.expose_num, 
		b.act_num, 
		b.inter_act_num, 
		b.expose_num_recent, 
		b.act_num_recent,  
		b.inter_act_num_recent, 
		b.hot_ret_num, 
		b.hot_cmt_num, 
		b.hot_like_num, 
		b.hot_ret_num_recent, 
		b.hot_cmt_num_recent, 
		b.hot_like_num_recent,
		b.group_expose_num, 
		b.group_act_num, 
		b.group_inter_act_num, 
		b.group_ret_num, 
		b.group_cmt_num, 
		b.group_like_num, 
		b.group_expose_num_recent, 
		b.group_act_num_recent, 
		b.group_inter_act_num_recent, 
		b.group_ret_num_recent, 
		b.group_cmt_num_recent, 
		b.group_like_num_recent, 
		b.mid_click_rate, 
		b.mid_inter_act_rate, 
		b.mid_click_num_rate, 
		b.mid_group_click_rate, 
		b.mid_group_inter_act_rate, 
		b.mid_group_click_num_rate, 
		b.inter_count, 
		b.hot_inter_count, 
		b.article_read_num, 
		b.miaopai_view_num, 
		b.second_level_valid_tag, 
		b.third_level_valid_tag, 
		b.topic_valid_tag, 
		b.key_word_valid_tag, 
		b.author_id, 
		b.author_verified_type, 
		b.author_user_class, 
		b.author_user_property, 
		b.author_followers_num, 
		b.author_property_and_verified_type, 
		b.author_user_weight,  
		a.match_level, 
		b.second_level_inte_weight, 
		b.third_level_inte_weight, 
		b.first_level_match_tag, 
		b.second_level_match_tag, 
		b.third_level_match_tag, 
		b.user_second_match_tag_value, 
		b.mblog_second_match_tag_value, 
		b.user_third_match_tag_value, 
		b.mblog_third_match_tag_value, 
		b.user_author_intimacy, 
		b.is_match_long_interest, 
		b.is_match_short_interest, 
		b.first_level_inte_group_ctr, 
		b.second_level_inte_group_ctr, 
		b.third_level_inte_group_ctr,  
		b.expo_time, 
		b.network_type, 
		b.is_match_location, 
		b.province_group_ctr, 
		b.author_user_ability_tags, 
		b.is_match_author_ability
			from 
			(select uid, mid,  dist_score as match_level, label from binbin7_comp_embedding_feature where dt='$dt') a  
			join
			(select * from binbin7_hot_mblog_real_base_features where dt='$dt') b
			on
			a.uid = b.uid and a.mid = b.mid and a.label = b.is_click;"
#(select split_part(split_part(sample,' ',1),'.',1) as uid, split_part(split_part(sample,' ',1),'.',2) as mid, split_part(sample,' ',2) as match_level from sample_for_dnn_from_data_plus_csv where dt='$res_dt') a  

}


function gen_hot_weibo_train_libsvm_table(){
		s_dt=$1
		e_dt=$2
		train_classify=$3
		born=$4
		gender=$5
		create_hot_weibo_train_libsvm_table
#create function binbin7_gen_hot_weibo_features_libsvm as GenHotWeiboInterLibsvm0420 using 'genHotWeiboCorpus_binbin7.jar' -f;
		train_part="version='$train_classify'"
		create_partition $HOT_WEIBO_TRAIN_LIBSVM_TABLE_NAME "$train_part"
		echo "********************************** to generate samples for train (s_dt='$s_dt', e_dt='$e_dt', version='$train_classify', table_name:'$HOT_WEIBO_TRAIN_LIBSVM_TABLE_NAME') **********************************"
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		set odps.stage.mapper.split.size=1024;
		Add jar target/genHotWeiboCorpus_binbin7.jar -f;
		create function binbin7_gen_hot_weibo_features_libsvm as GenHotWeiboClkLibsvm0516 using 'genHotWeiboCorpus_binbin7.jar' -f;
		insert overwrite table
			$HOT_WEIBO_TRAIN_LIBSVM_TABLE_NAME partition($train_part)
		select
			binbin7_gen_hot_weibo_features_libsvm('0',is_click,features,pic_num,mblog_long_pic_num,mblog_gif_num,article_num,video_num,obj_num,actions,isautoplay,first_level_match_tag, second_level_match_tag, third_level_match_tag, duration, uid, mid) as (label, features_list, uid, mid)
		from
			$HOT_WEIBO_LIBSVM_TABLE_NAME a
		where
			a.dt >= $s_dt and a.dt <= $e_dt ;
	"
		echo "********************************** generate samples for train (s_dt='$s_dt', e_dt='$e_dt', cate='$train_classify', table_name:$HOT_WEIBO_TRAIN_LIBSVM_TABLE_NAME ) successfully ! **********************************"

}

function gen_hot_weibo_fm_table(){
		s_dt=$1
		e_dt=$2
		train_classify=$3
		born=$4
		gender=$5
		create_hot_weibo_fm_table 
		train_part="version='$train_classify'"
		create_partition $HOT_WEIBO_FM_TABLE_NAME "$train_part"
#inter coeff:22
		echo "********************************** to generate samples for train (s_dt='$s_dt', e_dt='$e_dt', version='$train_classify', table_name:'$HOT_WEIBO_FM_TABLE_NAME') **********************************"
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		set odps.stage.mapper.split.size=1024;
		Add jar target/genHotWeiboCorpus_binbin7.jar -f;
		create function binbin7_gen_hot_weibo_features_fm as GenHotWeiboClkFM0529 using 'genHotWeiboCorpus_binbin7.jar' -f;
		insert overwrite table 
			$HOT_WEIBO_FM_TABLE_NAME partition($train_part)
		select
			binbin7_gen_hot_weibo_features_fm('0',is_click,features,pic_num,mblog_long_pic_num,mblog_gif_num,article_num,video_num,obj_num,actions,isautoplay,first_level_match_tag, second_level_match_tag, third_level_match_tag, duration, uid, mid) as (label, features_list)
		from 
			$HOT_WEIBO_LIBSVM_TABLE_NAME a 
		where
			a.dt >= $s_dt and a.dt <= $e_dt and random() < 0.1; 
	"
		echo "********************************** generate samples for train (s_dt='$s_dt', e_dt='$e_dt', cate='$train_classify', table_name:$HOT_WEIBO_FM_TABLE_NAME ) successfully ! **********************************"

}

function gen_hot_weibo_fm_shujia_test_table(){
		train_classify=$1
		train_fields='positive bigint, negative bigint, feature string, id bigint'
		train_partitions='version string'
		create_partition_table_without_row_format "$HOT_WEIBO_FM_SHUJIA_TEST_TABLE_NAME" "$train_fields" "$train_partitions" "$HOT_WEIBO_FM_SHUJIA_TEST_TABLE_LOCATION"
		train_part="version='$train_classify'"
		create_partition $HOT_WEIBO_FM_SHUJIA_TEST_TABLE_NAME "$train_part"
		echo "********************************** to generate samples for train (s_dt='$s_dt', e_dt='$e_dt', version='$train_classify', table_name:'$HOT_WEIBO_FM_SHUJIA_TEST_TABLE_NAME') **********************************"
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		set odps.stage.mapper.split.size=1024;
		insert overwrite table 
			$HOT_WEIBO_FM_SHUJIA_TEST_TABLE_NAME partition($train_part)
		select
			case when label > 0 then 1 else 0 end as positive, case when label > 0 then 0 else 1 end as negative, replace(features_list,' ',','), 1 
		from 
			$HOT_WEIBO_FM_TABLE_NAME a 
		where
			version='$train_classify'; 
	"
		echo "********************************** generate samples for train (s_dt='$s_dt', e_dt='$e_dt', cate='$train_classify', table_name:$HOT_WEIBO_FM_SHUJIA_TEST_TABLE_NAME ) successfully ! **********************************"

}
function gen_hot_weibo_fm_shujia_table(){
		train_classify=$1
		train_fields='positive bigint, negative bigint, feature string'
		train_partitions='version string'
		create_partition_table_without_row_format "$HOT_WEIBO_FM_SHUJIA_TABLE_NAME" "$train_fields" "$train_partitions" "$HOT_WEIBO_FM_SHUJIA_TABLE_LOCATION"
		train_part="version='$train_classify'"
		create_partition $HOT_WEIBO_FM_SHUJIA_TABLE_NAME "$train_part"
		echo "********************************** to generate samples for train (s_dt='$s_dt', e_dt='$e_dt', version='$train_classify', table_name:'$HOT_WEIBO_FM_SHUJIA_TABLE_NAME') **********************************"
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		set odps.stage.mapper.split.size=1024;
		insert overwrite table 
			$HOT_WEIBO_FM_SHUJIA_TABLE_NAME partition($train_part)
		select
			case when label > 0 then 1 else 0 end as positive, case when label > 0 then 0 else 1 end as negative, replace(features_list,' ',',') 
		from 
			$HOT_WEIBO_FM_TABLE_NAME a 
		where
			version='$train_classify'; 
	"
		echo "********************************** generate samples for train (s_dt='$s_dt', e_dt='$e_dt', cate='$train_classify', table_name:$HOT_WEIBO_FM_SHUJIA_TABLE_NAME ) successfully ! **********************************"

}


function check_data_percentile(){
	odpscmd -e "
		PAI -name Quantile -project weibo_ml -DinputTableName=$HOT_WEIBO_LIBSVM_TABLE_NAME -DcolName=firstLevelTnteType,secondLevelTnteType, thirdLevelTnteType, inteCount, hotInterCount, effectWeight, articleClickRate, videoClickRate, picClickRate, articleGroupClickRate, videoGroupClickRate, picGroupClickRate, articleInterRate, videoInterRate, picInterRate, articleGroupInterRate, videoGroupInterRate, picGroupInterRate, writerUserAttractionAllCate1, writerUserAttractionAllCate2, readerWriterIntimacy, u2firstLevelTagsClickRate, u2secondLevelTagsClickRate, u2thirdLevelTagsClickRate -DoutputTableName=$HOT_WEIBO_LIBSVM_TABLE_NAME'_analyse' -D 10;
	"
}


function ps_train_libsvm(){
		version_part=$1
		model_part=$version_part
		create_partition_table_without_row_format "$HOT_WEIBO_MODEL_TABLE_NAME" "key bigint, value double" "version string"
		create_partition "$HOT_WEIBO_MODEL_TABLE_NAME" "version='$model_part'"
		odpscmd -e "
		param_server -i ${HOT_WEIBO_TRAIN_LIBSVM_TABLE_NAME}/version=$version_part -o $HOT_WEIBO_MODEL_TABLE_NAME/version=$model_part -a OptOwlqn -extrastr {\"worker_num\":300,\"worker_memory\":20480,\"server_num\":150,\"server_memory\":4096,\"server_cpu\":500,\"worker_cpu\":700,\"worker_high_water_mark\":\"15\",\"worker_low_water_mark\":\"5\",\"algorithm.class.conf\":\"{\\\"l2_weight\\\":0.01,\\\"item_delimiter\\\":\\\"\u0020\\\",\\\"tolerance\\\":1.0E-5,\\\"model_size\\\":2488255,\\\"l1_weight\\\":0,\\\"objective_name\\\":\\\"ObjectiveSparseKV\\\",\\\"kv_delimiter\\\":\\\":\\\",\\\"iteration_limit\\\":300,\\\"feature_columns\\\":[1],\\\"label_columns\\\":[0],\\\"compact_mode\\\":true}\"};
	"
}

function ps_train_fm(){
		version_part=$1
		model_part=$2
		create_partition_table_without_row_format "binbin7_fm_weight_table" "key bigint, value double" "version string"
		create_partition_table_without_row_format "binbin7_fm_factor_table" "rownumber bigint, colnumber bigint, value double" "version string"
		create_partition "binbin7_fm_weight_table" "version='$model_part'"
		create_partition "binbin7_fm_factor_table" "version='$model_part'"
		odpscmd -e "
		param_server -i ${HOT_WEIBO_FM_SHUJIA_TABLE_NAME}/version=$version_part -o binbin7_fm_weight_table/version=$model_part,binbin7_fm_factor_table/version=$model_part -a FM -f 62145 -extrastr {\"server_num\":150,\"worker_num\":500,\"server_cpu\":500,\"worker_cpu\":700,\"worker_memory\":20480,\"server_memory\":10240,\"algorithm.class.conf\":\"{\\\"maxiter\\\":100,\\\"MiniBatch\\\":100,\\\"feature.size\\\":62145,\\\"Use.Serialize\\\":\\\"false\\\",\\\"K\\\":20,\\\"w.l1\\\":0.0,\\\"DataType\\\":1}\"};
	"
}


function gen_test_set(){
		s_dt=$1
		e_dt=$2
		test_part=$3
		odpscmd -e "
		create table if not exists binbin7_lr_predict_score (uid string, score double, label bigint) partitioned by (version string) lifecycle 30;
		insert overwrite table
		binbin7_lr_predict_score partition(version=\"$test_part\")
		select 
		a.uid, b.ctr, a.is_click
		from 
		( select uid, mid, is_click from $HOT_WEIBO_CORPUS_TABLE_NAME where dt >=$s_dt and dt <= $e_dt and recommend_source in ('2','1','5','4','7') and substr(uid, -4, 1) in ('8')) a
		join
		(select uid, id, ctr from ods_tblog_hotmblog_exposure_storage where dt >= $s_dt and dt <= $e_dt) b
		on 
		a.uid = b.uid and a.mid = b.id;
	"
#( select uid, mid, is_click from $HOT_WEIBO_CORPUS_TABLE_NAME where dt >=$s_dt and dt < $e_dt and recommend_source in ('2','1','5','4','7') and substr(uid, -4, 2) in ('80','81','82','83','84')) a
}

function get_auc_with_udf(){
		SCORE_TABLE_NAME='binbin7_lr_predict_score'
		model_partition=$1
		test_set_partition=$2
		#1.this is for libsvm format
		#odpscmd -e "
		#add jar target/lr_predictor.jar -f;
		#create function opt_predict_binbin7 as 'odps.ml.ps.Predictor' using 'lr_predictor.jar, lr_model' -f;"
		#odpscmd -e '
		#set odps.stage.mapper.jvm.mem=8192;
		#set odps.stage.mapper.mem=12288;
		#insert overwrite table '$SCORE_TABLE_NAME' select opt_predict_binbin7("{\"loss_name\":\"LogisticLoss\",\"objective_name\":\"ObjectiveSparseKV\",\"kv_delimiter\":\":\",\"item_delimiter\":\"\\u0020\",\"data_include_bias\":false}", features) as score, is_click from '$HOT_WEIBO_LIBSVM_TABLE_NAME' where version = "'$test_set_partition'" ;'
		#2.this is for binary format
		odpscmd -e "
		add jar target/lr-predict-udf-1.0-SNAPSHOT-jar-with-dependencies.jar -f;
		add table $HOT_WEIBO_MODEL_TABLE_NAME partition(version='$model_partition') as lr_model -f;
		create function opt_predict_binbin7 as 'com.aliyun.pai.Predictor' using 'lr-predict-udf-1.0-SNAPSHOT-jar-with-dependencies.jar, lr_model' -f;
		create table if not exists $SCORE_TABLE_NAME (score double, label bigint) lifecycle 100;
		insert overwrite table $SCORE_TABLE_NAME select opt_predict_binbin7(\"{\\\"loss_name\\\":\\\"LogisticLoss\\\",\\\"objective_name\\\":\\\"ObjectiveSparse\\\",\\\"item_delimiter\\\":\\\",\\\",\\\"data_include_bias\\\":false}\", features_id_list) as score, case when positive > 0 then 1 else 0 end from $HOT_WEIBO_TEST_TABLE_NAME where version = '$test_set_partition' ;
"
		#3.this is for fm of shujia
		#create_partition_table_without_row_format "binbin7_fm_score_table" "id string,positive double,negative double, score double" "version string"
		#create_partition "binbin7_fm_score_table" "version='$test_set_partition'"
		#odpscmd -e "
		#param_server -i ${HOT_WEIBO_FM_SHUJIA_TEST_TABLE_NAME}/version=$test_set_partition,binbin7_fm_weight_table/version=$model_partition,binbin7_fm_factor_table/version=$model_partition -o binbin7_fm_score_table/version=$test_set_partition  -a fm_predict -f 62145 -extrastr {\"server_num\":100,\"worker_num\":200,\"server_cpu\":500,\"worker_cpu\":700,\"worker_memory\":10240,\"server_memory\":4096,\"algorithm.class.conf\":\"{\\\"featureSize\\\":62145,\\\"Use.Serialize\\\":\\\"false\\\",\\\"k\\\":20,\\\"id\\\":\\\"3\\\",\\\"DataType\\\":1}\"};
		#create table if not exists $SCORE_TABLE_NAME (score double, label bigint) lifecycle 100;
		#insert overwrite table $SCORE_TABLE_NAME select score, case when positive > 0 then 1 else 0 end from binbin7_fm_score_table where version = '$test_set_partition' ;
		#"
		#this is getting auc
		odpscmd -e "
		drop table if exists binbin7_evaluate_metric_table;
		drop table if exists binbin7_evaluate_detail_table;
		pai 
			-name=evaluate 
			-DoutputMetricTableName=binbin7_evaluate_metric_table 
			-DoutputDetailTableName=binbin7_evaluate_detail_table 
			-DinputTableName=$SCORE_TABLE_NAME 
			-DlabelColName=label 
			-DscoreColName=score;
		select * from binbin7_evaluate_metric_table;
	"
}

function get_auc_with_udf_new(){
		model_partition=$1
		test_set_partition=$2
		set -e
		set -x
		odpscmd -e "
		add jar target/lr-predict-udf-1.0-SNAPSHOT-jar-with-dependencies.jar -f;
		add table $HOT_WEIBO_MODEL_TABLE_NAME partition(version='$model_partition') as lr_model -f;
		create function opt_predict_binbin7 as 'com.aliyun.pai.Predictor' using 'lr-predict-udf-1.0-SNAPSHOT-jar-with-dependencies.jar, lr_model' -f;"
		odpscmd -e 'create table if not exists binbin7_lr_predict_score (uid string, score double, label bigint) lifecycle 30;'
		odpscmd -e 'set odps.stage.mapper.jvm.mem=8192;set odps.stage.mapper.mem=12288;insert overwrite table binbin7_lr_predict_score select uid, opt_predict_binbin7("{\"loss_name\":\"LogisticLoss\",\"objective_name\":\"ObjectiveSparse\",\"item_delimiter\":\"\\u0020\",\"data_include_bias\":false}", features_id_list) as score, case when positive > 0 then positive else 0 end from '$HOT_WEIBO_TEST_TABLE_NAME' where version = "'$test_set_partition'" ;'
		odpscmd -e "
		set odps.stage.mapper.jvm.mem = 4096;
		set odps.stage.reducer.jvm.mem = 8192;

		add jar target/genHotWeiboCorpus_binbin7.jar -f;
		create function get_lr_auc as GetLrAuc using 'genHotWeiboCorpus_binbin7.jar' -f;
		create table if not exists binbin7_uid_auc (uid string, auc double) lifecycle 30;
		insert overwrite table
		binbin7_uid_auc
		select
		'a', get_lr_auc(uid, score, label)
		from
		binbin7_lr_predict_score
		"
		group by uid
}

function get_test_set_auc(){
		s_dt=$1
		e_dt=$2
		test_set=$3
		gen_test_set $s_dt $e_dt $test_set
		odpscmd -e "
		set odps.stage.mapper.jvm.mem = 4096;
		set odps.stage.reducer.jvm.mem = 12288;

		add jar target/genHotWeiboCorpus_binbin7.jar -f;
		create function binbin7_get_lr_auc as GetLrAuc using 'genHotWeiboCorpus_binbin7.jar' -f;
		select
		binbin7_get_lr_auc(uid, score, label)
		from
		binbin7_lr_predict_score where version=\"$test_set\"
		"
}

function get_valid_model(){
		model_part=$1
		model_name="binbin7_model_tmp_$model_part"
		odpscmd -e "
		create table if not exists $model_name (key bigint, value double) lifecycle 7;
		insert overwrite table $model_name select key,value from $HOT_WEIBO_MODEL_TABLE_NAME where version='$model_part' and abs(value) >= 0.000001;
		tunnel download $model_name model/model_$model_part; 
	"
}

# 入口函数
function iterate_gen_train_day_table(){
		s_dt=$1
		s_dt_orig=$s_dt
		e_dt=$2
		while [ $s_dt_orig -lt $e_dt ]
		do
			cur_day=$s_dt_orig
			merge_user_and_doc_properties_for_October $cur_day
			gen_hot_weibo_base_features_table_for_October $cur_day 'mid_first_tags_55' 'user_interest_cold_start_file'
			gen_hot_weibo_real_read_table $cur_day
			gen_hot_weibo_libsvm_table $cur_day
			s_dt_orig=`date +%Y%m%d -d "$cur_day 1 days"`
		done
}

# merge user and doc features to $HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE
function merge_user_and_doc_properties_for_October(){
		dt_name=$1
		create_hot_weibo_merge_user_and_doc_properties
		merge_part="dt=$dt_name"
		create_partition $HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE "$merge_part"
		echo "********************************** to merge with user and doc parperties tables (partition:'dt=$dt_name, hour=$sub_dt_name', table_name:'$HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE') **********************************"
		reader_intimacy_table_dt=`get_latest_partition "hot_mblog_user_intimacy_plat" "$dt_name" "2"`
		echo "hot_mblog_user_intimacy_plat: "$reader_intimacy_table_dt
		user_long_interests_dt=`get_latest_partition "user_long_interest_modified_for_hotmblog" "$dt_name" "5"`
		echo "user_long_interest_modified_for_hotmblog: "$user_long_interests_dt
		user_short_interests_dt=`get_latest_partition "users_short_interest_in_interest_based_reading" "$dt_name" "2"`
		echo "users_short_interest_in_interest_based_reading: "$user_short_interests_dt
		seven_day_before_dt=`date +%Y%m%d -d "$dt_name -7 days"`
		three_day_before_dt=`date +%Y%m%d -d "$dt_name -3 days"`
		two_day_before_dt=`date +%Y%m%d -d "$dt_name -2 days"`
		echo "seven_day_before_dt:"$seven_day_before_dt
		odpscmd -e "
		set odps.sql.planner.mode=lot;
		set odps.sql.joiner.instances=2000;
		set odps.sql.groupby.skewindata=true;
		insert overwrite table
		$HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE partition($merge_part)
		select
		h.is_click, h.actions, h.isautoplay, h.mid, h.duration, h.uid, h.born, h.gender, h.area_id, h.user_tags, d.content_attribute, h.author_id, h.expo_time, h.network_type, h.recommend_source, h.recommend_base_level, h.category, h.first_level_inte_weight, h.second_level_inte_weight, h.third_level_inte_weight, h.effect_weight, d.pic_num, d.mblog_article_num, d.mblog_miaopai_num, d.mblog_card_num, h.user_weight, h.ret_num, h.cmt_num, h.like_num, h.ret_num_recent, h.cmt_num_recent, h.like_num_recent, h.total_read_num, h.expose_num, h.act_num, h.inter_act_num, h.expose_num_recent, h.act_num_recent,  h.inter_act_num_recent, h.hot_ret_num, h.hot_cmt_num, h.hot_like_num, h.hot_ret_num_recent, h.hot_cmt_num_recent, h.hot_like_num_recent, h.article_read_num, h.miaopai_view_num, h.all_group_msg, h.hour_group_msg, h.extend, h.extend2, h.extend3, concat(b.f1,',',b.f2,',',b.f3), concat(g.interests1,',',g.interests2,',',g.interests3), e.intimacy, null, d.author_attribute, null, d.format_attribute, null, null, concat(i.device,'@',m.lgn_all), concat(j.u_iar_month,',',j.u_clickr_month,',',j.u_iar_week,',',j.u_clickr_week,',',k.lgn_all), null
		from
		(select distinct uid,mid,author_id from $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME where dt=$dt_name and instr(category, '1042015:dujia') = 0 and instr(category, 'yunying') = 0)a
		left outer join
		(select uid,u_iar_month,u_clickr_month,u_iar_week,u_clickr_week from mds_strategy_feed_user_rate where dt=$three_day_before_dt) j
		on
		(
		 a.author_id = j.uid
		)
		left outer join
		(
		 select uid,lgn_all from mds_bas_user_usagefreq where dt=$three_day_before_dt
		) k
		on
		(
		 a.author_id = k.uid
		)
		left outer join
		(select uid,device from bigdata_vf_user_device_type where dt=$dt_name) i
		on
		(
		 a.uid = i.uid
		)
		left outer join
		(select * from hot_mblog_user_intimacy_plat where dt = '$reader_intimacy_table_dt') e
		on
		(
		 a.uid=e.uid
		)
		left outer join
		( select * from user_long_interest_modified_for_hotmblog where dt='$user_long_interests_dt') b
		on
		(
		 a.uid=b.uid
		)
		left outer join
		(select * from users_short_interest_in_interest_based_reading where dt='$user_short_interests_dt') g
		on
		(
		 a.uid = g.uid
		)
		left outer join
		(
		 select
		 *
		 from
		 (
		  select
		  mid,content_attribute,author_attribute,format_attribute,
		  pic_num, mblog_gif_num, mblog_long_pic_num, mblog_article_num, mblog_miaopai_num, mblog_card_num,
		  ROW_NUMBER() OVER (partition by mid order by expose_num desc) as nums
		  from
		  hot_mblog_recommend_mblog_info
		  where
		  dt>='$seven_day_before_dt' and dt<='$dt_name'
		 ) tmp where tmp.nums = 1
		) d
		on
		(
		 a.mid=d.mid
		)
		right outer join
		( select * from $HOT_WEIBO_CORPUS_DATA_CLEAN_TABLE_NAME where dt=$dt_name and instr(category, '1042015:dujia') = 0 and instr(category, 'yunying') = 0 ) h
		on
		(
		 a.uid = h.uid and a.mid = h.mid and a.author_id = h.author_id
		)
		"
# 	left outer join
# 		(select mid, wm_concat('|', concat(keyword_id, '@', weight)) as key_word_list from bigdata_corpus_keyword_offline_formatted_dt where dt >= $seven_day_before_dt and dt <= $dt_name group by mid) f
# 	on
# 	(
# 		a.mid = f.mid
# 	)
# "
#	left outer join
#		(select mid, wm_concat(',', concat(topic_id, '-', topic_weight)) as topic_list from bigdata_lightlda_topic_offline_formatted_dt where dt >= $seven_day_before_dt and dt <= $dt_name group by mid) c
#	on
#	(
#		a.mid = c.mid
#	)
#"
		echo "********************************** generate merge with user and doc properties tables (partition:'dt=$dt_name, hour=$sub_dt_name', table_name:$HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE successfully ! **********************************"

}


function gen_hot_weibo_base_features_table_for_October(){
		dt_name=$1
		first_tag_feature_config_file=$2
		user_interest_cold_start_file=$3
		create_hot_weibo_base_features_table
		train_part="dt='$dt_name'"
		create_partition $HOT_WEIBO_BASE_FEATURES_TABLE "$train_part"
		echo "********************************** to generate base features for train (table_name:'$HOT_WEIBO_BASE_FEATURES_TABLE', dt='$dt_name') **********************************"
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		ALIAS first_tag_feature_config=$first_tag_feature_config_file;
		Add jar target/genHotWeiboCorpus_binbin7.jar -f;
		add file conf/$first_tag_feature_config_file -f;
		add file conf/first_tag_feature_config -f;
		add file conf/$user_interest_cold_start_file -f;

		create function binbin7_gen_hot_weibo_base_features_new as GenHotWeiboBaseFeatures180423 using 'genHotWeiboCorpus_binbin7.jar, first_tag_feature_config, $user_interest_cold_start_file' -f;

		insert overwrite table
		$HOT_WEIBO_BASE_FEATURES_TABLE partition($train_part)
		select
		is_click,
		actions,
		isautoplay,
		uid,
		born,
		gender,
		area_id,
		province_id,
		mid,
		duration,
		recommend_source,
		recommend_base_level,
		category,
		effect_weight,
		pic_weight,
		mblog_long_pic_num,
		mblog_gif_num,
		article_weight,
		video_weight,
		obj_weight,
		content_form,
		mblog_level,
		mblog_topic_num,
		text_len,
		ret_num,
		cmt_num,
		like_num,
		ret_num_recent,
		cmt_num_recent,
		like_num_recent,
		total_read_num,
		expose_num,
		act_num,
		inter_act_num,
		expose_num_recent,
		act_num_recent,
		inter_act_num_recent,
		hot_ret_num,
		hot_cmt_num,
		hot_like_num,
		hot_ret_num_recent,
		hot_cmt_num_recent,
		hot_like_num_recent,
		group_expose_num,
		group_act_num,
		group_inter_act_num,
		group_ret_num,
		group_cmt_num,
		group_like_num,
		group_expose_num_recent,
		group_act_num_recent,
		group_inter_act_num_recent,
		group_ret_num_recent,
		group_cmt_num_recent,
		group_like_num_recent,
		mid_click_rate,
		mid_inter_act_rate,
		mid_click_num_rate,
		mid_group_click_rate,
		mid_group_inter_act_rate,
		mid_group_click_num_rate,
		0.6*ret_num+0.4*like_num as inter_count,
		0.6*hot_ret_num+0.4*hot_like_num as hot_inter_count,
		article_read_num,
		miaopai_view_num,
		second_level_valid_tag,
		third_level_valid_tag,
		null as topic_valid_tag,
		key_word_valid_tag,
		author_id,
		author_verified_type,
		author_user_class,
		author_user_property,
		author_followers_num,
		author_property_and_verified_type,
		user_weight as author_user_weight,
		first_level_inte_weight,
		second_level_inte_weight,
		third_level_inte_weight,
		first_level_match_tag,
		second_level_match_tag,
		third_level_match_tag,
		user_second_match_tag_value,
		mblog_second_match_tag_value,
		user_third_match_tag_value,
		mblog_third_match_tag_value,
		user_author_intimacy,
		is_match_long_interest,
		is_match_short_interest,
		first_level_inte_group_ctr,
		second_level_inte_group_ctr,
		third_level_inte_group_ctr,
		expo_time,
		network_type,
		is_match_location,
		province_group_ctr,
		null as author_user_ability_tags,
		null as is_match_author_ability,
		mid_duration_all,
		mid_duration_uv,
		mid_duration_avg,
		rank_num,
		case
			when instr(tolower(split_part(uid_extend,'@',1)), 'huawei')>0 then 'huawei'
			when instr(tolower(split_part(uid_extend,'@',1)), 'oppo')>0 then 'oppo'
			when instr(tolower(split_part(uid_extend,'@',1)),'vivo')>0 then 'vivo'
			when instr(tolower(split_part(uid_extend,'@',1)),'xiaomi')>0 then 'xiaomi'
			when instr(tolower(split_part(uid_extend,'@',1)),'samsung')>0 then 'samsung'
			when instr(tolower(split_part(uid_extend,'@',1)),'meizu')>0 then 'meizu'
			when instr(tolower(split_part(uid_extend,'@',1)),'lenovo')>0 then 'lenovo'
			when instr(tolower(split_part(uid_extend,'@',1)),'gionee')>0 then 'gionee'
			when instr(tolower(split_part(uid_extend,'@',1)),'htc')>0 then 'htc'
			when instr(tolower(split_part(uid_extend,'@',1)),'iphone')>0 then 'iphone'
			else 'other' end as reader_device,
		split_part(uid_extend,'@',2) as reader_lgn_all,
		split_part(author_extend,',',1) as author_iar_month,
		split_part(author_extend,',',2) as author_clickr_month,
		split_part(author_extend,',',3) as author_iar_week,
		split_part(author_extend,',',4) as author_clickr_week,
		split_part(author_extend,',',5) as author_lgn_all,
		case
		when
			datepart(from_unixtime(substr(expo_time,1,10)),'mi') > 30
		then
			1+2*datepart(from_unixtime(substr(expo_time,1,10)),'hh')
		else
			2*datepart(from_unixtime(substr(expo_time,1,10)),'hh')
		end as expose_time_day_slot,
		weekday(from_unixtime(substr(expo_time,1,10))) as expose_time_week_slot,
		--TODO:contain national holiday and weekend which is not national work day
		case
		when
			substr($dt_name,5,4) in (0101,0215,0216,0219,0220,0221,0405,0406,0430,0501,0618,0924,1001,1002,1003,1004,1005) or (weekday(from_unixtime(substr(expo_time,1,10))) in (5,6) and not substr($dt_name,5,8) in (0211,0224,0408,0428,0929,0930))
		then 'TRUE' else 'FALSE' end as is_holiday,
		mid_feed_expo,
		mid_feed_clk,
		mid_feed_clk_rate
					from
					(
					 select * from
					 $HOT_WEIBO_CORPUS_MERGE_USER_AND_DOC_PROPERTIES_TABLE
					 where
					 dt = '$dt_name'
					) merge_table_tmp
					lateral view binbin7_gen_hot_weibo_base_features_new(mid, born, gender, area_id, doc_tags, author_id, category, pic_weight, article_weight, video_weight, obj_weight, expose_num, act_num, inter_act_num, all_group_msg, hour_group_msg, user_long_interests, user_short_interests, user_intimacy, author_base_attributes, mid_base_attributes, extend2) tmp as
					group_expose_num,
					group_act_num,
					group_inter_act_num,
					group_ret_num,
					group_cmt_num,
					group_like_num,
					group_expose_num_recent,
					group_act_num_recent,
					group_inter_act_num_recent,
					group_ret_num_recent,
					group_cmt_num_recent,
					group_like_num_recent,
					mid_click_rate,
					mid_inter_act_rate,
					mid_click_num_rate,
					mid_group_click_rate,
					mid_group_inter_act_rate,
					mid_group_click_num_rate,
					second_level_valid_tag,
					third_level_valid_tag,
					author_verified_type,
					author_user_property,
					author_followers_num,
					second_level_match_tag,
					third_level_match_tag,
					user_second_match_tag_value,
					mblog_second_match_tag_value,
					user_third_match_tag_value,
					mblog_third_match_tag_value,
					user_author_intimacy,
					content_form,
					author_property_and_verified_type,
					mblog_gif_num,
					mblog_long_pic_num,
					mblog_level,
					author_user_class,
					key_word_valid_tag,
					mblog_topic_num,
					text_len,
					is_match_long_interest,
					is_match_short_interest,
					first_level_inte_group_ctr,
					second_level_inte_group_ctr,
					third_level_inte_group_ctr,
					first_level_match_tag,
					is_match_location,
					province_group_ctr,
					province_id,
					mid_duration_all,
					mid_duration_uv,
					mid_duration_avg,
					rank_num,
					mid_feed_expo,
					mid_feed_clk,
					mid_feed_clk_rate
						;
			"
				echo "********************************** generate base features for train (table_name:$HOT_WEIBO_BASE_FEATURES_TABLE , dt='$dt_name') successfully ! **********************************"

}

# join上真实阅读表，生成真实阅读数据,离散前最后一张表
function gen_hot_weibo_real_read_table(){
		dt_name=$1
		create_hot_weibo_real_read_table
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		insert overwrite table
		$HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE partition(dt=$dt_name)
		select
		is_click,
		actions,
		isautoplay,
		a.uid,
		born,
		gender,
		area_id,
		province_id,
		a.mid,
		b.duration,
		recommend_source,
		recommend_base_level,
		category,
		effect_weight,
		pic_num,
		mblog_long_pic_num,
		mblog_gif_num,
		article_weight,
		video_weight,
		obj_weight,
		content_form,
		mblog_level,
		mblog_topic_num,
		text_len,
		ret_num,
		cmt_num,
		like_num,
		ret_num_recent,
		cmt_num_recent,
		like_num_recent,
		total_read_num,
		expose_num,
		act_num,
		inter_act_num,
		expose_num_recent,
		act_num_recent,
		inter_act_num_recent,
		hot_ret_num,
		hot_cmt_num,
		hot_like_num,
		hot_ret_num_recent,
		hot_cmt_num_recent,
		hot_like_num_recent,
		group_expose_num,
		group_act_num,
		group_inter_act_num,
		group_ret_num,
		group_cmt_num,
		group_like_num,
		group_expose_num_recent,
		group_act_num_recent,
		group_inter_act_num_recent,
		group_ret_num_recent,
		group_cmt_num_recent,
		group_like_num_recent,
		mid_click_rate,
		mid_inter_act_rate,
		mid_click_num_rate,
		mid_group_click_rate,
		mid_group_inter_act_rate,
		mid_group_click_num_rate,
		inter_count,
		hot_inter_count,
		article_read_num,
		miaopai_view_num,
		second_level_valid_tag,
		third_level_valid_tag,
		topic_valid_tag,
		key_word_valid_tag,
		author_id,
		author_verified_type,
		author_user_class,
		author_user_property,
		author_followers_num,
		author_property_and_verified_type,
		author_user_weight,
		first_level_inte_weight,
		second_level_inte_weight,
		third_level_inte_weight,
		first_level_match_tag,
		second_level_match_tag,
		third_level_match_tag,
		user_second_match_tag_value,
		mblog_second_match_tag_value,
		user_third_match_tag_value,
		mblog_third_match_tag_value,
		user_author_intimacy,
		is_match_long_interest,
		is_match_short_interest,
		first_level_inte_group_ctr,
		second_level_inte_group_ctr,
		third_level_inte_group_ctr,
		a.expo_time,
		network_type,
		is_match_location,
		province_group_ctr,
		author_user_ability_tags,
		is_match_author_ability,
		mid_duration_all,
		mid_duration_uv,
		mid_duration_avg,
		rank_num,
		reader_device,
		reader_lgn_all,
		author_iar_month,
		author_clickr_month,
		author_iar_week,
		author_clickr_week,
		author_lgn_all,
		expose_time_day_slot,
		expose_time_week_slot,
		is_holiday,
		mid_feed_expo,
		mid_feed_clk,
		mid_feed_clk_rate
			from
			(select * from $HOT_WEIBO_BASE_FEATURES_TABLE where dt='$dt_name') a
			join
			(select uid, mid, sum(case when read_duration is null then 0.0 else cast(read_duration as double) end) as duration from $HOT_WEIBO_REAL_READ_EXPOSE_TABLE where dt='$dt_name' read_duration is not null group by uid,mid ) b
			on
			a.uid = b.uid and a.mid = b.mid;
	"
#(select uid, mid, sum(case when read_duration is null or read_duration ='\\\N' then 0.0 else cast(read_duration as double) end) as duration from $HOT_WEIBO_REAL_READ_EXPOSE_TABLE where dt='$dt_name' group by uid,mid ) b
}

function gen_hot_weibo_libsvm_table(){
		dt_name=$1
		create_hot_weibo_libsvm_table
		features='uid,born,gender,category,effect_weight,content_form,mid_click_rate,mid_inter_act_rate,mid_click_num_rate,mid_group_click_rate,mid_group_inter_act_rate,mid_group_click_num_rate,inter_count,hot_inter_count,second_level_valid_tag,third_level_valid_tag,key_word_valid_tag,author_verified_type,author_user_property,author_property_and_verified_type,first_level_inte_weight,second_level_inte_weight,third_level_inte_weight,first_level_match_tag,second_level_match_tag,third_level_match_tag,user_second_match_tag_value,mblog_second_match_tag_value,user_third_match_tag_value,mblog_third_match_tag_value,user_author_intimacy,network_type,author_id,author_followers_num,author_user_class,text_len,is_match_location,province_id,province_group_ctr,first_level_inte_group_ctr,second_level_inte_group_ctr,third_level_inte_group_ctr,is_match_long_interest,is_match_short_interest,ret_num,cmt_num,like_num,hot_ret_num,hot_cmt_num,hot_like_num,mid_duration_avg,rank_num,reader_device,reader_lgn_all,author_iar_month,author_clickr_month,author_iar_week,author_clickr_week,expose_time_day_slot,is_holiday,mid_feed_expo,mid_feed_clk,mid_feed_clk_rate'
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		set odps.stage.mapper.jvm.mem = 512;
		set odps.stage.reducer.jvm.mem = 512;
		add file conf/binbin7_hot_weibo_base_features_table.feature.conf -f;
		add jar target/weibo-feature-udf-0.0.1-SNAPSHOT.jar -f;
		create function binbin7_gen_hot_weibo_libsvm_features as 'com.weibo.FeatureUDF' using 'weibo-feature-udf-0.0.1-SNAPSHOT.jar,binbin7_hot_weibo_base_features_table.feature.conf' -f;
		insert overwrite table
			$HOT_WEIBO_LIBSVM_TABLE_NAME partition(dt=$dt_name)
		select
			is_click, binbin7_gen_hot_weibo_libsvm_features('$features', $features) as features, pic_num, mblog_long_pic_num, mblog_gif_num, article_weight, video_weight, obj_weight, actions, isautoplay, uid, mid , born, gender, first_level_match_tag, second_level_match_tag, third_level_match_tag, duration
		from
			$HOT_WEIBO_REAL_READ_BASE_FEATURES_TABLE
		where
#dt='$dt_name' and (category='1042015:tagCategory_031' or category='1042015:tagCategory_009' or category='1042015:tagCategory_055' or category='1042015:tagCategory_007' or category='1042015:tagCategory_028' or category='1042015:tagCategory_058' or category='1042015:tagCategory_044' or category='1042015:tagCategory_005' or category='1042015:tagCategory_004' or category='1042015:tagCategory_045' or category='1042015:tagCategory_035' or category='1042015:tagCategory_005' or category='1042015:tagCategory_043' or category='1042015:tagCategory_061' or category='1042015:tagCategory_021' or category='1042015:tagCategory_001') and expose_num >= 1000 and mid_group_click_num_rate != 'NaN' and author_clickr_month is not null and author_clickr_week is not null;
		dt='$dt_name' and (instr(category, '1042015:tagCategory') != 0) and expose_num >= 1000 and mid_group_click_num_rate != 'NaN' and author_clickr_month is not null and author_clickr_week is not null;
	"
}


function gen_hot_weibo_train_table(){
		s_dt=$1
		e_dt=$2
		train_classify=$3
		born=$4
		gender=$5
		create_hot_weibo_train_table
#create function binbin7_gen_hot_weibo_features_final as GenHotWeiboTrainInter180401 using 'genHotWeiboCorpus_binbin7.jar' -f;
#create function binbin7_gen_hot_weibo_features_final as GenHotWeiboClk180516 using 'genHotWeiboCorpus_binbin7.jar' -f;
		train_part="version='$train_classify'"
		create_partition $HOT_WEIBO_TRAIN_TABLE_NAME "$train_part"
		echo "********************************** to generate samples for train (s_dt='$s_dt', e_dt='$e_dt', version='$train_classify', table_name:'$HOT_WEIBO_TRAIN_TABLE_NAME') **********************************"
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		set odps.stage.mapper.split.size=1024;
		Add jar target/genHotWeiboCorpus_binbin7.jar -f;
		create function binbin7_gen_hot_weibo_features_final as GenHotWeiboClk180516_inter_weight using 'genHotWeiboCorpus_binbin7.jar' -f;
		insert overwrite table
			$HOT_WEIBO_TRAIN_TABLE_NAME partition($train_part)
		select
			binbin7_gen_hot_weibo_features_final('2',is_click,features,pic_num,mblog_long_pic_num,mblog_gif_num,article_num,video_num,obj_num,actions,isautoplay,first_level_match_tag, second_level_match_tag, third_level_match_tag, duration ) as (group_id, features_len, features_id_list, positive, negative)
		from
			$HOT_WEIBO_LIBSVM_TABLE_NAME a
		where
			a.dt >= $s_dt and a.dt <= $e_dt and substr(uid,-1,1) != '0';
	"
		echo "********************************** generate samples for train (s_dt='$s_dt', e_dt='$e_dt', cate='$train_classify', table_name:$HOT_WEIBO_TRAIN_TABLE_NAME ) successfully ! **********************************"

}

function gen_hot_weibo_test_table(){
		s_dt=$1
		e_dt=$2
		train_classify=$3
		create_hot_weibo_test_table
		train_part="version='$train_classify'"
		create_partition $HOT_WEIBO_TEST_TABLE_NAME "$train_part"
		echo "********************************** to generate samples for train (s_dt='$s_dt', e_dt='$e_dt', version='$train_classify', table_name:'$HOT_WEIBO_TEST_TABLE_NAME') **********************************"
#create function binbin7_gen_hot_weibo_test_set as GenHotWeiboTestData using 'genHotWeiboCorpus_binbin7.jar' -f;
#create function binbin7_gen_hot_weibo_test_set as GenHotWeiboTestInter using 'genHotWeiboCorpus_binbin7.jar' -f;
		odpscmd -e "
		set odps.sql.groupby.skewindata=true;
		set odps.stage.mapper.split.size=1024;
		Add jar target/genHotWeiboCorpus_binbin7.jar -f;

		create function binbin7_gen_hot_weibo_test_set as GenHotWeiboTestData using 'genHotWeiboCorpus_binbin7.jar' -f;

		insert overwrite table
			$HOT_WEIBO_TEST_TABLE_NAME partition($train_part)
		select
			binbin7_gen_hot_weibo_test_set('1',is_click,features,pic_num,mblog_long_pic_num,mblog_gif_num,article_num,video_num,obj_num,actions,isautoplay,first_level_match_tag, second_level_match_tag, third_level_match_tag, duration, uid, mid) as (group_id, features_len, features_id_list, positive, negative, uid, mid)
		from
			$HOT_WEIBO_LIBSVM_TABLE_NAME a
		where
			a.dt >= $s_dt and a.dt <= $e_dt and (isautoplay is null or isautoplay = 0 or (isautoplay=1 and duration>3000)) and substr(uid,-1,1) = '0';
	"
		echo "********************************** generate samples for train (s_dt='$s_dt', e_dt='$e_dt', cate='$train_classify', table_name:$HOT_WEIBO_TEST_TABLE_NAME ) successfully ! **********************************"

}

function ps_train(){
		version_part=$1
		create_partition_table_without_row_format "$HOT_WEIBO_MODEL_TABLE_NAME" "key bigint, value double" "version string"
		version_test_part=$version_part
		create_partition "$HOT_WEIBO_MODEL_TABLE_NAME" "version='$version_test_part'"
		odpscmd -e "
param_server -i ${HOT_WEIBO_TRAIN_TABLE_NAME}/version=$version_part,${HOT_WEIBO_TEST_TABLE_NAME}/version=20180818_20180823_all_cates_original_clk_0815_feed -o $HOT_WEIBO_MODEL_TABLE_NAME/version=$version_test_part -a Owlqn -extrastr {\"worker_num\":300,\"worker_memory\":18000,\"server_num\":150,\"server_memory\":4096,\"worker_high_water_mark\":\"15\",\"worker_low_water_mark\":\"5\",\"checkpoint.dir\":\"/20180827/binbin7_hot_mblog_${version_test_part}_checkpoint_path/\",\"algorithm.class.conf\":\"{\\\"l2_weight\\\":0,\\\"tolerance\\\":1.0E-5,\\\"model_size\\\":3145230,\\\"l1_weight\\\":0,\\\"iteration_limit\\\":300,\\\"feature_columns\\\":[2],\\\"label_columns\\\":[3,4],\\\"enable_train_auc\\\":true,\\\"enable_test_auc\\\":true}\"};
	"
}

function main(){
	s_dt=$1
	e_dt=$2
	echo "before clean and merge", $s_dt, $e_dt
#    iterate_gen_train_day_table $s_dt $e_dt

	cate_id='all_cates'
	np_rate='original'

	echo "finish generate libsvm data"
	echo "before gen features", $s_dt, $e_dt
	train_name=${s_dt}'_'${e_dt}'_'${cate_id}'_'${np_rate}'_clk_1108_feed_inter_weight'
#    gen_hot_weibo_train_table $s_dt $e_dt $train_name $born $gender
	gen_hot_weibo_test_table $s_dt $e_dt $train_name
	#gen_hot_weibo_train_libsvm_table $s_dt $e_dt $train_name $born $gender
	#gen_hot_weibo_fm_table $s_dt $e_dt $train_name $born $gender
	#gen_hot_weibo_fm_shujia_table $train_name
	#gen_hot_weibo_fm_shujia_test_table $train_name
	echo "before train", $s_dt, $e_dt
	echo $train_name
	#ps_train $train_name
	#ps_train_libsvm $train_name
	#ps_train_fm $train_name $train_name'_'
	#get_auc_with_udf $train_name '20180430_20180501_all_cates_original_inter_0423'

}

function iterate_gen_libsvm_table(){
	    s_dt=$1
		s_dt_orig=$s_dt
		e_dt=$2
		while [ $s_dt_orig -lt $e_dt ]
		do
			cur_day=$s_dt_orig
			gen_hot_weibo_libsvm_table $cur_day
			s_dt_orig=`date +%Y%m%d -d "$cur_day 1 days"`
		done
}

function gen_data(){
	s_dt=$1
	e_dt=$2
#	iterate_gen_libsvm_table $s_dt $e_dt
	cate_id='all_cates'
	np_rate='original'

	echo "before gen features", $s_dt, $e_dt
#train_name=${s_dt}'_'${e_dt}'_'${cate_id}'_'${np_rate}'_clk_0815_feed'
	train_name=20180817_20180819_ori
	gen_hot_weibo_train_table $s_dt $e_dt $train_name $born $gender
	gen_hot_weibo_test_table 20180820 20180821 20180820_ori
	echo "before train", $s_dt, $e_dt
	echo $train_name
}
main $1 $2
#gen_data $1 $2
