/*
 * parseDataConf.cpp
 *
 *  Created on: 2016年12月23日
 *      Author: huinan1
 */

#include <math.h>
#include <iostream>
#include <fstream>
#include <algorithm>
#include "parseDataConf.h"

// map key: feature index, map value: DataConf struct which contains description in data.conf
bool CDataConfParser::parseDataConf(map<string, DataConf>& featureMap,
        string dataConfPath)
{
    ifstream fin(dataConfPath.c_str());
    if (!fin.is_open())
    {
        cerr << "can't open file: " << dataConfPath << endl;
        return false;
    }

    string line = "";
    // first line is label info
    getline(fin, line);
    int xgboostIndex = 0;
    while (getline(fin, line))
    {
        if (line.empty())
        {
            continue;
        }

        vector<string> featureVec = StringTool::SplitString(line, "@");
        if (featureVec.size() < 3)
        {
            cerr << "data conf file format error: " << line << endl;
            return false;
        }

        DataConf dataConf;
        int featureIndex = atoi(featureVec[0].c_str());
        dataConf.index = featureIndex;
        dataConf.xgboostIndex = xgboostIndex;
        dataConf.name = featureVec[1];
        string featureCategory = featureVec[2];

        std::transform(featureCategory.begin(), featureCategory.end(),
                featureCategory.begin(), ::tolower);

        //label column
        if ("persist" == featureCategory)
        {
            continue;
        }

        dataConf.category = featureCategory;

        if (featureVec.size() == 4)
        {
            vector<string> oper2Args = StringTool::SplitString(featureVec[3],
                    ":");
            if (oper2Args.size() == 1)
            {
                dataConf.operation = featureVec[3];
                dataConf.args = "";
            }
            if (oper2Args.size() == 2)
            {
                dataConf.operation = oper2Args[0];
                dataConf.args = oper2Args[1];
            }
        }

        featureMap[dataConf.name] = dataConf;
        xgboostIndex += 1;
    }

    return true;
}

bool CDataConfParser::getInstance(map<string, DataConf>& featureMap,
        map<string, string>& dataField, map<int, double>& feature2Value)
{
    // first feature value is label value
    for (map<string, string>::iterator dataIter = dataField.begin();
            dataIter != dataField.end(); ++dataIter)
    {
        map<string, DataConf>::iterator iter = featureMap.find(dataIter->first);
        if (iter != featureMap.end())
        {
            DataConf dc = iter->second;
            int xgboostFeatIndex = dc.xgboostIndex;
            string oper = dc.operation;
            std::transform(oper.begin(), oper.end(), oper.begin(), ::tolower);

            if (oper == "pickcat")
            {
                string oriArgs = dc.args;
                vector<string> argsVec;
                // process given args list
                if (dc.args.find("[") != string::npos)
                {
                    dc.args = oriArgs.substr(oriArgs.find("[") + 1,
                            oriArgs.find("]") - oriArgs.find("[") - 1);
                    argsVec = StringTool::SplitString(dc.args, ",");

                }
                // process given args file name
                else
                {
                    ifstream fcatPath(oriArgs.c_str());

                    if (!fcatPath.is_open())
                    {
                        cerr << "can't open file: " << oriArgs << endl;
                        return false;
                    }
                    string featureCat = "";

                    while (getline(fcatPath, featureCat))
                    {
                        argsVec.push_back(featureCat);
                    }

                    fcatPath.close();
                }
                bool findFeature = false;
                for (int argIndex = 0; argIndex < argsVec.size(); ++argIndex)
                {
                    if (dataIter->second == argsVec[argIndex])
                    {
                        feature2Value[xgboostFeatIndex] = argIndex;
                        findFeature = true;
                        cout << "catch: " << argIndex << endl;
                    }
                }
                if (!findFeature)
                {
                    feature2Value[xgboostFeatIndex] = argsVec.size();
                }
            }
            // if feature is not category type, use it's original value.
            else
            {
                feature2Value[xgboostFeatIndex] = atof(
                        dataIter->second.c_str());
            }
        }
    }
    return true;
}

/*bool CDataConfParser::getInstances(map<string, DataConf>& featureMap,
 string dataPath, vector<map<int, double> >& feature2ValueList)
 {
 ifstream fDataSample(dataPath.c_str());
 if (!fDataSample.is_open())
 {
 cerr << "can't open file: " << dataPath << endl;
 return false;
 }

 string line = "";

 while (getline(fDataSample, line))
 {
 if (line.empty())
 {
 continue;
 }

 vector<string> dataVals = StringTool::SplitString(line, "\t");
 map<int, double> feature2Value;

 // first feature value is label value
 for (int valIndex = 1; valIndex < dataVals.size(); valIndex++)
 {
 map<int, DataConf>::iterator iter = featureMap.find(
 valIndex);
 if (iter != featureMap.end())
 {
 DataConf dc = iter->second;
 int xgboostFeatIndex = dc.xgboostIndex;
 string oper = dc.operation;
 std::transform(oper.begin(), oper.end(), oper.begin(),
 ::tolower);

 if (oper == "pickcat")
 {
 string oriArgs = dc.args;
 vector<string> argsVec;
 // process given args list
 if (dc.args.find("[") != string::npos)
 {
 dc.args = oriArgs.substr(oriArgs.find("[") + 1,
 oriArgs.find("]") - oriArgs.find("[") - 1);
 argsVec = StringTool::SplitString(dc.args, ",");

 }
 // process given args file name
 else
 {
 ifstream fcatPath(oriArgs.c_str());

 if (!fcatPath.is_open())
 {
 cerr << "can't open file: " << dataPath << endl;
 return false;
 }
 string featureCat = "";

 while (getline(fcatPath, featureCat))
 {
 argsVec.push_back(featureCat);
 }

 fcatPath.close();
 }
 bool findFeature = false;
 for (int argIndex = 0; argIndex < argsVec.size();
 ++argIndex)
 {
 if (dataVals[valIndex] == argsVec[argIndex])
 {
 feature2Value[xgboostFeatIndex] = argIndex;
 findFeature = true;
 cout << "catch: " << argIndex << endl;
 }
 }
 if (!findFeature)
 {
 feature2Value[xgboostFeatIndex] = argsVec.size();
 }
 }
 // if feature is not category type, use it's original value.
 else
 {
 feature2Value[xgboostFeatIndex] = stod(dataVals[valIndex]);
 }
 }
 }
 feature2ValueList.push_back(feature2Value);
 fDataSample.close();
 }

 return true;
 }
 */
