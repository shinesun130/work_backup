#include <iostream>
#include <fstream>
#include <string>
#include <set>
#include <map>
#include <math.h>
using namespace std;

typedef struct FeatureNode{
	string type;
	string args;
	string oper;
	int index;
	map<string,int> mindex;
};


class FeatureManager{
	//���캯��&��������
public:
	FeatureManager();
	~FeatureManager();
	//�����ӿ�
public:
	bool Init(const char* file);
	bool GenInstance(map<string,string>& fmap,set<pair<int,double> >& instance);
	string DoConvert(string param,string oper,string args);

	//��Ա����
private:
	map<string,FeatureNode> feature_map;
};
