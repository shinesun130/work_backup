#! /bin/sh
rm *~
