/*
 * parseDataConf.h
 *
 *  Created on: 2016年12月23日
 *      Author: huinan1
 */
#include <string>
#include <map>
#include <map>
#include "StringTool.h"

using namespace std;

struct DataConf
{
    int index;
    int xgboostIndex;
    string name;
    string category;
    string operation;
    string args;
    int maxHint;
};

class CDataConfParser
{
public:
    static bool parseDataConf(map<string, DataConf >& featureMap,
            string dataConfPath);
//    static bool getInstances(map<string, DataConf >& featureMap,
//            string dataPath, vector<map<int, double> >& feature2ValueList);
    static bool getInstance(map<string, DataConf>& featureMap,
            map<string, string>& tField, map<int, double>& feature2Value);
};
