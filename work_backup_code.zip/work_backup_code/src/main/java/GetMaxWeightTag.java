package com.weibo.mytest;

import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;


public class GetMaxWeightTag extends UDF{
    public String evaluate(String oriValue) {
        if (StringUtils.isNullOrEmpty(oriValue) || oriValue.equals("\\N")) {
            return "NULL";
        }
        String tag = "NULL";
        float max_weight = 0;
        for (String tag_weight : oriValue.split("\\|")) {
            String[] tag_weight_pair = tag_weight.split("@");
            if (tag_weight_pair.length == 2 && max_weight < Float.parseFloat(tag_weight_pair[1])) {
                max_weight = Float.parseFloat(tag_weight_pair[1]);
                tag = tag_weight_pair[0];
            }
        }
        return tag;
    }
}
