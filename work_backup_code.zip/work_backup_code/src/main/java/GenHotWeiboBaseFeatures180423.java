package com.weibo.mytest;

import com.google.gson.*;
import com.google.gson.reflect.TypeToken;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;

import java.io.*;
import java.util.*;

import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.FSDataInputStream;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.Path;

import java.io.BufferedReader;
import java.io.InputStreamReader;

/**
 * Created by huinan1 on 18/10/18.
 */
// TODO define input and output types, e.g. "string,string->string,bigint".
//@Resolve({"string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string->string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string"})
//@Resolve({"string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string,string->double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,double,bigint"})

public class GenHotWeiboBaseFeatures180423 extends GenericUDTF {


    static Map<String, Integer> bornConfigMap = new HashMap<String, Integer>() {{
        put("70s", 0);
        put("80s", 1);
        put("90s", 2);
        put("00s", 3);
    }};
    static Map<String, Integer> genderConfigMap = new HashMap<String, Integer>() {{
        put("m", 0);
        put("f", 1);
    }};
    static Map<String, Integer> netWorkTypeConfigMap = new HashMap<String, Integer>() {{
        put("wifi", 0);
        put("4g", 1);
    }};
    static Map<String, Integer> provinceConfigMap = new HashMap<String, Integer>(){{
        put("1042015:province_11", 0);
        put("1042015:province_12", 1);
        put("1042015:province_13", 2);
        put("1042015:province_14", 3);
        put("1042015:province_15", 4);
        put("1042015:province_21", 5);
        put("1042015:province_22", 6);
        put("1042015:province_23", 7);
        put("1042015:province_31", 8);
        put("1042015:province_32", 9);
        put("1042015:province_33", 10);
        put("1042015:province_34", 11);
        put("1042015:province_35", 12);
        put("1042015:province_36", 13);
        put("1042015:province_37", 14);
        put("1042015:province_41", 15);
        put("1042015:province_42", 16);
        put("1042015:province_43", 17);
        put("1042015:province_44", 18);
        put("1042015:province_45", 19);
        put("1042015:province_46", 20);
        put("1042015:province_50", 21);
        put("1042015:province_51", 22);
        put("1042015:province_52", 23);
        put("1042015:province_53", 24);
        put("1042015:province_54", 25);
        put("1042015:province_61", 26);
        put("1042015:province_62", 27);
        put("1042015:province_63", 28);
        put("1042015:province_64", 29);
        put("1042015:province_65", 30);
        put("1042015:province_71", 31);
        put("1042015:province_81", 32);
        put("1042015:province_82", 33);
        put("1042015:province_400", 34);
    }};
//    static String[] firstLevelTagsConfigArray;
//    static String[] secondLevelTagsConfigArray;
//    static String[] thirdLevelTagsConfigArray;
//    static String[] topicConfigArray;
//    static String[] keyWordsConfigArray;


    static Map<String, Integer> firstLevelTagsConfigMap;
    //    static Map<String, Integer> secondLevelTagsConfigMap;
    static Map<String, Integer> thirdLevelTagsConfigMap;
    static Map<String, Integer> topicConfigMap;
    static Map<String, Integer> keyWordsConfigMap;
    static int firstLevelTagsNum;
    static int secondLevelTagsNum;
    static int thirdLevelTagsNum;

    static Map<String, String> user_interest_cold_start;
    final private float defaultMidInterRate = 0.123f;
    private static List<String> interActionCodes = new ArrayList<String>() {{
        add("3");
        add("381");
        add("658");
        add("659");
        add("4");
        add("336");
        add("932");
        add("933");
        add("6");
    }};
    static List<Integer> calSecondLevelMatch = new ArrayList<Integer>() {{
        add(7);
        add(13);
        add(16);
        add(28);
    }};
    static List<Integer> calThirdLevelMatch = new ArrayList<Integer>() {{
        add(4);
        add(7);
        add(12);
        add(16);
        add(17);
        add(18);
        add(19);
        add(23);
        add(24);
        add(28);
    }};
    static Set<String> HIGH_CLK_CATES  = new HashSet<String>(){{
        add("1042015:tagCategory_020");
//        add("1042015:tagCategory_012");
//        add("1042015:tagCategory_029");
        add("1042015:tagCategory_010");
    }};
    static Set<String> LOW_CLK_CATES  = new HashSet<String>(){{
        add("1042015:tagCategory_031");
        add("1042015:tagCategory_005");
        add("1042015:tagCategory_019");
        add("1042015:tagCategory_10001");
        add("1042015:tagCategory_001");
        add("1042015:tagCategory_043");
        add("1042015:tagCategory_055");
        add("1042015:tagCategory_046");
        add("1042015:tagCategory_004");
        add("1042015:tagCategory_061");
        add("1042015:tagCategory_025");
        add("1042015:tagCategory_030");
        add("1042015:tagCategory_015");
        add("1042015:tagCategory_035");
        add("1042015:tagCategory_044");
        add("1042015:tagCategory_017");
        add("1042015:tagCategory_048");
    }};
    final static int[] tagMatchConfigArray = new int[]{50, 60, 70, 75, 80, 85, 90, 95};//9
    final static int[] docTagsConfigArray = new int[]{10, 20, 30, 40, 50, 60, 70, 80, 90};//10
    final static int[] interCountConfigArray = new int[]{20, 40, 60, 80, 100, 200, 400, 600, 800, 1000, 2000, 3000, 4000, 5000, 6000, 7000, 11000};//18
    final static int[] effectWeightConfigArray = new int[]{3, 5, 7, 9, 11, 13, 16, 20, 24};//10
    //    final static int[] clickRateConfigArray = new int[]{4, 7, 10, 12, 14, 16, 18, 20, 23, 26, 30, 35, 40};
    final static int[] clickRateConfigArray = new int[]{10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 110, 120, 130, 140, 150, 160, 170, 180, 190};//20
    final static int[] clickNumRateConfigArray = new int[]{50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 600, 650, 700, 750, 800, 850, 900, 950};//20
    final static int[] interRateConfigArray = new int[]{3, 6, 9, 11, 13, 15, 17, 19, 21, 24, 27, 30};//13
    //    final static int[] interRateConfigArray = new int[]{3, 6, 9, 11, 13, 15, 17, 19, 21, 24, 27, 30, 35, 40};
    final static int[] writerUserAttractionAllCate1ConfigArray = new int[]{50, 52, 54, 56, 58, 60};
    final static int[] readerWriterIntimacyConfigArray = new int[]{10, 20, 30, 40, 50, 60, 70};//8
    //    static ObjectMapper objectMapper = new ObjectMapper();
    final static JsonParser jsonParser = new JsonParser();


    public static Map<String, Object> jsonToMap(String data) {
        GsonBuilder gb = new GsonBuilder();
        Gson g = gb.create();
        Map<String, Object> map = g.fromJson(data, new TypeToken<Map<String, Object>>() {
        }.getType());
        return map;
    }

    private static List<Map> jsonToList(String data) {
        GsonBuilder gb = new GsonBuilder();
        Gson g = gb.create();
        List<Map> list = g.fromJson(data, new TypeToken<List<Map>>() {
        }.getType());
        return list;
    }

    public static JsonObject getJsonObject(String json) {
//        JsonParser jsonParser = new JsonParser();
        return jsonParser.parse(json).getAsJsonObject();
    }

    public static Map<String, JsonObject> getJsonMap(JsonObject jo) {
        Map<String, JsonObject> res = new HashMap();
        Set<Map.Entry<String, JsonElement>> iterator = jo.entrySet();
        for (Map.Entry<String, JsonElement> s : iterator) {
            res.put(s.getKey(), s.getValue().getAsJsonObject());
        }
        return res;
    }

    private int getContentForm(int picNum, int article, int videoNum, int obj) {
        /*int ind = 12;
        int picMaxNum = Math.min(picNum, 9);
        if (picMaxNum > 0) {
            ind = picMaxNum - 1;
        }else if(videoNum > 0){
            ind = 9;
        }else if(article > 0){
            ind = 10;
        }else if(obj > 0){
            ind = 11;
        }*/
        int ind = 10;
        int picMaxNum = Math.min(picNum, 9);
        if (picMaxNum > 0) {
            ind = picMaxNum - 1;
        } else if (videoNum > 0) {
            ind = 9;
        }
        return ind;
    }

    private static String getValidValue(Map<String, Tag> tagMap, float validValue) {
        String resTag = "invalidValue";
        float resValue = 0.0f;
        if (tagMap.size() > 0) {
            for (Map.Entry<String, Tag> m : tagMap.entrySet()) {
                float curValue = m.getValue().weight;
                if (curValue > resValue && curValue >= validValue) {
                    resTag = m.getKey();
                    resValue = curValue;
                }
            }
        }
        return resTag;
    }

    private String getMatchValidValue(Map<String, Float> userTagMap, Map<String, Tag> docTagMap) {
        String resTag = "invalidValue";
        if (userTagMap.size() < 1 || docTagMap.size() < 1) {
            return resTag;
        }
        Set<String> mKeys = userTagMap.keySet();
        Set<String> nKeys = docTagMap.keySet();
        mKeys.retainAll(nKeys);
        if (mKeys.size() >= 1) {
            float tmp = 0f;
            for (String s : mKeys) {
//                float matchValue = userTagMap.get(s) * docTagMap.get(s);
                float matchValue = userTagMap.get(s) * 1.0f;
                if (matchValue > tmp) {
                    resTag = s;
                    tmp = matchValue;
                }
            }
        }
        return resTag;
    }
    private String getMatchValidValueNew(Map<String, Float> userTagMap, Map<String, Tag> docTagMap, String category) {
        String resTag = "invalidValue";
        if (userTagMap.size() < 1 || docTagMap.size() < 1) {
            return resTag;
        }
        Set<String> mKeys = userTagMap.keySet();
        Set<String> nKeys = docTagMap.keySet();
        mKeys.retainAll(nKeys);
        boolean is_category = isCategory(category);
        if (mKeys.size() >= 1) {
            float tmp = 0f;
            for (String s : mKeys) {
                //                float matchValue = userTagMap.get(s) * docTagMap.get(s);
                float matchValue = userTagMap.get(s) * 1.0f;
                switch (docTagMap.get(s).type) {
                    case 1:

                        if (!is_category || category.equals(docTagMap.get(s).category) ) {
                            if (matchValue > tmp) {
                                resTag = s;
                                tmp = matchValue;
                            }
                        }
                        break;
                    case 2:
                        if (!is_category || category.equals(docTagMap.get(s).category) ) {
                            if (matchValue > tmp) {
                                resTag = s;
                                tmp = matchValue;
                            }
                        }
                        break;
                    case 3:
                        if (category.equals(docTagMap.get(s).category) || isPerson(s)) {
                            matchValue = matchValue * 1;
                        } else {
                            matchValue = matchValue * 0.5f;
                        }
                        if (matchValue > tmp) {
                            resTag = s;
                            tmp = matchValue;
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        return resTag;
    }

    private static int getDiscreteNumericalFeatureIndex(int fea, int[] feaArray, int len) {
        int ind = 0;
        //(-inf, v), [v, vv)
        while (ind <= (len - 2) && fea >= feaArray[ind])
            ind++;
        return ind;
    }

    public static int[] discreteNumericalFeature(int fea, int[] feaArray) {
        int count = feaArray.length + 1;
        /*int[] resArray = new int[count];
        int ind = getDiscreteNumericalFeatureIndex(fea, feaArray, count);
        resArray[ind] = 1;*/
        int[] resArray = new int[2];
        int ind = getDiscreteNumericalFeatureIndex(fea, feaArray, count);
        resArray[0] = count;
        resArray[1] = ind;
        return resArray;
    }

    private static int getDiscreteCategoricalFeatureIndex(String fea, String[] feaArray, int len) {
        int ind = 0;
        while (ind <= (len - 2) && !feaArray[ind].equals(fea))
            //while (ind <= (len - 2) && fea != feaArray[ind])
            ind++;
        return ind;
    }

    private static int[] discreteCategoricalFeature(String fea, String[] feaArray) {
        int count = feaArray.length + 1;
        int[] resArray = new int[count];
        int ind = getDiscreteCategoricalFeatureIndex(fea, feaArray, count);
        resArray[ind] = 1;
        return resArray;
    }

    private int[] discreteCategoricalFeatureNew(String fea, Map<String, Integer> feaMap, int feaMapSize) {
        int[] resArray = new int[2];
        resArray[0] = feaMapSize + 1;
        if (feaMap.containsKey(fea)) {
            resArray[1] = feaMap.get(fea);
        } else {
            resArray[1] = feaMapSize;
        }
        return resArray;
    }

    private int getPosValueIndex(float[] v) {
        int ind = 0;
        for (float f : v) {
            if (f > 0) {
                break;
            }
            ind += 1;
        }
        return ind;
    }

    private int getPosValueIntIndex(int[] v) {
        int ind = 0;
        for (int f : v) {
            if (f > 0) {
                break;
            }
            ind += 1;
        }
        return ind;
    }

    private String genLibsvmFeatures(List features) {
        int allLen = features.size();
        String[] disFeatures = new String[allLen];
        int indAll = 0;
        for (int i = 0; i < allLen; i++) {
            /*if (features.get(i) instanceof int[]) {
                long s = System.currentTimeMillis();
                int feaLen = ((int[]) features.get(i)).length;
//                int ind = intArray2String((int[]) features.get(i)).indexOf('1');
                int ind = getPosValueIntIndex((int[]) features.get(i));
                disFeatures[i] = String.join(":", Integer.toString(indAll + ind + 1), "1");
                indAll += feaLen;
                long e = System.currentTimeMillis();
                System.out.println("gen int array libsvm:"+ String.valueOf(e-s));
            }else */
            if (features.get(i) instanceof float[]) {
                float[] tmp = (float[]) features.get(i);
//                int feaLen = tmp.length;
                int feaLen = (int) tmp[0];
//                int ind = getPosValueIndex(tmp);
                int ind = (int) tmp[1];
//                disFeatures[i] = String.join(":", Integer.toString(indAll + ind + 1), String.valueOf(tmp[ind]));
                disFeatures[i] = String.join(":", Integer.toString(indAll + ind + 1), String.valueOf(tmp[2]));
                indAll += feaLen;
            } else {
                disFeatures[i] = String.join(":", Integer.toString(indAll + 1), String.valueOf(features.get(i)));
                indAll += 1;
            }
        }
        return String.join(" ", disFeatures);

    }

    private static String genCommonFeatures(List features) {
        int allLen = features.size();
        String[] disFeatures = new String[allLen];
        for (int i = 0; i < allLen; i++) {
            if (features.get(i) instanceof int[]) {
                disFeatures[i] = String.join("\t", (String[]) features.get(i));
            } else {
                disFeatures[i] = features.get(i).toString();
            }
        }
        return String.join("\t", disFeatures);
    }

    private Map<String, String> loadDictConfigFile(String fileName) throws HiveException {
        Map<String, String> configMap = new HashMap<String, String>();
        try {
            InputStream in = new FileInputStream(new File(fileName));
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = br.readLine()) != null) {
                String[] lineSplitted = line.split("\t", 2);
                String key = lineSplitted[0];
                String value = lineSplitted[1];
                configMap.put(key, value);
            }
            return configMap;
        } catch (IOException e) {
            throw new HiveException(e);
        }
    }

    private Map<String, Integer> loadDictConfigFileWithIndex(String fileName) throws HiveException {
        Map<String, Integer> configMap = new HashMap<String, Integer>();
        try {
            InputStream in = new FileInputStream(new File(fileName));
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            int ind = 0;
            while ((line = br.readLine()) != null) {
                configMap.put(line, ind);
                ind++;
            }
            return configMap;
        } catch (IOException e) {
            throw new HiveException(e);
        }
    }

    public List<String> loadListConfigFile(String fileName) throws HiveException {
        List<String> configList = new ArrayList<String>();
//        this.ctx = ctx;
        try {
            InputStream in = new FileInputStream(new File(fileName));
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            while ((line = br.readLine()) != null) {
                configList.add(line);
            }
            return configList;
        } catch (IOException e) {
            throw new HiveException(e);
        }
    }

    private Float genGlobalInterClickRate(float expo, float click) {
        float rate = (click + 20) / (expo + 15700);
        rate = rate * 50;
        rate = 2 * rate - 0.03f;
        if (rate > 0) {
            return rate;
        } else {
            return new Float(0);
        }
    }

    private Float getMergeAct(float actNum, float interActNum) {
        return actNum + interActNum * 5;
    }

    private Float genClickRate(float expo, float click, float defaultRate) {
        float rate = defaultRate;
        if (expo >= 1000 && click < expo) {
            rate = click / expo;
            rate = Math.min(0.4f, rate);
        }
        return rate;

    }

    private Float genClickRateReal(float expo, float click, float defaultRate) {
        // default:
        float rate = defaultRate;
        if (expo >= 500 && click < expo) {
            rate = click / expo;
//            rate = Math.min(0.4f, rate);
        }
        return rate;

    }

    private Float genClickNumRate(float expo, float click, float defaultRate) {
        float rate = defaultRate;
        if (expo >= 1000 && click < expo) {
            rate = click / expo;
            rate = Math.min(1f, rate);
        }
        return rate;

    }

    private Float genClickNumRateReal(float expo, float click, float defaultRate) {
        float rate = defaultRate;
        if (expo >= 500) {
            rate = click / expo;
            rate = Math.min(1f, rate);
        }
        return rate;

    }

    private Float genMidDuration(float durationAll, float durationUv, float defaultDuration) {
        float rate = defaultDuration;
        if (durationUv >= 500) {
            rate = durationAll / durationUv;
        }
        return rate;

    }

    private Float genFeedClickRate(float expo, float click, float defaultRate) {
        float rate = defaultRate;
        if (expo >= 1000 ) {
            rate = click / expo;
            rate = Math.min(1f, rate);
        }
        return rate;

    }

    private Float genInterClickRate(float expo, float click, float defaultRate) {
        //default: 0.097
        float rate = defaultRate;
        if (click < expo) {
//            rate = click / expo;
            rate = (click + 2f) / (expo + 3140.0f);
            rate *= 100;
            rate = Math.min(rate, 0.8f);
        }
        return rate;
    }

    private Float genInterClickRateReal(float expo, float click, float defaultRate) {
        //default: 0.097
        float rate = defaultRate;
        if (click < expo) {
            rate = (click + 2f) / (expo + 1626.1f);
            rate *= 100;
            rate = Math.min(rate, 1.0f);
        }
        return rate;
    }

    public int isInterAction(String ac) {
        if (ac == null) {
            return 0;
        }
        String[] acArray = ac.trim().split(",");
        List<String> acList = new ArrayList<String>();
        int aLen = acArray.length;
        for (int i = 0; i < aLen; i++) {
            acList.add(acArray[i]);
        }
//        List acList = Arrays.asList(acArray);
        acList.retainAll(interActionCodes);
        if (acList.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    private static int getWriterVerifiedType(String verifiedType, String userProperty) {
        int ind;
        if (userProperty.equals("1") || userProperty.equals("2")) {
            ind = 0;
        } else if (verifiedType.equals("0")) {
            ind = 1;
        } else if (Integer.parseInt(verifiedType) >= 1 && Integer.parseInt(verifiedType) <= 7) {
            ind = 2;
        } else {
            ind = 3;
        }
        return ind;
    }

    private static boolean isCategory(String cate) {
        if (cate.contains("1042015:tagCategory_")) {
            return true;
        }
        return false;
    }

    private static boolean isPerson(String cate) {
        if (cate.contains("Person_")) {
            return true;
        }
        return false;
    }

    public static float calInterMatchValue(String cate, Map<String, Float> userTags, Map<String, Tag> docTags) {
        boolean is_category = isCategory(cate);
        String this_category = cate;
        if (cate.length() > 11 && cate.substring(0, 11).equals("vertical_t_")) {
            this_category = cate.substring(11);
        }
        float inter_weight_res = 0;
        for (Map.Entry<String, Tag> d : docTags.entrySet()) {
            String tagName = d.getKey();
            if (tagName.length() > 11 && tagName.substring(0, 11).equals("vertical_t_")) {
                tagName = d.getKey().substring(11);
            }
            if (userTags.containsKey(tagName)) {
                float tag_weight = 1.0f;
                float user_tag_weight = Math.max(0f, userTags.get(tagName));
                float inter_weight_tmp = 0f;
                switch (d.getValue().type) {
                    case 1:
                        if (!is_category || tagName.equals(this_category)) {
                            inter_weight_tmp = tag_weight * user_tag_weight;
                            if (inter_weight_tmp > inter_weight_res) {
                                inter_weight_res = inter_weight_tmp;
                            }
                        }
                        break;
                    case 2:
                        if (!is_category || d.getValue().category.equals(this_category)) {
                            inter_weight_tmp = tag_weight * user_tag_weight;
                            if (inter_weight_tmp > inter_weight_res) {
                                inter_weight_res = inter_weight_tmp;
                            }
                        }
                        break;
                    case 3:
                        if (d.getValue().category.equals(cate) || isPerson(tagName)) {
                            inter_weight_tmp = tag_weight * user_tag_weight;
                        } else {
                            inter_weight_tmp = tag_weight * user_tag_weight * 0.5f;
                        }
                        if (inter_weight_tmp > inter_weight_res) {
                            inter_weight_res = inter_weight_tmp;
                        }
                        break;
                    default:
                        break;
                }
            }
        }
        return inter_weight_res;
    }

    /*
         * INPUT: intimacyRaw: "2004645241@0.6581|1731230547@0.4308|3847782259@0.4308|2963524621@0.6088"
         *        uid: "1731230547"
         * OUTPUT: 0.4308
         */
    public static float ParseIntimacy(String intimacyRaw, String uid) {
        float score = 0.0f;
        try {

//            int intimacyStart = intimacyRaw.indexOf(uid + "@");
//            if (-1 != intimacyStart) {
//                int intimacyAt = intimacyRaw.indexOf("@", intimacyStart);
//                if (intimacyAt > intimacyStart) {
//                    int intimacyEnd = intimacyRaw.indexOf("|", intimacyAt);
//                    intimacyEnd = (-1 != intimacyEnd) ? intimacyEnd : intimacyRaw.length();
//                    if (intimacyEnd > intimacyAt + 1) {
//                        score = Float.valueOf(intimacyRaw.substring(intimacyAt + 1, intimacyEnd));
//                    }
//                }
//            }
            String[] uidUnit = intimacyRaw.split("\\|");
            for(String s:uidUnit){
                if(s.contains(uid)){
                    score = Float.parseFloat(s.substring(s.indexOf("@")+1, s.lastIndexOf("@")));
                }
            }
        } catch (Exception e) {
//            System.out.printf("uid: %s, raw: %s", uid, intimacyRaw);
//            e.printStackTrace();
        }
        return score;
    }

    public static String parseKeyWords(String keyWords, float validThres) {
        String resStr = "invalidValue";
        float weight = 0.0f;
        try {
            String[] strWeights = keyWords.split("\\|");
            int len = strWeights.length;
            for (int i = 0; i < len; i++) {
                String[] strWeight = strWeights[i].split("@");
                float weightTmp = Float.parseFloat(strWeight[1]);
                if (weightTmp >= validThres && weightTmp > weight) {
                    weight = weightTmp;
                    resStr = strWeight[0];
                }
            }
        } catch (Exception e) {
//            e.printStackTrace();
        }
        return resStr;
    }

    public static String getProvinceId(String location){
        String res = "";
        if(location.contains("city_")){
            res = "1042015:province_".concat(location.substring(location.indexOf("_")+3, location.indexOf("_")+5));
        }else if(location.contains("province_")){
            res = location;
        }
        return res;
    }

    @Override
    public StructObjectInspector initialize(StructObjectInspector argOIs)  throws UDFArgumentException {
        try {
//            firstLevelTagsConfigArray = loadListConfigFile("first_tag_feature_config").toArray(new String[0]).clone();
//            secondLevelTagsConfigArray = loadListConfigFile("second_tag_feature_config").toArray(new String[0]).clone();
//            thirdLevelTagsConfigArray = loadListConfigFile("third_tag_feature_config").toArray(new String[0]).clone();
//            topicConfigArray = loadListConfigFile("second_tag_feature_config").toArray(new String[0]).clone();
//            keyWordsConfigArray = loadListConfigFile("mid_key_word_config").toArray(new String[0]).clone();

            firstLevelTagsConfigMap = loadDictConfigFileWithIndex("first_tag_feature_config");
//            secondLevelTagsConfigMap = loadDictConfigFileWithIndex("second_tag_feature_config");
//            thirdLevelTagsConfigMap = loadDictConfigFileWithIndex("third_tag_feature_config");
//            topicConfigMap = loadDictConfigFileWithIndex("second_tag_feature_config");
            firstLevelTagsNum = firstLevelTagsConfigMap.size();
//            thirdLevelTagsNum = thirdLevelTagsConfigMap.size();

//            mid_click_num_dict = loadDictConfigFile("mid_click_num_info");
            user_interest_cold_start = loadDictConfigFile("user_interest_cold_start_file");

            ArrayList<String> fieldNames = new ArrayList<String>();
            ArrayList<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>();
            String[] features_out={
                    "group_expose_num",
                    "group_act_num",
                    "group_inter_act_num",
                    "group_ret_num",
                    "group_cmt_num",
                    "group_like_num",
                    "group_expose_num_recent",
                    "group_act_num_recent",
                    "group_inter_act_num_recent",
                    "group_ret_num_recent",
                    "group_cmt_num_recent",
                    "group_like_num_recent",
                    "mid_click_rate",
                    "mid_inter_act_rate",
                    "mid_click_num_rate",
                    "mid_group_click_rate",
                    "mid_group_inter_act_rate",
                    "mid_group_click_num_rate",
                    "second_level_valid_tag",
                    "third_level_valid_tag",
                    "author_verified_type",
                    "author_user_property",
                    "author_followers_num",
                    "second_level_match_tag",
                    "third_level_match_tag",
                    "user_second_match_tag_value",
                    "mblog_second_match_tag_value",
                    "user_third_match_tag_value",
                    "mblog_third_match_tag_value",
                    "user_author_intimacy",
                    "content_form",
                    "author_property_and_verified_type",
                    "mblog_gif_num",
                    "mblog_long_pic_num",
                    "mblog_level",
                    "author_user_class",
                    "key_word_valid_tag",
                    "mblog_topic_num",
                    "text_len",
                    "is_match_long_interest",
                    "is_match_short_interest",
                    "first_level_inte_group_ctr",
                    "second_level_inte_group_ctr",
                    "third_level_inte_group_ctr",
                    "first_level_match_tag",
                    "is_match_location",
                    "province_group_ctr",
                    "province_id",
                    "mid_duration_all",
                    "mid_duration_uv",
                    "mid_duration_avg",
                    "rank_num",
                    "mid_feed_expo",
                    "mid_feed_clk",
                    "mid_feed_clk_rate"
            };
            for(int i = 0; i < features_out.length; i++){
                fieldNames.add(features_out[i]);
                fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
            }
            return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);

        } catch (Exception e) {
            throw new UDFArgumentException(e);
        }
    }

    @Override
    public void process(Object[] args) throws HiveException {
        // TODO

//        int isClick = Integer.parseInt(args[0].toString());
//        String actions = (String) args[1];
//        String isAutoPlay = (String) args[2];
        String mid = args[0].toString();
//        String durations = (String) args[4];
//        String uid = (String) args[5];
        String born = (String) args[1];
        String gender = (String) args[2];
        String areaId = (String) args[3];
        if(areaId == null){
            return;
        }
//        String userTags = (String) args[9];
        String docTagsJson = String.valueOf(args[4]);
        String authorId = (String) args[5];
//        long expoTime = Long.parseLong((String)args[12]);
//        String netWorkType = (String) args[13];
//        String recommendSource = (String) args[14];
//        String recommendBaseLevel = (String) args[15];
        String category = (String) args[6];
//        float firstLevelMatch = Float.parseFloat(args[17].toString());
//        float secondLevelMatch = Float.parseFloat(args[18].toString());
//        float thirdLevelMatch = Float.parseFloat(args[19].toString());
//        float effectWeight = Float.parseFloat(args[20].toString());
        if (args[7] == null ) {
            return;
        }
        int picWeight = (int) Float.parseFloat((String) args[7]);
        int articleWeight = (int) Float.parseFloat((String) args[8]);
        int videoWeight = (int) Float.parseFloat((String) args[9]);
        int objWeight = (int) Float.parseFloat((String) args[10]);
//        String userWeight = (String) args[25];
//        float retNum = Float.parseFloat(args[26].toString());
//        float cmtNum = Float.parseFloat(args[27].toString());
//        float likeNum = Float.parseFloat(args[28].toString());
//        float retRecentNum = Float.parseFloat(args[29].toString());
//        float cmtRecentNum = Float.parseFloat(args[30].toString());
//        float likeRecentNum = Float.parseFloat(args[31].toString());
//        float totalReadNum = Float.parseFloat(args[32].toString());
        float exposureNum = Float.parseFloat(args[11].toString());
        float actNum = Float.parseFloat(args[12].toString());
        float interActNum = Float.parseFloat(args[13].toString());
//        float exposureRecentNum = Float.parseFloat(args[36].toString());
//        float actRecentNum = Float.parseFloat(args[37].toString());
//        float interActRecentNum = Float.parseFloat(args[38].toString());
//        float hotRetNum = Float.parseFloat(args[39].toString());
//        float hotCmtNum = Float.parseFloat(args[40].toString());
//        float hotLikeNum = Float.parseFloat(args[41].toString());
//        float hotRetRecentNum = Float.parseFloat(args[42].toString());
//        float hotCmtRecentNum = Float.parseFloat(args[43].toString());
//        float hotLikeRecentNum = Float.parseFloat(args[44].toString());
//        float articleReadNum = Float.parseFloat(args[45].toString());
//        float miaopaiViewNum = Float.parseFloat(args[46].toString());
        String allGroupMsg = (String) args[14];
        String hourGroupMsg = (String) args[15];
//        String extend = args[49].toString();
        String userLongInterestsJson = (String) args[16];//user long interest tags
        String userShortInterestsJson = (String) args[17];//user short interest tags
        String userAuthorIntimacy = (String) args[18];
//        String userTagsClickRate = (String) args[53];
        String authorBaseAttributes = (String) args[19];
//        String authorUserAttraction = (String)args[55];
        String midBaseAttributes = (String) args[20];
//        String midTopicTags = (String) args[57];
//        String midKeyWordTags = (String) args[58];
//        String uidExtendJson = (String) args[59];
//        String authorExtendJson = (String) args[60];
//        String midExtendJson = (String) args[61];
        String extend2 = (String)args[21];


        String mblogGifNum;
        String mblogLongPicNum;
        String mblogLevel;
        String mblogTopicNum;
        try {
            JsonArray contentFormArray = jsonParser.parse(midBaseAttributes).getAsJsonArray();
            mblogLevel = contentFormArray.get(1).getAsJsonObject().get("mblog_level").getAsString();
            mblogTopicNum = contentFormArray.get(5).getAsJsonObject().get("mblog_topic_num").getAsString();
            mblogGifNum = contentFormArray.get(13).getAsJsonObject().get("mblog_gif_num").getAsString();
            mblogLongPicNum = contentFormArray.get(15).getAsJsonObject().get("mblog_long_pic_num").getAsString();
        } catch (Exception e) {
//            System.out.println("midBaseAttributes:"+midBaseAttributes+", err:"+String.valueOf(e));
            return;
        }
        String groupExpoNum;
        String groupActionNum;
        String groupInterActionNum;
        String groupRetNum;
        String groupCmtNum;
        String groupLikeNum;
        String groupExpoRecentNum;
        String groupActionRecentNum;
        String groupInterActionRecentNum;
        String groupRetRecentNum;
        String groupCmtRecentNum;
        String groupLikeRecentNum;

        try {
            allGroupMsg = org.apache.commons.lang.StringUtils.strip(allGroupMsg, "[]");
            String[] allGroupMsgSplitted = allGroupMsg.split(",");
            hourGroupMsg = org.apache.commons.lang.StringUtils.strip(hourGroupMsg, "[]");
            String[] hourGroupMsgSplitted = hourGroupMsg.split(",");
            groupExpoNum = org.apache.commons.lang.StringUtils.strip(allGroupMsgSplitted[0], "' ");
            groupActionNum = org.apache.commons.lang.StringUtils.strip(allGroupMsgSplitted[1], "' ");
            groupInterActionNum = org.apache.commons.lang.StringUtils.strip(allGroupMsgSplitted[2], "' ");
            groupRetNum = org.apache.commons.lang.StringUtils.strip(allGroupMsgSplitted[3], "' ");
            groupCmtNum = org.apache.commons.lang.StringUtils.strip(allGroupMsgSplitted[4], "' ");
            groupLikeNum = org.apache.commons.lang.StringUtils.strip(allGroupMsgSplitted[5], "' ");
            groupExpoRecentNum = org.apache.commons.lang.StringUtils.strip(hourGroupMsgSplitted[0], "' ");
            groupActionRecentNum = org.apache.commons.lang.StringUtils.strip(hourGroupMsgSplitted[1], "' ");
            groupInterActionRecentNum = org.apache.commons.lang.StringUtils.strip(hourGroupMsgSplitted[2], "' ");
            groupRetRecentNum = org.apache.commons.lang.StringUtils.strip(hourGroupMsgSplitted[3], "' ");
            groupCmtRecentNum = org.apache.commons.lang.StringUtils.strip(hourGroupMsgSplitted[4], "' ");
            groupLikeRecentNum = org.apache.commons.lang.StringUtils.strip(hourGroupMsgSplitted[5], "' ");
        } catch (Exception e) {
//            System.out.println("allGroupMsg:"+ allGroupMsg+"and hourGroupMsg:"+hourGroupMsg+", err:"+String.valueOf(e));
            return;
        }

        String writerVerifiedType;
        String writerProperty;
        String writerFollowersNum;
        String writer_user_class;

        try {
            JsonArray writerBaseArray = jsonParser.parse(authorBaseAttributes).getAsJsonArray();
            writerVerifiedType = writerBaseArray.get(9).getAsJsonObject().get("verified_type").getAsString();
            writerProperty = writerBaseArray.get(2).getAsJsonObject().get("user_property").getAsString();
            writerFollowersNum = writerBaseArray.get(0).getAsJsonObject().get("followers_num").getAsString();
            writer_user_class = writerBaseArray.get(3).getAsJsonObject().get("user_class").getAsString();
        } catch (Exception e) {
            System.out.println("authorBaseAttributes"+authorBaseAttributes+", err:"+String.valueOf(e));
            return;
        }

        Map<String, Tag> firstDocTags = new HashMap<>();
        Map<String, Tag> secondDocTags = new HashMap<>();
        Map<String, Tag> thirdDocTags = new HashMap<>();
        Map<String, Tag> keyWordsTags = new HashMap<>();
        String text_len;
        String isMatchLocation = "0";
        try {
            JsonArray ja = jsonParser.parse(docTagsJson).getAsJsonArray();
            text_len = ja.get(2).getAsJsonObject().get("text_len").getAsString();
            List<Map> docTags = jsonToList(ja.get(6).getAsJsonObject().get("content_tag").getAsString());
            int tagsLen = docTags.size();
            for (int i = 0; i < tagsLen; i++) {
                double tagType = (Double) docTags.get(i).get("type");
                Tag t = new Tag();
                if (tagType == 3 && !docTags.get(i).get("tagid").toString().contains("tagTopic_") && !docTags.get(i).get("tagid").toString().contains("keyWord_")) {
                    t.weight = Float.parseFloat(docTags.get(i).get("rel_weight").toString());
                    t.type = (int) tagType;
                    t.category = docTags.get(i).get("category").toString();
                    thirdDocTags.put(docTags.get(i).get("tagid").toString(), t);
                } else if (tagType == 3 && docTags.get(i).get("tagid").toString().contains("keyWord_")) {
                    t.weight = Float.parseFloat(docTags.get(i).get("rel_weight").toString());
                    t.category = docTags.get(i).get("category").toString();
                    t.type = (int) tagType;
                    keyWordsTags.put((String) docTags.get(i).get("tagid"), t);
                } else if (tagType == 2) {
                    t.weight = Float.parseFloat(docTags.get(i).get("rel_weight").toString());
                    t.category = docTags.get(i).get("category").toString();
                    t.type = (int) tagType;
                    secondDocTags.put((String) docTags.get(i).get("tagid"), t);
                } else if (tagType == 1) {
                    t.weight = Float.parseFloat(docTags.get(i).get("rel_weight").toString());
                    t.category = docTags.get(i).get("category").toString();
                    t.type = (int) tagType;
                    firstDocTags.put((String) docTags.get(i).get("tagid"), t);
                }else if(tagType == 6){
                    if(Float.parseFloat(isMatchLocation) <= 1){
                        isMatchLocation = "1";
                        if(((String) docTags.get(i).get("tagid")).contains(areaId)){
                            isMatchLocation = "3";
                        }else if(getProvinceId((String) docTags.get(i).get("tagid")).contains(getProvinceId(areaId)) ){
                            isMatchLocation = "2";
                        }
                    }else if("2".equals(isMatchLocation)){
                        if(((String) docTags.get(i).get("tagid")).contains(areaId)){
                            isMatchLocation = "3";
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("address doctag:"+docTagsJson+", err:"+String.valueOf(e));
            return;
        }

        String thirdLevelValidTag = getValidValue(thirdDocTags, 0.6f);
        String secondLevelValidTag = getValidValue(secondDocTags, 0.6f);
        String firstLevelValidTag = getValidValue(firstDocTags, 0f);
        String invalidKeyWord = getValidValue(keyWordsTags, 0.5f);

        String born_alias;
        String gender_alias;
        if (born == null || born.equals("")) {
            born_alias = "unk_born";
        } else {
            born_alias = born;
        }
        if (gender == null || gender.equals("")) {
            gender_alias = "no_gender";
        } else {
            gender_alias = gender;
        }
        Map<String, Float> user_inter_cold_start_map = new HashMap<>();
        try {
            String[] user_inter_cold_start_str = user_interest_cold_start.get(gender_alias + " " + born_alias).split("\t");
            for (int i = 0; i < user_inter_cold_start_str.length; ++i) {
                String[] cate_weight = user_inter_cold_start_str[i].split("@");
                user_inter_cold_start_map.put(cate_weight[0], Float.parseFloat(cate_weight[1]));
            }
        } catch (Exception e) {
            System.out.println("user_interest_cold_start:"+gender_alias + " " + born_alias+", err:"+String.valueOf(e));
            return;
        }
//        long s0=System.currentTimeMillis();
//        address reader long info
        Map<String, Float> thirdUserInterTags = new HashMap();
        Map<String, Float> firstUserInterTags = new HashMap();
        Map<String, Float> secondUserInterTags = new HashMap();
        try {
            String[] firstSecondThirdLongTags = userLongInterestsJson.split(",", -1);
            String firstTags = firstSecondThirdLongTags[0];
            String secondTags = firstSecondThirdLongTags[1];
            String thirdTags = firstSecondThirdLongTags[2];
            if(firstTags.length() > 0 ){
                for(String tagWeight:firstTags.split("\\|")){
                    String[] tagWeightArray = tagWeight.split("@");
                    firstUserInterTags.put(tagWeightArray[0], Float.parseFloat(tagWeightArray[1]));
                }
            }
            if(secondTags.length() > 0 ){
                for(String tagWeight:secondTags.split("\\|")){
                    String[] tagWeightArray = tagWeight.split("@");
                    secondUserInterTags.put(tagWeightArray[0], Float.parseFloat(tagWeightArray[1]));
                }
            }
            if(thirdTags.length() > 0 ){
                for(String tagWeight:thirdTags.split("\\|")){
                    String[] tagWeightArray = tagWeight.split("@");
                    thirdUserInterTags.put(tagWeightArray[0], Float.parseFloat(tagWeightArray[1]));
                }
            }

        } catch (Exception e) {
//            System.out.println("address long inter:"+userLongInterestsJson+", err:"+String.valueOf(e));
        }

        //add user first level interests to 10
        int firstLevelCnt = firstUserInterTags.size();
        if (firstLevelCnt < 1) {
            for (Map.Entry<String, Float> entry : user_inter_cold_start_map.entrySet()) {
                firstUserInterTags.put(entry.getKey(), entry.getValue());
            }
        } else {
            List<Map.Entry<String, Float>> first_user_inter_list = new ArrayList<Map.Entry<String, Float>>(firstUserInterTags.entrySet());
            Collections.sort(first_user_inter_list, new Comparator<Map.Entry<String, Float>>() {
                @Override
                public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2) {
                    return o1.getValue().compareTo(o2.getValue());
                }
            });
            List<Map.Entry<String, Float>> user_inter_cold_start_list = new ArrayList<>(user_inter_cold_start_map.entrySet());
            Collections.sort(user_inter_cold_start_list, new Comparator<Map.Entry<String, Float>>() {
                @Override
                public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });
            float minWeight = first_user_inter_list.get(0).getValue();
            float top = Math.min(minWeight - 0.1f, 0.5f);
            float firstFill = user_inter_cold_start_list.get(0).getValue();
            Set<String> idSet = new HashSet(firstUserInterTags.keySet());
            boolean flag = false;
            for (Map.Entry<String, Float> m : user_inter_cold_start_list) {
                if (!idSet.contains(m.getKey())) {
                    if (!flag) {
                        firstUserInterTags.put(m.getKey(), top);
                        flag = true;
                        firstFill = m.getValue();
                    } else {
                        firstUserInterTags.put(m.getKey(), m.getValue() / firstFill * top);
                    }
                    firstLevelCnt++;
                    idSet.add(m.getKey());
                    if (firstLevelCnt >= 29) {
                        break;
                    }
                }
            }
        }
        //get and merge short user interest tag to persistant tags
        Map<String, Float> firstUserShortInterTags = new HashMap();
        try {
            String[] firstSecondThirdShortTags = userShortInterestsJson.split(",", -1);
            String firstTags = firstSecondThirdShortTags[0];
            String secondTags = firstSecondThirdShortTags[1];
            String thirdTags = firstSecondThirdShortTags[2];
            String tagName;
            float tagValue;
            if(firstTags.length() > 0 ){
                for(String tagWeight:firstTags.split("\\|")){
                    String[] tagWeightArray = tagWeight.split("@");
                    firstUserShortInterTags.put(tagWeightArray[0], Float.parseFloat(tagWeightArray[1]));
//                    System.out.println("first tagName:"+tagWeightArray[0]+", value:"+tagWeightArray[1]);
                }
            }
            if(secondTags.length() > 0 ){
                for(String tagWeight:secondTags.split("\\|")){
                    String[] tagWeightArray = tagWeight.split("@");
                    tagName = tagWeightArray[0];
                    tagValue = Float.parseFloat(tagWeightArray[1]);
                    if (secondUserInterTags.containsKey(tagName)) {
                        secondUserInterTags.put(tagName, Math.max(secondUserInterTags.get(tagName), tagValue * 0.9f));
                    } else {
                        secondUserInterTags.put(tagName, tagValue * 0.9f);
                    }
//                    System.out.println("sec tagName:"+tagWeightArray[0]+", value:"+tagWeightArray[1]);
                }
            }
            if(thirdTags.length() > 0 ){
                for(String tagWeight:thirdTags.split("\\|")){
                    String[] tagWeightArray = tagWeight.split("@");
                    tagName = tagWeightArray[0];
                    tagValue = Float.parseFloat(tagWeightArray[1]);
                    if (thirdUserInterTags.containsKey(tagName)) {
                        thirdUserInterTags.put(tagName, Math.max(thirdUserInterTags.get(tagName), tagValue * 0.9f));
                    } else {
                        thirdUserInterTags.put(tagName, tagValue * 0.9f);
                    }
//                    System.out.println("third tagName:"+tagWeightArray[0]+", value:"+tagWeightArray[1]);
                }
            }
            List<Map.Entry<String, Float>> firstUserShortInterList = new ArrayList<>(firstUserShortInterTags.entrySet());
            Collections.sort(firstUserShortInterList, new Comparator<Map.Entry<String, Float>>() {
                @Override
                public int compare(Map.Entry<String, Float> o1, Map.Entry<String, Float> o2) {
                    return o2.getValue().compareTo(o1.getValue());
                }
            });
            for (int i = 0; i < firstUserShortInterList.size() && i < 6; ++i) {
                tagName = firstUserShortInterList.get(i).getKey();
                if (firstUserInterTags.containsKey(tagName)) {
                    firstUserInterTags.put(tagName, firstUserInterTags.get(tagName) + firstUserShortInterList.get(i).getValue() * 0.7f);
                } else {
                    firstUserInterTags.put(tagName, firstUserShortInterList.get(i).getValue() * 0.9f);
                }
            }
        } catch (Exception e) {

        }
        //get each level match tag value
        String firstLevelMatchTag;
        if(category.contains("1042015:tagCategory_") || (category.contains("1042015:city_") && !category.contains("new")) || (category.contains("1042015:province_") && !category.contains("new")) ){
            firstLevelMatchTag = category;
        }else if((category.contains("1042015:city_") && category.contains("new")) || (category.contains("1042015:province_") && category.contains("new"))) {
            firstLevelMatchTag = category.substring(0, category.lastIndexOf("_"));
        }else{
            firstLevelMatchTag = getMatchValidValue(firstUserInterTags,firstDocTags);
        }
//        String thirdLevelMatchTag = getMatchValidValue(thirdUserInterTags, thirdDocTags);
        String thirdLevelMatchTag = getMatchValidValueNew(thirdUserInterTags, thirdDocTags, category);
//        String secondLevelMatchTag = getMatchValidValue(secondUserInterTags, secondDocTags);
        String secondLevelMatchTag = getMatchValidValueNew(secondUserInterTags, secondDocTags,category);

        float userThirdMatchTagValue;
        float mblogThirdMatchTagValue;
        if (!thirdLevelMatchTag.equals("invalidValue")) {
            userThirdMatchTagValue = thirdUserInterTags.get(thirdLevelMatchTag);
            mblogThirdMatchTagValue = thirdDocTags.get(thirdLevelMatchTag).weight;
        } else {
            userThirdMatchTagValue = 0f;
            mblogThirdMatchTagValue = 0f;
        }
        float userSecondMatchTagValue;
        float mblogSecondMatchTagValue;
        if (!secondLevelMatchTag.equals("invalidValue")) {
            userSecondMatchTagValue = secondUserInterTags.get(secondLevelMatchTag);
            mblogSecondMatchTagValue = secondDocTags.get(secondLevelMatchTag).weight;
        } else {
            userSecondMatchTagValue = 0f;
            mblogSecondMatchTagValue = 0f;
        }

        float readerWriterIntimacy = ParseIntimacy(userAuthorIntimacy, "1042:".concat(authorId));
//        System.out.println("intimacy:"+readerWriterIntimacy+", auid:"+authorId+",str:"+userAuthorIntimacy);
        int natural_group_ind;
        int born_ind = 4;
        int gender_ind = 2;
        if (born != null && born.equals("90s")) {
            born_ind = 2;
        } else if (born != null && born.equals("80s")) {
            born_ind = 1;
        } else if (born != null && born.equals("70s")) {
            born_ind = 0;
        } else if (born != null && born.equals("00s")) {
            born_ind = 3;
        }
        if (gender != null && gender.equals("f")) {
            gender_ind = 1;
        } else if (gender != null && gender.equals("m")) {
            gender_ind = 0;
        }
        natural_group_ind = 3 * born_ind + gender_ind;

        float newClickNum = 0f;
        String isMatchLongInterest = "0";
        String isMatchShortInterest = "0";
        float firstLevelInteGroupCtr;
        float secondLevelInteGroupCtr;
        float thirdLevelInteGroupCtr;
        float provinceGroupCtr;
        String provinceId = getProvinceId(areaId);

//        int[] categoryArray = discreteCategoricalFeatureNew(category, firstLevelTagsConfigMap, firstLevelTagsNum);
//        int cateInd = categoryArray[1];
//        cateInd == 2 || cateInd == 28
        float defaultMidClickRate = 0.064f;
        if (LOW_CLK_CATES.contains(category)) {
            defaultMidClickRate = 0.032f;
        }
        float defaultMidClickRateReal = 0.123f;
        if (LOW_CLK_CATES.contains(category)) {
            defaultMidClickRateReal = 0.0615f;
        }

        float midRate;
        float midRateReal;
        float midGroupRateReal;

        float midInterRate;
        float midGroupInterRate;
        float exposureNumReal;
        float groupExpoNumReal;

        float midDurationAll;
        float midDurationUv;
        int rankNum;
        float midFeedExpo = 0f;
        float midFeedClk = 0f;
        try {
            String extend2Real;
            if(extend2.contains("##")){
                extend2Real = extend2.substring(extend2.lastIndexOf("#")+1);
            }else {
                extend2Real = extend2;
            }
            JsonObject extend2dictJson = jsonParser.parse(jsonParser.parse(extend2Real).getAsJsonObject().get("doc_dictionary").getAsString()).getAsJsonObject();
            if(extend2dictJson.has("match_long_inte")){
                isMatchLongInterest = "1";
            }
            if(extend2dictJson.has("match_short_inte")){
                isMatchShortInterest = "1";
            }

            //计算真实总点击率、自然人群点击率
            midRate = genClickRate(exposureNum, actNum, defaultMidClickRate);
            exposureNumReal = extend2dictJson.get("real_expo_num").getAsFloat();
            String[] naturalGroupInfoArray = extend2dictJson.get("time_born_gender_real_read").getAsString().split(",");
            groupExpoNumReal = Float.parseFloat(naturalGroupInfoArray[natural_group_ind]);
            midRateReal = genClickRateReal(exposureNumReal, actNum, defaultMidClickRateReal);
            midGroupRateReal = genClickRateReal(groupExpoNumReal, Float.parseFloat(groupActionNum), midRateReal);
            midInterRate = genInterClickRateReal(exposureNumReal, interActNum, defaultMidInterRate);
            midGroupInterRate = genInterClickRateReal(groupExpoNumReal, Float.parseFloat(groupInterActionNum), midInterRate);
            //
            String[] newClickNumArray = extend2dictJson.get("new_clicknum").getAsString().split(",");
            for(String s:newClickNumArray){
                newClickNum += Float.parseFloat(s);
            }
            //计算标签人群点击率
            String firstLevelMatchTagKey = "tag_ctr,".concat(firstLevelMatchTag);
            String secondLevelMatchTagKey = "tag_ctr,".concat(secondLevelMatchTag);
            String thirdLevelMatchTagKey = "tag_ctr,".concat(thirdLevelMatchTag);
            //
            if(extend2dictJson.has(firstLevelMatchTagKey)){
                String[] tagCtr = extend2dictJson.get(firstLevelMatchTagKey).getAsString().split(",");
                firstLevelInteGroupCtr = genClickRate(Float.parseFloat(tagCtr[0]), Float.parseFloat(tagCtr[1]), midRate);
            }else if(!"invalidValue".equals(firstLevelValidTag) && extend2dictJson.has("tag_ctr,".concat(firstLevelValidTag))){
                firstLevelMatchTagKey = "tag_ctr,".concat(firstLevelValidTag);
                String[] tagCtr = extend2dictJson.get(firstLevelMatchTagKey).getAsString().split(",");
                firstLevelInteGroupCtr = genClickRate(exposureNum-Float.parseFloat(tagCtr[0]), actNum-Float.parseFloat(tagCtr[1]), midRate);
            }else{
                firstLevelInteGroupCtr = midRate;
            }
            if(extend2dictJson.has(secondLevelMatchTagKey)){
                String[] tagCtr = extend2dictJson.get(secondLevelMatchTagKey).getAsString().split(",");
                secondLevelInteGroupCtr = genClickRate(Float.parseFloat(tagCtr[0]), Float.parseFloat(tagCtr[1]), firstLevelInteGroupCtr);
            }else if(!"invalidValue".equals(secondLevelValidTag) && extend2dictJson.has("tag_ctr,".concat(secondLevelValidTag))){
                secondLevelMatchTagKey = "tag_ctr,".concat(secondLevelValidTag);
                String[] tagCtr = extend2dictJson.get(secondLevelMatchTagKey).getAsString().split(",");
                secondLevelInteGroupCtr = genClickRate(exposureNum-Float.parseFloat(tagCtr[0]), actNum-Float.parseFloat(tagCtr[1]), midRate);
            }else{
                secondLevelInteGroupCtr = midRate;
            }
            if(extend2dictJson.has(thirdLevelMatchTagKey)){
                String[] tagCtr = extend2dictJson.get(thirdLevelMatchTagKey).getAsString().split(",");
                thirdLevelInteGroupCtr = genClickRate(Float.parseFloat(tagCtr[0]), Float.parseFloat(tagCtr[1]), secondLevelInteGroupCtr);
            }else if(!"invalidValue".equals(thirdLevelValidTag) && extend2dictJson.has("tag_ctr,".concat(thirdLevelValidTag))){
                thirdLevelMatchTagKey = "tag_ctr,".concat(thirdLevelValidTag);
                String[] tagCtr = extend2dictJson.get(thirdLevelMatchTagKey).getAsString().split(",");
                thirdLevelInteGroupCtr = genClickRate(exposureNum-Float.parseFloat(tagCtr[0]), actNum-Float.parseFloat(tagCtr[1]), midRate);
            }else{
                thirdLevelInteGroupCtr = midRate;
            }
            if(provinceConfigMap.containsKey(provinceId)) {
                int expoInd = provinceConfigMap.get(provinceId);
                String[] provinceInfoArray = extend2dictJson.get("province_info").getAsString().split(",");
                provinceGroupCtr = genClickRate(Float.parseFloat(provinceInfoArray[expoInd]), Float.parseFloat(provinceInfoArray[expoInd + 35]), midRate);
            }else{
                provinceGroupCtr = midRate;
            }
            //
            midDurationAll = extend2dictJson.get("real_read_duration").getAsFloat();
            midDurationUv = extend2dictJson.get("real_read_uv").getAsFloat();
            rankNum = extend2dictJson.get("rank").getAsInt();

            //
            String[] midFeedExpoClk = extend2dictJson.get("mid_feed_expo_click").getAsString().split(",");
            if(midFeedExpoClk.length == 7){
                midFeedExpo = Float.parseFloat(midFeedExpoClk[0]);
                for(int i=1; i < 4; i++){
                    midFeedClk += Float.parseFloat(midFeedExpoClk[i]);
                }
            }
        } catch (Exception e) {
            return;
        }
//        float midClickNumRateDefault = 0.2f;
//        if (cateInd == 2 || cateInd == 28) {
//            midClickNumRateDefault = 0.1f;
//        }
        float midClickNumRateDefault = 0.193f;
        if (HIGH_CLK_CATES.contains(category)) {
            midClickNumRateDefault = 0.386f;
        }else if(LOW_CLK_CATES.contains(category)){
            midClickNumRateDefault = 0.0965f;
        }
        float midClickNumRate = genClickNumRateReal(exposureNumReal, newClickNum, midClickNumRateDefault);
        float midGroupClickNumRate = midRateReal>1.0E-4 ? midGroupRateReal / midRateReal * midClickNumRate : midClickNumRate;

//        String invalidKeyWord = parseKeyWords(midKeyWordTags, 0.5f);
        int content_form = getContentForm(picWeight, articleWeight, videoWeight, objWeight);
        int author_property_and_verified_type = getWriterVerifiedType(writerVerifiedType, writerProperty);

        float midDurationAvg = genMidDuration(midDurationAll, midDurationUv, 4263);

        float midFeedClkRate = genFeedClickRate(midFeedExpo, midFeedClk, 0.039f);

        List<String> result = new ArrayList<String>();

        result.add(groupExpoNum);
        result.add(groupActionNum);
        result.add(groupInterActionNum);
        result.add(groupRetNum);
        result.add(groupCmtNum);
        result.add(groupLikeNum);
        result.add(groupExpoRecentNum);
        result.add(groupActionRecentNum);
        result.add(groupInterActionRecentNum);
        result.add(groupRetRecentNum);
        result.add(groupCmtRecentNum);
        result.add(groupLikeRecentNum);
        result.add(String.valueOf(midRateReal));
        result.add(String.valueOf(midInterRate));
        result.add(String.valueOf(midClickNumRate));
        result.add(String.valueOf(midGroupRateReal));
        result.add(String.valueOf(midGroupInterRate));
        result.add(String.valueOf(midGroupClickNumRate));
        result.add(secondLevelValidTag);
        result.add(thirdLevelValidTag);
        result.add(writerVerifiedType);
        result.add(writerProperty);
        result.add(writerFollowersNum);
        result.add(secondLevelMatchTag);
        result.add(thirdLevelMatchTag);
        result.add(String.valueOf(userSecondMatchTagValue));
        result.add(String.valueOf(mblogSecondMatchTagValue));
        result.add(String.valueOf(userThirdMatchTagValue));
        result.add(String.valueOf(mblogThirdMatchTagValue));
        result.add(String.valueOf(readerWriterIntimacy));
        result.add(String.valueOf(content_form));
        result.add(String.valueOf(author_property_and_verified_type));
        result.add(mblogGifNum);
        result.add(mblogLongPicNum);
        result.add(mblogLevel);
        result.add(writer_user_class);
        result.add(invalidKeyWord);
        result.add(mblogTopicNum);
        result.add(text_len);
        result.add(isMatchLongInterest);
        result.add(isMatchShortInterest);
        result.add(String.valueOf(firstLevelInteGroupCtr));
        result.add(String.valueOf(secondLevelInteGroupCtr));
        result.add(String.valueOf(thirdLevelInteGroupCtr));
        result.add(firstLevelMatchTag);
        result.add(isMatchLocation);
        result.add(String.valueOf(provinceGroupCtr));
        result.add(provinceId);
        result.add(String.valueOf(midDurationAll));
        result.add(String.valueOf(midDurationUv));
        result.add(String.valueOf(midDurationAvg));
        result.add(String.valueOf(rankNum));
        result.add(String.valueOf(midFeedExpo));
        result.add(String.valueOf(midFeedClk));
        result.add(String.valueOf(midFeedClkRate));
        forward(result);
    }

    @Override
    public void close() throws HiveException {

    }

}
