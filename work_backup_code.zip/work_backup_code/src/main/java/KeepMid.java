package com.weibo.mytest;
import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;


public class KeepMid extends UDF {
    public String evaluate(String oriValue, int num) {
        if (StringUtils.isNullOrEmpty(oriValue) || oriValue.equals("\\N")) {
            return "NULL";
        }
        String[] mids = oriValue.split(",");
        if (mids.length < num) {
            return "NULL";
        }
        String mid_str = "";
        for (int i = mids.length - 1; i > mids.length - 1 - num; i--) {
            mid_str += mids[i];
            if (i != mids.length - num) {
                mid_str += ",";
            }
        }
        return mid_str;
    }
}
