package com.weibo.mytest;

/**
 * Created by pengyu on 2017/2/28.
 */


import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;


public class ComputeTagMatch extends UDF{
    public double evaluate(String mid, String uid){
        if (StringUtils.isNullOrEmpty(mid) || StringUtils.isNullOrEmpty(uid) || !mid.contains("@") || !uid.contains("@")){
            return 0;
        }
        if (mid.equals("\\N") || uid.equals("\\N")){
            return 0;
        }

        Map<String, Double> midMap = getMap(mid);
        Map<String, Double> uidMap = getMap(uid);

        uidMap.keySet().retainAll(midMap.keySet());
        if (uidMap.isEmpty()){
            return 0;
        }

        return Collections.max(uidMap.values());
    }

    public Map<String, Double> getMap(String s){
        String[] tagList = s.split("\\|");
        Map<String, Double> res = new HashMap<String, Double>();
        for (String tag : tagList){
            res.put(tag.split("@")[0], Double.parseDouble(tag.split("@")[1]));
        }
        return res;
    }

}
