/**
 * Created by huinan1 on 18/10/22.
 */
//
//import java.util.*;
//
//
//// TODO define input and output types, e.g. "double->double".
//public class GetLrAuc extends Aggregator {
//
//    private DoubleWritable ret = new DoubleWritable();
//
//    @Override
//    public void setup(ExecutionContext ctx) throws UDFException {
//
//    }
//
//    @Override
//    public Writable newBuffer() {
//        // TODO
//        return new MapWritable();
//    }
//
//    public double[] getUidAuc(ArrayList<Double[]> score_labels){
//        Collections.sort(score_labels, new Comparator<Double[]>() {
//            @Override
//            public int compare(Double[] o1, Double[] o2) {
//                if(o2[0] > o1[0]){
//                    return 1;
//                }else if(o2[0] < o1[0]){
//                    return -1;
//                }else{
//                    if(o2[1] > o1[1]){
//                        return -1;
//                    }else if(o2[1] < o1[1]){
//                        return 1;
//                    }else{
//                        return 0;
//                    }
//                }
//            }
//        });
//        int posNum = 0;
//        int posRank = 0;
//        int samplesNum = score_labels.size();
//        int rankInd = samplesNum;
//        for(Double[] a:score_labels){
//            if(a[1] > 0){
//                posRank += rankInd;
//                posNum += 1;
////                System.out.println("score:"+a[0]+",label:"+a[1]+",pos_ind:"+rankInd);
//            }
//            rankInd -= 1;
//        }
////        System.out.println("posNum:"+posNum);
////        System.out.println("posRank:"+posRank);
////        System.out.println("cnt(examples):"+score_labels.size());
//        double[] ret = new double[2];
//        ret[0] = samplesNum;
//        if(posNum > 0 && posNum < samplesNum) {
//            ret[1] = (double) (posRank - posNum * (posNum + 1) / 2) / (posNum * (samplesNum-posNum));
//        }else{
//            ret[1] = 0;
//        }
//        return ret;
//    }
//
//    @Override
//    public void iterate(Writable buffer, Writable[] args) throws UDFException {
//        // to get the auc and expo num of one uid
//
//        if(args.length != 3){
//            return;
//        }
//        MapWritable mw = (MapWritable)buffer;
//        Text uid = new Text(args[0].toString());
//        String score_label = args[1].toString().trim().concat("\t").concat(args[2].toString().trim());
////        System.out.println("uid:".concat(args[0].toString()).concat("@").concat(score_label));
//        if(mw.containsKey(uid)) {
//            Text value = (Text)mw.get(uid);
//            value.append(("@").concat(score_label).getBytes(), 0, score_label.length()+1);
//            mw.put(uid, value);
//        }else {
//            mw.put(uid, new Text(score_label));
//        }
//
//    }
//
//    @Override
//    public void merge(Writable buffer, Writable partial) throws UDFException {
//        // TODO
//        MapWritable result = (MapWritable) buffer;
//        MapWritable partialReal = (MapWritable) partial;
//        for(Map.Entry<Writable,Writable> entry:partialReal.entrySet()) {
//            Text uid = (Text) entry.getKey();
//            String score_label = entry.getValue().toString();
//            if (result.containsKey(uid)) {
//                Text value = (Text) result.get(uid);
//                value.append(("@").concat(score_label).getBytes(), 0, score_label.length() + 1);
//                result.put(uid, value);
//            } else {
//                result.put(uid, new Text(score_label));
//            }
//        }
//    }
//
//    @Override
//    public Writable terminate(Writable buffer) throws UDFException {
//        // TODO
//        MapWritable mw = (MapWritable) buffer;
//        int expoNum = 0;
//        double aucTotal = 0;
//        for(Map.Entry<Writable, Writable> entry:mw.entrySet()){
//            ArrayList<Double[]> score_labels = new ArrayList();
//            String uid = entry.getKey().toString();
//            String value = entry.getValue().toString();
////            System.out.println("uid:".concat(uid).concat("|").concat(value));
//            for (String s:value.split("@")){
//                score_labels.add(new Double[]{Double.parseDouble(s.split("\t")[0]),Double.parseDouble(s.split("\t")[1])});
//            }
//            double[] auc = getUidAuc(score_labels);
//            expoNum += auc[0];
//            aucTotal += (auc[0] * auc[1]);
////            System.out.println("uid:".concat(uid).concat("@auc:").concat(String.valueOf(auc[1])).concat("@expo:").concat(String.valueOf(auc[0])));
//        }
//        ret.set(aucTotal / expoNum);
//        return ret;
//    }
//
//    @Override
//    public void close() throws UDFException {
//
//    }
//
//}
