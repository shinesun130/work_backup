package com.weibo.mytest;

import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by zongheng on 2017-12-19.
 */
public class CalActRate_v2 extends UDF{
    public double evaluate(String actStr, String expoStr, String iStr){
        double act = 0;
        double expo = 0;
        if (!StringUtils.isNullOrEmpty(actStr) && !actStr.equals("\\N")){
            act = Double.parseDouble(actStr);
        }

        if (!StringUtils.isNullOrEmpty(expoStr) && !expoStr.equals("\\N")){
            expo = Double.parseDouble(expoStr);
        }

	double i = Double.parseDouble(iStr);

	if(expo == 0){
		return (act + i) / (10000 + act + expo);
	}

	expo = Math.max(act, expo);
	double p = act / expo;
	double z = 1.96;
	double score = (p + Math.pow(z, 2) / (2 * expo) - z * Math.sqrt((p * (1 - p) + Math.pow(z, 2) / (4 * expo)) / expo)) / (1 + Math.pow(z, 2) / expo);

	return Math.max(0.0, score);
    }
}
