package com.weibo.mytest;
/**
 * Created by huinan1 on 18/10/18.
 */
class Tag {
    int type;
    float weight;
    String category;
}

public class UtilClass {

}
