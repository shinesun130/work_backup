package com.weibo.mytest;

import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huinan1 on 18/10/17.
 */

//@Resolve({"string->string,string,string,string,string,string,string,string,string,string,string"})
public class ExtractExpoMsg extends GenericUDTF {
    @Override
    public void process(Object[] args) throws HiveException {
        String extend = args[0].toString();
        JsonObject extend_info;
        try {
            extend_info = getJsonObject(extend);
        } catch (Exception e) {
//            throw new UDFException(e);
            return;
        }
        JsonObject exposure_info = getJsonObject(getJsonString(extend_info, "exposure_interaction_rate", "{}"));
        JsonObject recommend_info = getJsonObject(getJsonString(extend_info, "recommend_sources", "{}"));
        int total_read_num = getJsonInt(extend_info, "total_read_num", 0);
        int inter_act_num = getJsonInt(exposure_info, "inter_act_num", 0);
        int inter_act_num_recent = getJsonInt(exposure_info, "inter_act_num_recent", 0);
        int hot_ret_num = getJsonInt(exposure_info, "hot_ret_num", 0);
        int hot_cmt_num = getJsonInt(exposure_info, "hot_cmt_num", 0);
        int hot_like_num = getJsonInt(exposure_info, "hot_like_num", 0);
        int hot_ret_num_recent = getJsonInt(exposure_info, "hot_ret_num_recent", 0);
        int hot_cmt_num_recent = getJsonInt(exposure_info, "hot_cmt_num_recent", 0);
        int hot_like_num_recent = getJsonInt(exposure_info, "hot_like_num_recent", 0);
        JsonArray time_born_gender_action_list = getJsonArray(exposure_info, "time_born_gender_action_list", new JsonArray());
        int recommend_base_level = getJsonInt(recommend_info, "recommend_source_detail", -1);
        List<String> result = new ArrayList<String>();
        result.add(String.valueOf(total_read_num));
        result.add(String.valueOf(inter_act_num));
        result.add(String.valueOf(inter_act_num_recent));
        result.add(String.valueOf(hot_ret_num));
        result.add(String.valueOf(hot_cmt_num));
        result.add(String.valueOf(hot_like_num));
        result.add(String.valueOf(hot_ret_num_recent));
        result.add(String.valueOf(hot_cmt_num_recent));
        result.add(String.valueOf(hot_like_num_recent));
        result.add(String.valueOf(time_born_gender_action_list.toString()));
        result.add(String.valueOf(recommend_base_level));
        forward(result);
    }

    private static JsonObject getJsonObject(String json) {
        JsonParser jsonParser = new JsonParser();
        return jsonParser.parse(json).getAsJsonObject();
    }

    private static String getJsonString(JsonObject jo, String key, String defaultValue) {
        JsonElement jsonElement = jo.get(key);
        if (jsonElement != null) {
            return jsonElement.getAsString();
        } else {
            return defaultValue;
        }
    }

    private static int getJsonInt(JsonObject jo, String key, int defaultValue) {
        JsonElement jsonElement = jo.get(key);
        if (jsonElement != null) {
            return jsonElement.getAsInt();
        } else {
            return defaultValue;
        }
    }

    private static JsonArray getJsonArray(JsonObject jo, String key, JsonArray defaultValue) {
        JsonElement jsonElement = jo.get(key);
        if (jsonElement != null) {
            return jsonElement.getAsJsonArray();
        } else {
            return defaultValue;
        }
    }

    @Override
    public StructObjectInspector initialize(StructObjectInspector argOIs)  throws UDFArgumentException {
        try {
//            if (argOIs.getCategory() != ObjectInspector.Category.PRIMITIVE) {
//                throw new UDFArgumentException("ExplodeMap takes string as a parameter");
//            }

            ArrayList<String> fieldNames = new ArrayList<>();
            ArrayList<ObjectInspector> fieldOIs = new ArrayList<>();
            String[] features_out={
                    "total_read_num",
                    "inter_act_num",
                    "inter_act_num_recent",
                    "hot_ret_num",
                    "hot_cmt_num",
                    "hot_like_num",
                    "hot_ret_num_recent",
                    "hot_cmt_num_recent",
                    "hot_like_num_recent",
                    "time_born_gender_action_list",
                    "recommend_base_level"

            };
            for(int i = 0; i < features_out.length; i++){
                fieldNames.add(features_out[i]);
                fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
            }
            return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);

        } catch (Exception e) {
            throw new UDFArgumentException(e);
        }
    }

    @Override
    public void close() throws HiveException {

    }

}