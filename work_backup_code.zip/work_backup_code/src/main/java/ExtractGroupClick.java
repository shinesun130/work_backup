package com.weibo.mytest;

import java.util.Arrays;
import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.exec.UDFArgumentLengthException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by huinan1 on 18/10/18.
 */

//"born_index,gender_index,time_born_gender_action_list->all_group_msg,hour_group_msg"
//@Resolve({"bigint,bigint,string->string,string"})
public class ExtractGroupClick extends GenericUDTF {
    @Override
    public void process(Object[] args) throws HiveException {
//        int born_index = ((Long) args[0]).intValue();
//        int gender_index = ((Long) args[1]).intValue();
//        String time_born_gender_action_list = (String) args[2];
        int born_index = ((Long)Long.parseLong(args[0].toString())).intValue();
        int gender_index = ((Long)Long.parseLong(args[1].toString())).intValue();
        String time_born_gender_action_list = args[2].toString();
        String[] time_born_genders = time_born_gender_action_list.trim().replaceAll("^[\\[|\\]| ]+", "").replaceAll("[\\[|\\]| ]+$", "").split(",");
        // 目前数组一共180个数字 前半段是历史的 后半段是小时的
        // 前半段是70男、70女、70other、80男、80女、80other、90男、90女、90other、00男、00女、00other、other男、other女、other_other的曝光、点击、互动、转发、评论、赞
        // 5*3*6 (年龄*性别*互动行为) born index 是传入的user 所在的born index, gender index是传入的gender index
        List<String> result = new ArrayList<String>();
        if (time_born_genders.length == 180) {
            // all_group_index 是历史互动情况
            int all_group_index = born_index * 3 * 6 + gender_index * 6;
            // hour_group_index 小时互动情况
            int hour_group_index = all_group_index + 5 * 3 * 6;
            result.add(Arrays.toString(Arrays.copyOfRange(time_born_genders, all_group_index, all_group_index + 6)));
            result.add(Arrays.toString(Arrays.copyOfRange(time_born_genders, hour_group_index, hour_group_index + 6)));
            forward(result);
//            forward(Arrays.toString(Arrays.copyOfRange(time_born_genders, all_group_index, all_group_index + 6)),
//                    Arrays.toString(Arrays.copyOfRange(time_born_genders, hour_group_index, hour_group_index + 6)));

        } else if (time_born_genders.length == 255) {
            int all_group_index = born_index * 3 * 7 + gender_index * 7;
            int hour_group_index = all_group_index + 6 * 3 * 7;
            result.add(Arrays.toString(Arrays.copyOfRange(time_born_genders, all_group_index, all_group_index + 7)));
            result.add(Arrays.toString(Arrays.copyOfRange(time_born_genders, hour_group_index, hour_group_index + 7)));
            forward(result);
        } else {
            result.add("[]");
            result.add("[]");
            forward(result);
        }
    }

    @Override
    public StructObjectInspector initialize(StructObjectInspector argOIs)  throws UDFArgumentException {
        try {
//            if (argOIs.getCategory() != ObjectInspector.Category.PRIMITIVE) {
//                throw new UDFArgumentException("ExplodeMap takes string as a parameter");
//            }

            ArrayList<String> fieldNames = new ArrayList<>();
            ArrayList<ObjectInspector> fieldOIs = new ArrayList<>();
            String[] features_out={
                    "all_group_msg",
                    "hour_group_msg"
            };
            for(int i = 0; i < features_out.length; i++){
                fieldNames.add(features_out[i]);
                fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
            }
            return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);

        } catch (Exception e) {
            throw new UDFArgumentException(e);
        }
    }


    @Override
    public void close() throws HiveException {

    }
}
