package com.weibo.mytest;

import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;


public class ReplaceNULL extends UDF{
    public String evaluate(String oriValue, String newValue){
        if (StringUtils.isNullOrEmpty(oriValue) || oriValue.equals("\\N")){
            return newValue;
        }
        return oriValue;
    }
}
