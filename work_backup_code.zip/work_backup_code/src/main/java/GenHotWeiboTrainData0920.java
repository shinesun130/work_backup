package com.weibo.mytest;
/**
 * Created by huinan1 on 18/10/22.
 */

import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

import java.util.*;

// TODO define input and output types, e.g. "string,string->string,bigint".
public class GenHotWeiboTrainData0920 extends GenericUDTF {

    private static Set<String> interActionCodes = new HashSet<String>() {{
        add("3");
        add("381");
        add("658");
        add("659");
        add("4");
        add("336");
        add("932");
        add("933");
        add("6");
        add("3add");
        add("6add");
    }};

    private static Set<String> picClickCodes = new HashSet<String>() {{
        add("41");
        add("54");
        add("55");
        add("127");
        add("128");
        add("749");
    }};

    private static Set<String> retActionCodes = new HashSet<String>() {{
        add("3");
        add("381");
        add("658");
        add("659");
    }};

    private static Set<String> cmtActionCodes = new HashSet<String>() {{
        add("4");
        add("336");
        add("932");
        add("933");
    }};

    public static Map<String, Integer> actValueMap = new HashMap<String, Integer>() {{
        //initial pic weight
        put("41", 1);
        put("54", 1);
        put("55", 1);
        put("127", 1);
        put("128", 1);
        put("749", 1);

        //initial video weight
        put("799", 2);

        //initial article weight
        put("1423", 2);

        //initial main text weight
        put("7", 2);

        //initial follow weight
        put("91", 5);

        //initial ret weight
        put("3", 20);
        put("381", 20);
        put("658", 20);
        put("659", 20);

        //initial cmt weight
        put("4", 15);
        put("336", 15);
        put("932", 15);
        put("933", 15);

        //initial like weight
        put("6", 15);
    }};

    public static int isInterAction(String ac) {
        if (ac == null) {
            return 0;
        }
        String[] acArray = ac.trim().split(",");
        List<String> acList = new ArrayList<String>();
        int aLen = acArray.length;
        for (int i = 0; i < aLen; i++) {
            acList.add(acArray[i]);
        }
//        List acList = Arrays.asList(acArray);
        acList.retainAll(interActionCodes);
        if (acList.size() > 0) {
            return 1;
        } else {
            return 0;
        }
    }

    public static int getPosSamplesWeight(String ac) {
        if (ac == null) {
            return 0;
        }
        int pos = 0;
        Set<String> acSets = new HashSet<String>(Arrays.asList(ac.trim().split(",")));
        for (String acSet : acSets) {
            if (actValueMap.containsKey(acSet)) {
                pos += actValueMap.get(acSet);
            }
        }
        return pos;
    }

    public static String[] transToBinary(String fea) {
        String[] feaArray = fea.trim().split(" ");
        StringBuilder sb = new StringBuilder();
        for (String s : feaArray) {
            String[] sTmp = s.split(":");
            if (Float.parseFloat(sTmp[1]) != 1) {
                throw new RuntimeException("Unsupported feature data: " + fea);
            }
            sb.append(sTmp[0]);
            sb.append(",");
        }
        String resTmp = sb.toString();
        String[] res = new String[2];
        res[0] = resTmp.substring(0, resTmp.length() - 1);
        res[1] = String.valueOf(feaArray.length);
        return res;
    }

    @Override
    public void process(Object[] args) throws HiveException {
        // TODO
//        int interActionCoeff = Integer.parseInt(args[0].toString());
//        int isClick = Integer.parseInt(args[1].toString());
//        String features = (String) args[2];
//        int picWeight = (int) Float.parseFloat((String) args[3]);
//        int articleWeight = (int) Float.parseFloat((String) args[4]);
//        int videoWeight = (int) Float.parseFloat((String) args[5]);
//        int objWeight = (int) Float.parseFloat((String) args[6]);
//        String actions = (String) args[7];
//        String isAutoPlay = (String) args[8];
//        String firstMatchTag = (String) args[9];
//        String secondMatchTag = (String) args[10];
//        String thirdMatchTag = (String) args[11];
        int interActionCoeff = Integer.parseInt(args[0].toString());
        int isClick = Integer.parseInt(args[1].toString());
        String features = (String) args[2];
        int picWeight = (int) Float.parseFloat((String) args[3]);
        int longPicWeight = (int) Float.parseFloat((String) args[4]);
        int gifPicWeight = (int) Float.parseFloat((String) args[5]);
        int articleWeight = (int) Float.parseFloat((String) args[6]);
        int videoWeight = (int) Float.parseFloat((String) args[7]);
        int objWeight = (int) Float.parseFloat((String) args[8]);
        String actions = (String) args[9];
        String isAutoPlay = (String) args[10];
        String firstMatchTag = (String) args[11];
        String secondMatchTag = (String) args[12];
        String thirdMatchTag = (String) args[13];
        float duration = Float.parseFloat((String) args[14]);
        String[] binaryFeatures = transToBinary(features);
        if (isClick == 0) {
            Object[] result = {(long) 0, Long.parseLong(binaryFeatures[1]), binaryFeatures[0], (long) 0, (long) 1};
            forward(result);
        } else if (isClick == 1) {
            if (isAutoPlay != null && Integer.parseInt(isAutoPlay) == 1 && Math.random() > 0) {
                return;
            }
            int posLen;
            int isInterAction = isInterAction(actions);
            //large scale model 2.2 : multi-objection: 0.42
            if (Math.random() >= 0.42 && isInterAction == 0) {
                return;
            }
            if (isAutoPlay != null && Integer.parseInt(isAutoPlay) == 0 && ((actions.contains("799") && picWeight <= 0) || (actions.contains("1423") && picWeight <= 0 && videoWeight <= 0))) {
                posLen = 2;
            } else {
                posLen = 1;
            }
            posLen += isInterAction * interActionCoeff;
            Object[] result = {(long) 0, Long.parseLong(binaryFeatures[1]), binaryFeatures[0], (long) posLen, (long) 0};
            forward(result);
        }
    }

    @Override
    public void close() throws HiveException {

    }

}
