package com.weibo.mytest;
/**
 * Created by huinan1 on 18/10/22.
 */
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import org.apache.hadoop.hive.ql.exec.UDFArgumentException;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.udf.generic.GenericUDTF;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.ObjectInspectorFactory;
import org.apache.hadoop.hive.serde2.objectinspector.StructObjectInspector;
import org.apache.hadoop.hive.serde2.objectinspector.primitive.PrimitiveObjectInspectorFactory;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

// TODO define input and output types, e.g. "string,string->string,bigint".
public class GenIsThirdTagFeature extends GenericUDTF {

    static Map<String, Integer> firstLevelTagsConfigMap;
    static Map<String, Integer> thirdLevelTagsConfigMap;

    public Map<String, Integer> loadDictConfigFileWithIndex(String fileName) throws HiveException {
        Map<String, Integer> configMap = new HashMap<String, Integer>();
        try {
            InputStream in = new FileInputStream(new File(fileName));
            BufferedReader br = new BufferedReader(new InputStreamReader(in));
            String line;
            int ind = 0;
            while ((line = br.readLine()) != null) {
                configMap.put(line, ind);
                ind++;
            }
            return configMap;
        } catch (IOException e) {
            throw new HiveException(e);
        }
    }

    private static List<Map> jsonToList(String data) {
        GsonBuilder gb = new GsonBuilder();
        Gson g = gb.create();
        List<Map> list = g.fromJson(data, new TypeToken<List<Map>>() {
        }.getType());
        return list;
    }

    private static String getValidValue(Map<String, Tag> tagMap, float validValue) {
        String resTag = "invalidValue";
        float resValue = 0.0f;
        if (tagMap.size() > 0) {
            for (Map.Entry<String, Tag> m : tagMap.entrySet()) {
                float curValue = m.getValue().weight;
                if (curValue > resValue && curValue >= validValue) {
                    resTag = m.getKey();
                    resValue = curValue;
                }
            }
        }
        return resTag;
    }

    @Override
    public StructObjectInspector initialize(StructObjectInspector argOIs) throws UDFArgumentException {
        try {
            firstLevelTagsConfigMap = loadDictConfigFileWithIndex("first_tags_feature_config");
            thirdLevelTagsConfigMap = loadDictConfigFileWithIndex("third_tags_feature_config");
            ArrayList<String> fieldNames = new ArrayList<String>();
            ArrayList<ObjectInspector> fieldOIs = new ArrayList<ObjectInspector>();
            fieldNames.add("third_other");
            fieldOIs.add(PrimitiveObjectInspectorFactory.javaStringObjectInspector);
            return ObjectInspectorFactory.getStandardStructObjectInspector(fieldNames, fieldOIs);
        } catch (Exception e) {
            throw new UDFArgumentException(e);
        }
    }

    @Override
    public void process(Object[] args) throws HiveException {
        // TODO
        String cate = (String) args[0];
        String docTagsJson = (String) args[1];
        Map<String, Tag> thirdDocTags = new HashMap<>();
        try {
            List<Map> docTags = jsonToList(docTagsJson);
//            System.out.println("json:"+docTagsJson);
            int tagsLen = docTags.size();
            for (int i = 0; i < tagsLen; i++) {
                double tagType = (Double) docTags.get(i).get("type");
                Tag t = new Tag();
                if (tagType == 3 && !docTags.get(i).get("tagid").toString().contains("tagTopic_") && !docTags.get(i).get("tagid").toString().contains("keyWord_")) {
                    t.weight = Float.parseFloat(docTags.get(i).get("rel_weight").toString());
                    t.type = (int) tagType;
                    t.category = docTags.get(i).get("category").toString();
                    thirdDocTags.put(docTags.get(i).get("tagid").toString(), t);
                }
            }
        } catch (Exception e) {
            return;
//            if(firstLevelTagsConfigMap.containsKey(cate)){
//                forward(cate);
//            }else{
//                forward("except_other");
//            }
        }
        String thirdLevelValidTag = getValidValue(thirdDocTags, 0.6f);
        if (thirdLevelTagsConfigMap.containsKey(thirdLevelValidTag)) {
            forward(thirdLevelValidTag);
        } else {
            if (firstLevelTagsConfigMap.containsKey(cate)) {
                forward(cate);
            } else {
                forward("third_other");
            }
        }
    }

    @Override
    public void close() throws HiveException {

    }

}
