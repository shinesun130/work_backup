package com.weibo.mytest;

import com.mysql.jdbc.StringUtils;
import org.apache.hadoop.hive.ql.exec.UDF;

/**
 * Created by pengyu on 2017-3-6.
 */
public class CalActRate extends UDF{
    public double evaluate(String actStr, String expoStr, String iStr,  String kStr){
        double act = 0;
        double expo = 0;
        if (!StringUtils.isNullOrEmpty(actStr) && !actStr.equals("\\N")){
            act = Double.parseDouble(actStr);
        }

        if (!StringUtils.isNullOrEmpty(expoStr) && !expoStr.equals("\\N")){
            expo = Double.parseDouble(expoStr);
        }

        double i = Double.parseDouble(iStr);
        double k = Double.parseDouble(kStr);

        if (expo == 0 || act > expo){
            return (act + i) / (10000 + act + expo);
        }

        if (expo < 1000){
            return (act + i / 10) / (1000 + expo);
        }

        return Math.max(0.0, 1 - k / expo) * act / expo;


    }
}
