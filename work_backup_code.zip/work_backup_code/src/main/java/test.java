package com.weibo.mytest;
/**
 * Created by huinan1 on 18/10/22.
 */
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.*;
import java.lang.Exception;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;


public class test {
    private static String[] bornConfigArray = new String[]{"70s", "80s", "90s", "00s"};
    private static String[] genderConfigArray = new String[]{"f", "m"};

    public int test_multi_args(String keys, String... values) {

        return values.length;
    }
    static Map<String, Integer> bornConfigMap = new HashMap<String, Integer>() {{
        put("70s", 0);
        put("80s", 1);
        put("90s", 2);
        put("00s", 3);
    }};


    public static void main(String args[]) {

        JsonParser jsonParser = new JsonParser();

//        GetLrAuc gl = new GetLrAuc();
        String[] s = "3913824579386790,8,0,216".split(",");
        float f = 0;
        for(String ss:s){
            f+=Float.parseFloat(ss);
        }
        float a = 1.1e-8f;
        System.out.println(a);
    }

}

