package com.weibo.mytest;
/**
 * Created by huinan1 on 18/10/22.
 */
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.apache.hadoop.hive.ql.metadata.HiveException;
import org.apache.hadoop.hive.ql.exec.UDF;

import java.util.Map;

public class TransformIntimacy extends UDF {
    // TODO define parameters and return type, e.g:  public String evaluate(String a, String b)
    JsonParser jsonParser = new JsonParser();

    public String evaluate(String s) {
        JsonObject jo = jsonParser.parse(s.trim()).getAsJsonObject();
        StringBuilder sb = new StringBuilder();
        for(Map.Entry<String, JsonElement> entry:jo.entrySet()){
            String uid = entry.getKey();
            JsonObject tmp = entry.getValue().getAsJsonObject();
            String weight = tmp.get("weight").getAsString();
            String type = tmp.get("type").getAsString();
            sb.append(uid).append("@").append(weight).append("@").append(type).append("|");
        }
        String ret = sb.toString();
        return ret.substring(0, ret.length()-1);
    }
}
