#! /bin/sh

path1="10.77.96.141::people_attack/rsc"
path2="10.77.96.142::people_attack/rsc"
path3="10.77.96.143::people_attack/rsc"
path4="10.77.96.144::people_attack/rsc"
path5="10.77.96.145::people_attack/rsc"
path6="10.77.96.146::people_attack/rsc"
path7="10.77.96.147::people_attack/rsc"
path8="10.77.96.245::people_attack/rsc"
path9="10.77.96.246::people_attack/rsc"
path10="10.77.96.247::people_attack/rsc"
path11="10.77.96.248::people_attack/rsc"

data_path="/data0/liubo/on_line_update/people_attack/shell"

if [ -f $data_path/blackList.txt ]
then
		rsync -av $data_path/blackList.txt $path1
		rsync -av $data_path/blackList.txt $path2
		rsync -av $data_path/blackList.txt $path3
		rsync -av $data_path/blackList.txt $path4
		rsync -av $data_path/blackList.txt $path5
		rsync -av $data_path/blackList.txt $path6
		rsync -av $data_path/blackList.txt $path7
		rsync -av $data_path/blackList.txt $path8
		rsync -av $data_path/blackList.txt $path9
		rsync -av $data_path/blackList.txt $path10
		rsync -av $data_path/blackList.txt $path11
fi
