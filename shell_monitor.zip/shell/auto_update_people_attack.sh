#! /bin/sh

data_path="/data0/liubo/on_line_update/people_attack/rsc"
bak_path="/data0/liubo/on_line_update/people_attack/rsc_bak"

if [ -f $data_path/blackList.txt ]
then
		mv $data_path/blackList.txt .
		sh update_people_attack.sh
		date=`date -d "+0 days" +"%Y%m%d%H%M"`
		date2=`date -d "+0 days" +"%Y-%m-%d %H:%M"`
		mv blackList.txt ../rsc_bak/blackList.txt_$date
		echo "update resoure $date2" >> ../log/log.txt
fi
