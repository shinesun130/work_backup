/*****************************************************
 * @file:interactpredict.cpp
 *
 * @author:liubo9@staff.sina.com.cn
 *
 * @date:2015-09-18
 *
 * @description:interact ratio predict
 *****************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <iostream>
#include <pthread.h>
#include <assert.h>
#include <map>
#include <set>
#include "modulecommon.h"
#include "parsejson.h"
#include "StringTool.h"
#include "linear.h"
#include "tron.h"
#include "feature.h"
using namespace std;

#define MAX_ATTR 1024


struct  InteractPredict{
	struct model* model_;
    FeatureManager* feature_manager;
	char configFile[1024];
	logger_t logger;
	map<long,string>* source;
};

struct module_thread_data{
	JsonTree_t *ptree;
	JsonText_t *ptext;
	struct feature_node *x;
};

void* module_load(const char * data_dir,logger_t logger){
	cerr<<"initing global data from:"<<data_dir<<endl;
	InteractPredict* module = (InteractPredict*)malloc(sizeof(InteractPredict));
	strcpy(module->configFile,data_dir);
	char file[1024];
	sprintf(file,"%s/interact_predict.mdl",data_dir);
	module->model_ = load_model(file);
	if(NULL == module->model_){
		cerr<<"load interact model failed!"<<endl;
		return NULL;
	}
	module->feature_manager = new FeatureManager();
	sprintf(file,"%s/feature.map",data_dir);
	if(!module->feature_manager->Init(file))
	{
		cerr<<"init feature map file failed"<<endl;
		return NULL;
	}
/*	sprintf(file,"%s/source.conf",data_dir);
	module->source = InitSource(file);
	if(module->source == NULL)
	{
		cerr<<"init source file failed!"<<endl;
		return NULL;
	}*/
	module->logger = logger;
	cerr<<"glabal data init success!"<<endl;
	return (void*)module;
}


int module_unload(void* plug){
	InteractPredict *module = (InteractPredict*)plug;
	delete (struct model*) module->model_;
	module->model_ = NULL;
	free(module);
}



void *module_thread_data_create(void* plug){
	module_thread_data* thread_data = (module_thread_data*)malloc(sizeof(module_thread_data));
	assert(thread_data != NULL);
	thread_data->ptree = CreateJsonTree();
	assert(thread_data->ptree != NULL);
	thread_data->ptext = CreateJsonText(1000);
	assert(thread_data->ptext != NULL);
	thread_data->x = (struct feature_node *) malloc(MAX_ATTR*sizeof(struct feature_node));
	InteractPredict* module = (InteractPredict*) plug;
	return thread_data;
}


void module_thread_data_release(void*plug,void *thread_data){
	module_thread_data* t_data = (module_thread_data*)thread_data;
	if(t_data->ptree != NULL)
	{
		FreeJsonTree(t_data->ptree);
		t_data->ptree = NULL;
		FreeJsonText(t_data->ptext);
		t_data->ptext = NULL;
		free(t_data->x);
		t_data->x = NULL;
	}
	free(thread_data);
}

int ParseJsonInput(module_thread_data *workData,map<string,string>&tField, char *input, int srcLen)
{
	int ret;
	JsonTree_t *ptree = workData->ptree;
	PairNode_t *ppair;
	ret = ParseJson(input, srcLen, ptree);
	if(ret<=0)
	  return -1;
	if(ptree->rootType!=V_PAIR_ARRAY)
	  return -2;
	map<string,string>::iterator it;
	tField.clear();
	ForEachPairNode(ptree, 0, ppair)
	{
		if(ppair->keyStr==NULL || ppair->pStr==NULL || 
					(ppair->v_type != V_STR && ppair->v_type != V_VALUE_STR))
		  return -3;
#ifdef DEBUG2
		fprintf(stderr,"parseJson:%s-->%s\n",ppair->keyStr,ppair->pStr);
#endif
		it=tField.find(ppair->keyStr);
		if(it==tField.end())
		  tField.insert(map<string,string>::value_type(ppair->keyStr,ppair->pStr));
	}
	return 0;
}

void GenResult(char *resultStr,int &resultLen,map<string,string>& resMap)
{
	map<string,string>::iterator sit;
	string resstr = "{";
	for(sit = resMap.begin();sit != resMap.end();sit++)
	{
		resstr += "\"" + sit->first + "\":\"" + sit->second + "\",";
	}
	string res = resstr.substr(0,resstr.size() - 1) + "}";
#ifdef DEBUG
	cerr<<res<<"#"<<endl;
#endif
	strcpy(resultStr,res.c_str());
	resultLen = res.length();
}

int do_predict(InteractPredict *workModule,module_thread_data *workData,
			set<pair<int,double> >& input,double *prob_estimates)
{
	struct model* model_ = workModule->model_;
	struct feature_node *fnode = workData->x;
	int nr_feature=get_nr_feature(model_);
	int n = 0,i = 0;
	if(model_->bias>=0)
	  n=nr_feature+1;
	else
	  n=nr_feature;
	int cur_index = 0;
	set<pair<int,double> >::iterator it;
	for(it = input.begin();it != input.end();it++)
	{
		fnode[cur_index].index = it->first;
		fnode[cur_index].value = it->second;
		cerr<<it->first<<":"<<it->second<<"\t";
		cur_index++;
	}
	cerr<<endl;
	if(model_->bias>=0)
	{
		fnode[cur_index].index = n;
		fnode[cur_index].value = model_->bias;
		cur_index++;
	}
	fnode[cur_index].index = -1;
	double predict_label = predict_probability(model_,fnode,prob_estimates);
	int labels[2];
	get_labels(model_,labels);
	for(int j=0;j<model_->nr_class;j++)
	{
		char key[24],value[24];
		cerr<<labels[j]<<":"<<prob_estimates[j]<<endl;
	}
	return 0;
}


int module_processor(void* module,const char *input,int intput_space_size ,char *output, int output_space_size, void *thread_data){
#ifdef DEBUG
	cerr<<"input:"<<input<<endl;
#endif
	strcpy(output,input);
	InteractPredict* workModule = (InteractPredict*) module;
	module_thread_data *workData = (module_thread_data *)thread_data;
	strcpy(output,"default result");
	map<string,string> tField;
	map<string,string> rMap;
	map<string,string>::iterator sit;
	char Log[65535];
	memcpy(Log,input,intput_space_size);
	int iret = ParseJsonInput(workData,tField,Log,intput_space_size);
	if(iret < 0)
	{
		rMap.insert(map<string,string>::value_type("error","parse input failed"));
		GenResult(output,output_space_size,rMap);
		return output_space_size;
	}
	/*	string source="";
		sit = tField.find("source");
		if(sit == tField.end())
		{
		rMap.insert(map<string,string>::value_type("error","can't find source"));
		GenResult(output,output_space_size,rMap);
		return output_space_size;
		}
		source = sit->second;
		long source_id = atol(source.c_str());
		map<long,string>::iterator it;
		it = workModule->source->find(source_id);
		if(it == workModule->source->end())
		{
		rMap.insert(map<string,string>::value_type("error","source authen failed"));
		GenResult(output,output_space_size,rMap);
		return output_space_size;
		}*/

	set<pair<int,double> > feature_set;
	workModule->feature_manager->GenInstance(tField,feature_set);
	set<pair<int,double> >::iterator it;
	for(it = feature_set.begin();it != feature_set.end();it++)
	{
			cerr<<it->first<<":"<<it->second<<"\t";
	}
	cerr<<endl;
	double prob_estimates[2];
	do_predict(workModule,workData,feature_set,prob_estimates);
	int labels[2];
	get_labels(workModule->model_,labels);
	for(int j=0;j<workModule->model_->nr_class;j++)
	{
			char key[24],value[24];
			sprintf(value,"%f",prob_estimates[j]);
			sprintf(key,"%d",labels[j]);
			rMap.insert(map<string,string>::value_type(string(key),string(value)));
	}
	GenResult(output,output_space_size,rMap);
	return output_space_size;
}


