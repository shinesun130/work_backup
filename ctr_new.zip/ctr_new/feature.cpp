#include <feature.h>
#include "StringTool.h"

FeatureManager::FeatureManager()
{
}

FeatureManager::~FeatureManager()
{

}


//////////////////////////////////////////////////////////
//init function
bool FeatureManager::Init(const char* file)
{
	ifstream fin(file);
	if(!fin.is_open())
	{
		cerr<<"can't open file: "<<file<<endl;
		return false;
	}

	string line;
	string tname = "";
	map<string,FeatureNode>::iterator it;
	while(getline(fin,line))
	{
		if(line.size() < 1)
		  continue;
		if(line[0] == '@')
		{
			continue;
		}
		if(line[0] == '#')
		{
			vector<string> tvec=StringTool::SplitString(line,"\t");
			if(tvec.size() < 2)
			{
					cerr<<"feature conf file format error: "<<line<<endl;
					return -1;
			}
			string name = tvec[0].substr(1),type = tvec[1];
			string oper = "",args = "";
			if(tvec.size() == 3)
			{
					oper = tvec[2];
			}
			if(tvec.size() == 4){
					oper = tvec[2];
					args = tvec[3];
			}
#ifdef DEBUG
			cerr<<"name:"<<name<<"\t"
					<<"type:"<<type<<"\t"
					<<"oper:"<<oper<<"\t"
					<<"args:"<<args<<endl;
#endif
			tname = name;
			struct FeatureNode fnode;
			fnode.type = type;
			fnode.oper = oper;
			fnode.args = args;
			feature_map.insert(map<string,FeatureNode>::value_type(name,fnode));
		}
		else
		{
			it = feature_map.find(tname);
			if(it == feature_map.end())
			{
				cerr<<"format error: "<<line<<endl;
				return false;
			}
			else
			{
				string type = it->second.type;
				vector<string> tvec=StringTool::SplitString(line,"\t");
				if(tvec.size() < 2)
				{
					cerr<<"format error: "<<line<<endl;
					return false;
				}
				if(type == "bool" || type == "boolean") 
				{
					it->second.index = atoi(tvec[0].c_str());
				}
				if(type == "enum")
				{
					int index = atoi(tvec[0].c_str());
					it->second.mindex.insert(map<string,int>::value_type(tvec[1],index));
				}
			}
		}
	}
	fin.close();
#ifdef DEBUG
    map<string,FeatureNode>::iterator qit;
	for(qit = feature_map.begin();qit != feature_map.end();qit ++)
	{
			cerr<<"#"<<qit->first<<"#"<<endl;
	}
#endif
	return true;
}


bool FeatureManager::GenInstance(map<string,string>& fmap,set<pair<int,double> >& instance)
{
	if(fmap.size() < 1)
	{
		cerr<<"feature num is null"<<endl;
		return false;
	}

	instance.clear();
	map<string,string>::iterator it;
	map<string,FeatureNode>::iterator fit;
	for(it = fmap.begin();it != fmap.end();it++)
	{
		string feature_name = it->first;
		string feature_value = it->second;
		fit = feature_map.find(feature_name);
		if(fit != feature_map.end())
		{

			string type = fit->second.type;
			if(type == "bool")
			{
				int index = fit->second.index;
				if(feature_value != "0")
				{
					instance.insert(make_pair(index,1));
				}
			}
			if(type == "origin"){
					int index = fit->second.index;
					if(feature_value != "0")
					{
							double dvalue = atof(feature_value.c_str());
							instance.insert(make_pair(index,dvalue));
					}
			}
			if(type == "enum")
			{
					string oper = fit->second.oper;
					string args = fit->second.args;
					map<string,int>::iterator sit;
					if(oper != ""){
							string value = DoConvert(feature_value,oper,args);
							sit = fit->second.mindex.find(value);
							if(sit == fit->second.mindex.end()){
									sit = fit->second.mindex.find("_other_");
									if(sit == fit->second.mindex.end()){
											cerr<<"can't find feature: "<<feature_name<<endl;
									}else{
											int index = sit->second;
											instance.insert(make_pair(index,1));
									}
							}else{
									int index = sit->second;
									instance.insert(make_pair(index,1));
							}  
					}else{
							sit = fit->second.mindex.find(feature_value);
							if(sit == fit->second.mindex.end()){
									sit = fit->second.mindex.find("_other_");
									if(sit == fit->second.mindex.end()){
									cerr<<"can't find feature: "<<feature_name<<endl;
									}else{
											int index = sit->second; 
											instance.insert(make_pair(index,1));
									}
							}else{
									int index = sit->second;
									instance.insert(make_pair(index,1));
							}
					}
			}
		}
		else
		{
				cerr<<"can't find feature: "<<feature_name<<endl;
				continue;
		}
	}
	return true;
}

string FeatureManager::DoConvert(string param,string oper,string args){
		if(param == ""){
				return "_other_";
		}
		if(oper == "log10" || oper == "Log10"){
				long value = atol(param.c_str());
				double rvalue = log(value);
				int resvalue = (int)(rvalue+0.5);
				char res[1024];
				sprintf(res,"%d",resvalue);
				return string(res);
		}
}
