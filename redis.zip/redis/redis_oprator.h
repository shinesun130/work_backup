#include <string>
#include <vector>
#include "redispool.h"
using namespace std;

int zadd(const char* key,const char* value);

bool is_exist(const char* key);

int zrange(const char* key,vector<string>& res);

int expire(const char* key,int timeline);

int szremrangebyrank(const char * key,vector<string>& res);

int scard(const char* key);


