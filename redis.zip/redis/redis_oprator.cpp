#include "redis_oprator.h"

int zadd(const char* key,const char* value)
{
	redisReply *reply = NULL;
	reply = (redisReply*)RedisProxy::Instance()->Execute(key,"ZADD %s %d %s",key,0,value);
#ifdef DEBUG
	printf("%s",reply->str);
#endif
	if(reply == NULL)
	{
	  return -1;
	}
	freeReplyObject(reply);
	return 0;
}

bool is_exist(const char* key)
{
	redisReply *reply = NULL;
	reply = (redisReply*)RedisProxy::Instance()->Execute(key,"EXISTS %s",key);
	if(reply == NULL)
	{
		return false;
	} 
#ifdef DEBUG
	    printf("%s",reply->str);
#endif
	int ret = reply->integer;
	freeReplyObject(reply);
	if(ret == 1)
	  return true;
	return false;
}

int szremrangebyrank(const char * key,vector<string>& res)
{
	int tsize = res.size();
	if(tsize < 2)
	{
		return 0;
	}
	string tkey(key);
	int i = 0;
	for(i = 0;i < tsize;i++)
	{
		if(tkey >= res[i])
		  break;
	}
	if(i == 0 || i == tsize - 1)
	  return 0;
	redisReply *reply = NULL;
	reply = (redisReply*)RedisProxy::Instance()->Execute(key,"ZREMRANGEBYRANK  %s %d %d",key,0,i);
	if(reply == NULL)
	{                     
		return -1;                          
	}                                           
	freeReplyObject(reply);
	return 0;  
}

int scard(const char* key)
{
	redisReply *reply = NULL;
	reply = (redisReply*)RedisProxy::Instance()->Execute(key,"ZCARD %s",key);
	if(reply == NULL)
	{              
		return -1;                           
	}                                      
	int ret = reply->integer;
	freeReplyObject(reply);
	return ret;       
}

int zrange(const char* key,vector<string>& res)
{
	redisReply *reply = NULL;
	reply = (redisReply*)RedisProxy::Instance()->Execute(key,"ZRANGE  %s",key);
	if(reply == NULL)
	{
		return -1;
	}
	if (reply->type == REDIS_REPLY_ARRAY) {
		for (int j = 0; j < reply->elements; j++) {
			res.push_back(string(reply->element[j]->str));
		}
	}
	freeReplyObject(reply);
	return 0;
}

int expire(const char* key,int timeline)
{
	redisReply *reply = NULL;
	reply = (redisReply*)RedisProxy::Instance()->Execute(key,"EXPIRE  %s %d",key,timeline);
	if(reply == NULL)
	{
		return -1;
	}
	freeReplyObject(reply);
	return 0;
}

