#include "redispool.h"
using namespace std;

void RedisPool::Open(std::string strIp,int iPort,int iTimeout,int iSize)
{
	this->strIp = strIp;
	this->iPort = iPort;
	this->iTimeout = iTimeout;
	this->iConnectNums = iSize;
	iRealsize = 0;
	pthread_mutex_init(&oMutex,NULL);
	redisConn.clear();
	for (int i=0;i<this->iConnectNums;i++)
	{
		printf("connect ip=%s,port=%d,iNums=%d\n",strIp.c_str(),iPort,i);
		redisContext *pConn = CreateConnection();
		if (!pConn){
#ifdef DEBUG
			printf("create connection error.ip:%s,port:%d\n",strIp.c_str(),iPort);
#endif
			continue;
		}
		iRealsize++;
		redisConn.push_back(pConn);
	}
}

redisContext * RedisPool::CreateConnection()
{
	struct timeval timeout = { iTimeout/1000, (iTimeout - iTimeout/1000*1000)*1000 }; // 1.5 seconds
	redisContext *pRedisConn = NULL;
	pRedisConn = redisConnectWithTimeout(strIp.c_str(),iPort,timeout);
	if (pRedisConn && pRedisConn->err) 
	{
#ifdef DEBUG
		printf("open redis error, mabye redis server don't start,error=%s\n",pRedisConn->errstr);
#endif
		redisFree(pRedisConn);
		return NULL;
	}
	return pRedisConn;
}

redisContext *RedisPool::GetConnection()
{
	pthread_mutex_lock(&oMutex);
	if (redisConn.size() > 0)
	{
		redisContext *pConn = NULL;
		pConn = redisConn.back();
		redisConn.pop_back();
		pthread_mutex_unlock(&oMutex);
		return pConn;
	}
	else 
	{
		if (iRealsize < iConnectNums)
		{
			pthread_mutex_unlock(&oMutex);
			redisContext *pConn = CreateConnection();
			if (pConn)
			{
				pthread_mutex_lock(&oMutex);
				iRealsize++;
				pthread_mutex_unlock(&oMutex);
			}
			return  pConn;
		}
	}
	pthread_mutex_unlock(&oMutex);
	return NULL;
}



void RedisPool::Close()
{
	pthread_mutex_lock(&oMutex);
	for (size_t i = 0;i<redisConn.size();i++){
		redisFree(redisConn[i]);
	}
	pthread_mutex_unlock(&oMutex);
	pthread_mutex_destroy(&oMutex);
}

int RedisPool::ReConnect(redisContext *&pConn)
{
#ifdef DEBUG
	printf("reConnect redis server. %p\n",pConn);
#endif
	if (!pConn){
		return -1;
	}
	redisFree(pConn);
	pConn = CreateConnection();
	if (pConn == NULL)
	{
		pthread_mutex_lock(&oMutex);
		iRealsize--;
		pthread_mutex_unlock(&oMutex);
		return -1;
	}
	return 0;
}

void RedisPool::ReleaseConnection(redisContext *pConn)
{
	pthread_mutex_lock(&oMutex);
#ifdef DEBUG
	printf("ReleaseConnection conn=%p,curCount:%d\n",pConn,iRealsize);
#endif
	redisConn.push_back(pConn);
	pthread_mutex_unlock(&oMutex);
}

void RedisPool::TerminateConnection(redisContext* pConn)
{
	if (pConn){
		redisFree(pConn);
		pthread_mutex_lock(&oMutex);
		iRealsize--;
		pthread_mutex_unlock(&oMutex);
	}
}



//////////////////////////


static unsigned int BKDRHash(const char *str)
{
	unsigned int seed = 131; // 31 131 1313 13131 131313 etc..
	unsigned int hash = 0;

	while (*str)
	{
		hash = hash * seed + (*str++);
	}

	return (hash & 0x7FFFFFFF);
}


int RedisProxy::Open(const std::vector<RedisInfo>& redisInfo,int retry /* = 3 */){
	if (redisInfo.empty()){
		return -1;
	}
	vecPool.resize(redisInfo.size());
	retryNums = retry;
	for (size_t i=0;i<redisInfo.size();i++){
		RedisPool* pool = new RedisPool();
		pool->Open(redisInfo[i].Ip,redisInfo[i].port,redisInfo[i].timeout,redisInfo[i].poolCount);
		vecPool[i] = pool;
	}
	return 0;
}

void RedisProxy::Close(){
	for (size_t i=0;i<vecPool.size();i++){
		vecPool[i]->Close();
		delete vecPool[i];
	}
}

redisReply * RedisProxy::Execute(const std::string& key,const char *format, ...)
{
	if (vecPool.size() == 0){
		return NULL;
	}
	
	int hashIndex = BKDRHash(key.c_str()) % vecPool.size();
	RedisPool* redisPool = vecPool[hashIndex];


	redisContext * context = redisPool->GetConnection();
	if (context == NULL){
		return NULL;
	}
	
	redisReply *reply = NULL;

	if (context->err){
		int ret = redisPool->ReConnect(context);
		if(ret == -1)
		{
#ifdef DEBUG
			printf("reconnect redis server error,context=%p\n",context);
#endif
			//autoConn.NoReturn();
			return NULL;
		}
	}else{
		va_list ap;
		va_start(ap,format);
		reply = (redisReply*)redisvCommand(context,format,ap);
		va_end(ap);
#ifdef DEBUG
		printf("execute command=%s,reply=%p,context=%p,context->err=%d\n",format,reply,context,context->err);
#endif
		if (reply && reply->type == REDIS_REPLY_ERROR)
		{
			freeReplyObject(reply);
			reply = NULL;
		}
	}

	if (context->err == REDIS_ERR_IO || context->err == REDIS_ERR_EOF)//reconnect server connect lost
	{
		int iRet = redisPool->ReConnect(context);
		if(iRet == -1){
			printf("reconnect redis server error,context=%p\n",context);
			//autoConn.NoReturn();
			return NULL;
		}
#ifdef DEBUG
		printf("restart get connect command=%s,reply=%p,context=%p,context->err=%d\n",format,reply,context,context->err);
#endif
		if (context->err == 0)
		{
			if (reply)
			{
				freeReplyObject(reply);
				reply = NULL;
			}
			va_list ap;
			va_start(ap,format);
			reply = (redisReply*)redisvCommand(context,format,ap);
			va_end(ap);
		}
#ifdef DEBUG
		printf("restart execute command=%s,reply=%p,context=%p,context->err=%d\n",format,reply,context,context->err);
#endif
		if (reply && reply->type == REDIS_REPLY_ERROR)
		{
			freeReplyObject(reply);
			reply = NULL;
		}
	}
	
	if (context){
		redisPool->ReleaseConnection(context);
	}
	
	return reply;
}

