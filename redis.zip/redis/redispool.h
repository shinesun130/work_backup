#ifndef _REDIS_POOL_H
#define _REDIS_POOL_H
#include "hiredis.h"
#include <string>
#include <vector>
#include <deque>
class RedisPool
{
public:
	void Open(std::string strIp,int iPort,int iTimeout,int iSize);
	redisContext *CreateConnection();
	int ReConnect(redisContext *&pConn);
	redisContext *GetConnection();
	void ReleaseConnection(redisContext *pConn);
	void TerminateConnection(redisContext* conn);
	void Close();
private:
	pthread_mutex_t oMutex;
	int iConnectNums;//
	int iRealsize;//
	std::deque<redisContext*> redisConn;
	std::string strIp;
	int iPort;
	int iTimeout;//micro second
};

struct RedisInfo{
	std::string Ip;
	int port;
	int poolCount;
	int timeout;
};

class RedisProxy{
public:
	static RedisProxy* Instance(){
		static RedisProxy oProxy;
		return &oProxy;
	}
	int Open(const std::vector<RedisInfo>& redisInfo,int retryNums = 3);
	void Close();
	redisReply* Execute(const std::string& key,const char *format, ...);
private:
	redisReply* Executeone(redisContext * context,const char *format, va_list ap);
	int retryNums;
	std::vector<RedisPool*> vecPool;
};





#endif


