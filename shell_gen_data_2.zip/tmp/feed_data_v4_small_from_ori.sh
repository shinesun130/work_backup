#!/bin/bash

TABLE_NAME='feed_data_v4_small_2'

dt=$1

hadoop_root=/user/algorithm_weibo/warehouse
array[0]=mds_strategy_feed_bhv_click
array[1]=feature_offline_click
array[2]=mds_strategy_feed_user_catagory
# check if all tables related exist when dt=$dt
hadoop fs -test -e /user/feed_weibo/warehouse/feed_sample_json_final/dt=$dt
if [ $? -ne 0 ]; then
	echo "/user/feed_weibo/warehouse/feed_sample_json_final/dt=$dt does not exist"
	exit 1
fi
size=`hadoop fs -du -s /user/feed_weibo/warehouse/feed_sample_json_final/dt=$dt | awk '{print $1}'`
echo $size
if (( $size < 1000 )); then
	echo "/user/feed_weibo/warehouse/feed_sample_json_final/dt=$dt null"
	exit 1
fi
for var in ${array[@]}
do
	hadoop fs -test -e $hadoop_root/$var/dt=$dt
	if [ $? -ne 0 ]; then
		echo "$hadoop_root/$var/dt=$dt does not exist"
		exit 1
	fi
	size=`hadoop fs -du -s $hadoop_root/$var/dt=$dt | awk '{print $1}'`
	echo $size
        if (( $size < 1000 )); then
		echo "$hadoop_root/$var/dt=$dt null"	
		exit 1
	fi
done
# get the latest dt of fuusp before current dt
parts_fuusp=`hadoop fs -du warehouse/feature_offline_relation_fuuisspfans | awk '{if($1>1000){print $2}}' | awk -F"[=/]" '{print $4}'`
for var in ${parts_fuusp[@]}
do
	echo $var
	if (( $var < $dt )); then
		dt_fuusp=$var
	fi
done
echo dt_fuusp=$dt_fuusp
# get the latest dt of relation before current dt
parts_relation=`hadoop fs -du warehouse/feature_offline_relation_click | awk '{if($1>1000){print $2}}' | awk -F"[=/]" '{print $4}'`
for var in ${parts_relation[@]}
do
	echo $var
	if (( $var < $dt )); then
		dt_relation=$var
	fi
done
echo dt_relation=$dt_relation

sql="
add jar ./udf.jar;
create temporary function tag_match as 'com.weibo.mytest.ComputeTagMatch';
create temporary function cal_ar as 'com.weibo.mytest.CalActRate';
create temporary function cal_ar_v2 as 'com.weibo.mytest.CalActRate_v2';
create temporary function max_weight_tag as 'com.weibo.mytest.GetMaxWeightTag';
create temporary function replace_null as 'com.weibo.mytest.ReplaceNULL';
create temporary function keep_mid as 'com.weibo.mytest.KeepMid';

set hive.exec.compress.output=true;
set mapred.output.compress=true;
set mapred.output.compression.codec=org.apache.hadoop.io.compress.GzipCodec;
set io.compression.codecs=org.apache.hadoop.io.compress.GzipCodec;

insert overwrite table $TABLE_NAME partition(dt=$dt)

select 
	case when(fum_isfwd_l = '1') then 1
			when(fum_iscmt_l = '1') then 1
			when(fum_islk_l = '1') then 1
			else 0 end as label,
	fum_iscmt_l,
	fum_isfwd_l,
	fum_islk_l,
	c_expotime,
	fu_uid,
	replace_null(fu_age,'23') as fu_age,
	replace_null(fu_age_level_mining,'NULL') as fu_age_level_mining,
	fu_gender,
	replace_null(fu_week_ia_interval_equal_3hs,'0') as fu_week_ia_interval_equal_3hs,
	replace_null(fu_week_ia_interval_equal_6hs,'0') as fu_week_ia_interval_equal_6hs,
	replace_null(fu_week_ia_interval_equal_24hs,'0') as fu_week_ia_interval_equal_24hs,
	replace_null(fu_week_ia_interval_equal_72hs,'0') as fu_week_ia_interval_equal_72hs,
	max_weight_tag(fu_short_interest_tag_1st) as fu_short_interest_tag_1st,
	max_weight_tag(fu_short_interest_tag_2nd) as fu_short_interest_tag_2nd,
	max_weight_tag(fu_short_interest_tag_3rd) as fu_short_interest_tag_3rd,
	m_chour,
	m_sourceid,
	m_ad,
	m_is_toutiao,
	m_is_transmit,
	m_has_gif,
	m_has_link,
	m_has_pic,
	replace_null(m_has_pic_num, '0') as m_has_pic_num,
	m_has_video,
	m_has_video_miaopai,
	replace_null(m_has_card_num, '0') as m_has_card_num,
	replace_null(m_feed_expo_num_his, '0') as m_feed_expo_num_his,
	replace_null(m_feed_expo_num_hour, '0') as m_feed_expo_num_hour,
	replace_null(m_feed_expo_num_cur_hour, '0') as m_feed_expo_num_cur_hour,
	replace_null(m_fwd_num_his, '0') as m_fwd_num_his,
	replace_null(m_cmt_num_his, '0') as m_cmt_num_his,
	replace_null(m_lk_num_his, '0') as m_lk_num_his,
	replace_null(m_fwd_num_hour, '0') as m_fwd_num_hour,
	replace_null(m_cmt_num_hour, '0') as m_cmt_num_hour,
	replace_null(m_lk_num_hour, '0') as m_lk_num_hour,
	replace_null(m_fwd_num_cur_hour, '0') as m_fwd_num_cur_hour,
	replace_null(m_cmt_num_cur_hour, '0') as m_cmt_num_cur_hour,
	replace_null(m_lk_num_cur_hour, '0') as m_lk_num_cur_hour,
	cal_ar(m_fwd_num_his, m_feed_expo_num_his, 8, 400) as m_fwdr_his,
	cal_ar(m_cmt_num_his, m_feed_expo_num_his, 5, 666) as m_cmtr_his,
	cal_ar(m_lk_num_his, m_feed_expo_num_his, 40, 88) as m_lkr_his,
	cal_ar(COALESCE(m_fwd_num_his, 0) + COALESCE(m_cmt_num_his, 0) + COALESCE(m_lk_num_his, 0), m_feed_expo_num_his, 53, 60) as m_iar_his,
	cal_ar(m_fwd_num_hour, m_feed_expo_num_hour, 12, 266) as m_fwdr_hour,
	cal_ar(m_cmt_num_hour, m_feed_expo_num_hour, 10, 333) as m_cmtr_hour,
	cal_ar(m_lk_num_hour, m_feed_expo_num_hour, 40, 88) as m_lkr_hour,
	cal_ar(COALESCE(m_fwd_num_hour,0) + COALESCE(m_cmt_num_hour,0) + COALESCE(m_lk_num_hour,0), m_feed_expo_num_hour, 62, 53) as m_iar_hour,
	replace_null(m_hb_click_num_his, '0') as m_hb_click_num_his,
	replace_null(m_hb_click_num_hour, '0') as m_hb_click_num_hour,
	replace_null(m_hb_expo_num_his, '0') as m_hb_expo_num_his,
	replace_null(m_hb_expo_num_hour, '0') as m_hb_expo_num_hour,
	replace_null(m_hb_ia_num_his, '0') as m_hb_ia_num_his,
	replace_null(m_hb_ia_num_hour, '0') as m_hb_ia_num_hour,
	replace_null(m_hb_like_num_his, '0') as m_hb_like_num_his,
	max_weight_tag(m_content_keyword) as m_content_keyword,
	max_weight_tag(m_content_tag_1st) as m_content_tag_1st,
	max_weight_tag(m_content_tag_2nd) as m_content_tag_2nd,
	max_weight_tag(m_content_tag_3rd) as m_content_tag_3rd,
	m_u_uid,
	m_u_clevel,
	replace_null(m_u_attens_num, '0') as m_u_attens_num,
	replace_null(m_u_filtered_fans_num, '0') as m_u_filtered_fans_num,
	replace_null(m_u_tweets_num, '0') as m_u_tweets_num,
	replace_null(m_u_expo_num_month_fa, '0') as m_u_expo_num_month_fa,
	replace_null(m_u_fwd_num_month_fa, '0') as m_u_fwd_num_month_fa,
	replace_null(m_u_cmt_num_month_fa, '0') as m_u_cmt_num_month_fa,
	replace_null(m_u_lk_num_month_fa, '0') as m_u_lk_num_month_fa,
	replace_null(m_u_ia_num_month_fa, '0') as m_u_ia_num_month_fa,
	replace_null(m_u_expo_num_week, '0') as m_u_expo_num_week,
	replace_null(m_u_ia_num_week, '0') as m_u_ia_num_week,
	cal_ar(m_u_ia_num_week, m_u_expo_num_week, 53, 0) as m_u_iar_week,
	cal_ar(m_u_ia_num_month_fa,m_u_expo_num_month_fa, 53, 0) as m_u_iar_month,
    max_weight_tag(m_u_short_interest_tag_1st) as m_u_short_interest_tag_1st,
	COALESCE(fuu_is_fansboth, 0) as fuu_is_fansboth,
	replace_null(fuu_affinity, '0') as fuu_affinity,
	replace_null(fuu_ia_num_hour, '0') as fuu_ia_num_hour,
	replace_null(fuu_expo_num_week, '0') as fuu_expo_num_week,
	replace_null(fuu_ia_num_week, '0') as fuu_ia_num_week,
    case when(fuu_ia_num_week > fuu_expo_num_week) then 1 when(fuu_expo_num_week = 0) then NULL else fuu_ia_num_week / fuu_expo_num_week end as fuu_iar_week,
	replace_null(fuu_expo_num_month, '0') as fuu_expo_num_month,
	replace_null(fuu_fwd_num_month, '0') as fuu_fwd_num_month,
	replace_null(fuu_cmt_num_month, '0') as fuu_cmt_num_month,
	replace_null(fuu_lk_num_month, '0') as fuu_lk_num_month,
	replace_null(fuu_ia_num_month, '0') as fuu_ia_num_month,
   	case when(fuu_ia_num_month > fuu_expo_num_month) then 1 when(fuu_expo_num_month = 0) then NULL else fuu_ia_num_month / fuu_expo_num_month end as fuu_iar_month,
	tag_match(m_content_tag_1st, fu_short_interest_tag_1st) as fum_interest_tag1_match,
	tag_match(m_u_short_interest_tag_1st, fu_short_interest_tag_1st) as fuu_interest_similarity_calA_tag1,
	case when(m_ctime is not null and c_expotime is not null) then (c_expotime - m_ctime) / 60 else NULL end as mc_time_interval,
	cast(f.catagory as int) as fu_category,
	case when(fuu_is_spfans='1') then 1 else 0 end as fuu_is_spfans,
	replace_null(u_click_num_week, '0') as u_click_num_week,
	replace_null(u_click_num_month, '0') as u_click_num_month,
	case when(u_click_num_week > m_u_expo_num_week) then 1 else (u_click_num_week + 154) / (m_u_expo_num_week + 1309) end as u_clickr_week,
    case when(u_click_num_month > m_u_expo_num_month_fa) then 1 else (u_click_num_month + 660) / (m_u_expo_num_month_fa + 5610) end as u_clickr_month,
	replace_null(fuu_click_num_week, '0') as fuu_click_num_week,
	replace_null(fuu_click_num_month, '0') as fuu_click_num_month,
	replace_null(m_real_reading_time,'0') as m_real_reading_time,
	replace_null(networktype,'NULL') as networktype,
    replace_null(mobile_brand,'NULL') as mobile_brand
from
(
	select *
	from feed_sample_json_final
	where dt=$dt
) a
join
(
        select distinct b.fu_uid as fu_uid
        from
        (
                select
                        fu_uid
                from
                        feed_sample_json_final
                where dt=$dt and (fum_isfwd_l=1 or fum_iscmt_l=1 or fum_islk_l=1)
                group by fu_uid having count(*) > 0
        )b
    	join
        (
                select
                        fu_uid
                from
                        feed_sample_json_final
                where dt=$dt
                group by fu_uid, c_expotime having count(*) < 500
        )d
        on b.fu_uid=d.fu_uid
)h
on h.fu_uid=c.fu_uid
left join
(
       	select from_uid, to_mid, 1 as click
        from mds_strategy_feed_bhv_click_algorithm
        where dt=$dt
	group by from_uid, to_mid
) b
on a.m_mid=b.to_mid and a.fu_uid=b.from_uid
left join
(
	select fromuid, touid, fuu_is_spfans
	from feature_offline_relation_fuuisspfans
	where dt=$dt_fuusp
) c
on a.fu_uid=c.fromuid and a.m_u_uid=c.touid
left join
(
	select *
	from feature_offline_click
	where dt=$dt
) d
on a.m_u_uid=d.uid
left join
(
	select *
	from feature_offline_relation_click
	where dt=$dt_relation
) e
on a.fu_uid=e.from_uid and a.m_u_uid=e.to_uid
left join
(
	select uid, catagory
        from mds_strategy_feed_user_catagory
        where dt=$dt
) f
on a.fu_uid=f.uid  
left join
(
	select
		uid, networktype, mobile_brand, expo_time
	from
		mobile_info_zongheng
	where dt=$dt
) g
on a.fu_uid=g.uid and a.c_expotime=g.expo_time
join
(
                select sum(read_duration) as read_duration, mid as temp_itemid, uid as temp_uid
                from mds_strategy_feed_real_read
                where dt=$dt and read_duration is not null and read_duration > 100
                group by mid, uid
) i
on a.m_mid=i.temp_itemid and a.fu_uid=i.temp_uid
"

hive -e "${sql}"




