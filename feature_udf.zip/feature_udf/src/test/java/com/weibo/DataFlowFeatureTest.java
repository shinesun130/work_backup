package com.weibo;

import com.weibo.dataflow.ConfResolver;
import com.weibo.dataflow.DataFlowFeature;
import com.weibo.dataflow.feature.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import org.junit.*;
import org.junit.rules.ExpectedException;
import static junit.framework.Assert.*;

/**
 * Created by dejun.xiedj on 2017/6/1.
 */
public class DataFlowFeatureTest {
  @Rule
  public ExpectedException exception = ExpectedException.none();

  @Test
  public void testBoolean() {
    DataFlowFeature f = new Bool("col1", 1, 3, false, true);
    assertEquals(f.getType(), DataFlowFeature.FEATRUE_TYPE.BOOL);
    assertEquals("2:1", f.getResult("1.0"));
    assertEquals(1.0, f.getCurrentValue());
    assertEquals("1:1", f.getResult("0.0"));
    assertEquals(0.0, f.getCurrentValue());
    assertEquals("", f.getResult(null));
    assertEquals(null, f.getCurrentValue());
    assertEquals("", f.getResult("nan"));
    assertEquals(null, f.getCurrentValue());
  }

  @Test
  public void testDefault() {
    DataFlowFeature f = new Default("col1", 1, 1, false, true);
    assertEquals("1:1.0", f.getResult("1.0"));
    assertEquals(1.0, f.getCurrentValue());
    assertEquals("1:2.2", f.getResult("2.2"));
    assertEquals(2.2, f.getCurrentValue());
    assertEquals("", f.getResult("nan"));
    assertEquals(null, f.getCurrentValue());
  }
  
  @Test
  public void testLog() {
    DataFlowFeature f = new Log("col1", 1, 3, false, true);
    assertEquals("1:1", f.getResult("1.0"));
    assertEquals(1.0, f.getCurrentValue());
    assertEquals("2:1", f.getResult("10.0"));
    assertEquals(10.0, f.getCurrentValue());
    assertEquals("3:1", f.getResult("100000.0"));
    assertEquals(100000.0, f.getCurrentValue());
    assertEquals("", f.getResult("nan"));
    assertEquals(null, f.getCurrentValue());
  }


  @Test
  public void testPickCat() {
    DataFlowFeature f = new PickCat("col1", 1, 3, Arrays.asList("m", "f"), false, true);
    assertEquals(f.getType(), DataFlowFeature.FEATRUE_TYPE.PICK_CAT);
    assertEquals("1:1", f.getResult("m"));
    assertEquals("m", f.getCurrentValue());
    assertEquals("2:1", f.getResult("f"));
    assertEquals("f", f.getCurrentValue());
    assertEquals("3:1", f.getResult("other"));
    assertEquals("other", f.getCurrentValue());
    assertEquals("3:1", f.getResult(null));
    assertEquals(null, f.getCurrentValue());

    DataFlowFeature f2 = new PickCat("col1", 1, 3, Arrays.asList("m", "f", "x", "y"), false, true);
    assertEquals("3:1", f2.getResult("x"));
    assertEquals("3:1", f2.getResult("xx"));
  }

  @Test
  public void testPiecewise() {
    Map<String, ConfResolver.Range> conf = new HashMap<String, ConfResolver.Range>();
    conf.put("0", new ConfResolver.Range(0.0, 0.02));
    Piecewise f = new Piecewise("col1", 1, 2, conf, false, true);
    assertEquals(f.getType(), DataFlowFeature.FEATRUE_TYPE.ENUM_PIECEWISE);
    assertEquals("2:1", f.getResult("-1"));
    assertEquals(-1.0, f.getCurrentValue());
    assertEquals("1:1", f.getResult("0.01"));
    assertEquals(0.01, f.getCurrentValue());
    assertEquals("2:1", f.getResult("1"));
    assertEquals(1.0, f.getCurrentValue());

    conf.put("1", new ConfResolver.Range(0.02, 0.04));
    Piecewise f2 = new Piecewise("col1", 1, 2, conf, false, true);
    assertEquals("2:1", f.getResult("0.03"));
  }

  @Test
  public void testCompound() {
    DataFlowFeature f1 = new Bool("col1", 1, 3, false, true);
    DataFlowFeature f2 = new Log("col2", 4, 7, false, true);
    DataFlowFeature f3 = new Compound("f3", 8, 21, Arrays.asList(f1, f2), true);
    //exception.expect(RuntimeException.class);
    //f3.getResult(null);
    f1.getResult("0.0");
    f2.getResult("1");
    assertEquals("8:1", f3.getResult(null));
    f2.getResult("10");
    assertEquals("9:1", f3.getResult(null));
    f1.getResult("1.0");
    assertEquals("13:1", f3.getResult(null));
    //DataFlowFeature f4 = new Compound("f3", 8, 12, Arrays.asList(f1, f2), false); // expect exception
    DataFlowFeature f4 = new Compound("f3", 8, 12, Arrays.asList(f1, f2), true);
    assertEquals("12:1", f4.getResult(null));
  }

  @Test
  public void testDescartes() {
    DataFlowFeature f1 = new Bool("col1", 1, 3, false, true);
    DataFlowFeature f2 = new Log("col2", 4, 7, false, true);
    DataFlowFeature f3 = new Default("col3", 8, 8, false, true);
    DataFlowFeature f4 = new Descartes("f3", 9, 22, Arrays.asList(f1, f2), null, true);
    DataFlowFeature f5 = new Descartes("f3", 9, 22, Arrays.asList(f1, f2), f3, true);
    //exception.expect(RuntimeException.class);
    //f4.getResult(null);
    f1.getResult("0.0");
    f2.getResult("1");
    //exception.expect(RuntimeException.class);
    //f5.getResult(null);
    f3.getResult("9.9");
    assertEquals("9:1", f4.getResult(null));
    assertEquals("9:9.9", f5.getResult(null));
    f2.getResult("10");
    assertEquals("10:1", f4.getResult(null));
    assertEquals("10:9.9", f5.getResult(null));
    f1.getResult("1.0");
    assertEquals("14:1", f4.getResult(null));
    assertEquals("14:9.9", f5.getResult(null));
    DataFlowFeature f6 = new Descartes("f3", 9, 13, Arrays.asList(f1, f2), f3, true);
    assertEquals("13:9.9", f6.getResult(null));
  }
}
