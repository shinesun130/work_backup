package com.weibo;

import com.weibo.dataflow.ConfResolver;
import com.weibo.dataflow.DataFlowFeature;
import com.weibo.dataflow.feature.*;

import java.io.*;
import java.util.Arrays;
import java.util.Map;

import org.junit.*;
import org.junit.rules.ExpectedException;

import static junit.framework.Assert.*;

/**
 * Created by dejun.xiedj on 2017/6/1.
 */
public class ConfResolverTest {
  @Test
  public void testResolve() throws FileNotFoundException {
    assert (getClass().getResourceAsStream("/example_feature.conf") != null);

    BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/example_feature.conf")));
    Map<String, DataFlowFeature> name2Features = ConfResolver.resolve(br);
    assertEquals("Index 5 in PICK_CAT born[1, 8] corresponding original value is 80s.", IndexResolver.resolveIndex(name2Features, 5));
    //assertEquals("Index 10 in PICK_CAT gender[9, 11] corresponding original value is f.", IndexResolver.resolveIndex(name2Features, 10));
    assertEquals("Index 12 in DEFAULT first_level_inte_weight[12, 12] corresponding original value is unknown.", IndexResolver.resolveIndex(name2Features, 12));
    assertEquals("Index 24 in PICK_CAT pic_weight[15, 24] corresponding original value is other.", IndexResolver.resolveIndex(name2Features, 24));
    assertEquals("Index 25 in BOOL article_weight[25, 27] corresponding original value is 0.0.", IndexResolver.resolveIndex(name2Features, 25));
    assertEquals("Index 36 in ENUM_LOG10 ret_num[34, 41] corresponding original value is in [pow(10, 2) 100.0, pow(10, 3) 1000.0].", IndexResolver.resolveIndex(name2Features, 36));
    assertEquals("Index 135 in ENUM_LOG10 inter_count[133, 140] corresponding original value is in [pow(10, 2) 100.0, pow(10, 3) 1000.0].", IndexResolver.resolveIndex(name2Features, 135));
    assertEquals("Index 149 in ENUM_PIECEWISE click_rate[148, 149] corresponding original value is not in range [(0.0,0.1)].", IndexResolver.resolveIndex(name2Features, 149));
    assertEquals("Index 228 in COMPOUND comp1[228, 421] sub feature's corresponding original values are:\n" +
        "  Index 1 in PICK_CAT born[1, 8] corresponding original value is 40s.\n" +
        "  Index 9 in PICK_CAT gender[9, 11] corresponding original value is m.\n" +
        "  Index 133 in ENUM_LOG10 inter_count[133, 140] corresponding original value is in [pow(10, 0) 1.0, pow(10, 1) 10.0].\n", IndexResolver.resolveIndex(name2Features, 228));
    assertEquals("Index 334 in COMPOUND comp1[228, 421] sub feature's corresponding original values are:\n" +
        "  Index 5 in PICK_CAT born[1, 8] corresponding original value is 80s.\n" +
        "  Index 10 in PICK_CAT gender[9, 11] corresponding original value is f.\n" +
        "  Index 135 in ENUM_LOG10 inter_count[133, 140] corresponding original value is in [pow(10, 2) 100.0, pow(10, 3) 1000.0].\n", IndexResolver.resolveIndex(name2Features, 334));
    assertEquals("Index 3486713 in DESCARTES descartes1[3486713, 3486778]\n" +
        "Sub feature's corresponding original value is:\n" +
        "  Index 1 in PICK_CAT born[1, 8] corresponding original value is 40s.\n" +
        "  Index 133 in ENUM_LOG10 inter_count[133, 140] corresponding original value is in [pow(10, 0) 1.0, pow(10, 1) 10.0].\n", IndexResolver.resolveIndex(name2Features, 3486713));
    assertEquals("Index 3486747 in DESCARTES descartes1[3486713, 3486778]\n" +
        "Sub feature's corresponding original value is:\n" +
        "  Index 5 in PICK_CAT born[1, 8] corresponding original value is 80s.\n" +
        "  Index 135 in ENUM_LOG10 inter_count[133, 140] corresponding original value is in [pow(10, 2) 100.0, pow(10, 3) 1000.0].\n", IndexResolver.resolveIndex(name2Features, 3486747));
    assertEquals("Index 3486813 in DESCARTES descartes2[3486779, 3486844]\n" +
        "Sub feature's corresponding original value is:\n" +
        "  Index 5 in PICK_CAT born[1, 8] corresponding original value is 80s.\n" +
        "  Index 135 in ENUM_LOG10 inter_count[133, 140] corresponding original value is in [pow(10, 2) 100.0, pow(10, 3) 1000.0].\n" +
        "Coeff feature's corresponding original value could not calculate from global index.", IndexResolver.resolveIndex(name2Features, 3486813));
  }

  @Test
  public void testResolve2() throws FileNotFoundException {
    assert (getClass().getResourceAsStream("/example_feature2.conf") != null);
    BufferedReader br = new BufferedReader(new InputStreamReader(getClass().getResourceAsStream("/example_feature2.conf")));
    //Map<String, DataFlowFeature> name2Features = ConfResolver.resolve(br);
    //assertEquals(true, name2Features.containsKey("d2"));
  }
}
