package com.weibo;

import com.aliyun.odps.udf.UDTF;
import com.aliyun.odps.udf.annotation.Resolve;
import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDFException;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.List;


//"born_index,gender_index,time_born_gender_action_list->all_group_msg,hour_group_msg"
@Resolve({"bigint,bigint,string->string,string"})
public class ExtractGroupClick extends UDTF {
  @Override
  public void process(Object[] args) throws UDFException {
    int born_index = ((Long) args[0]).intValue();
    int gender_index = ((Long) args[1]).intValue();
    String time_born_gender_action_list = (String) args[2];
    String[] time_born_genders = time_born_gender_action_list.trim().replaceAll("^[\\[|\\]| ]+", "").replaceAll("[\\[|\\]| ]+$", "").split(",");
    if (time_born_genders.length == 180) {
      int all_group_index = born_index * 3 * 6 + gender_index * 6;
      int hour_group_index = all_group_index + 5 * 3 * 6;
      forward(Arrays.toString(Arrays.copyOfRange(time_born_genders, all_group_index, all_group_index + 6)),
          Arrays.toString(Arrays.copyOfRange(time_born_genders, hour_group_index, hour_group_index + 6)));

    } else if (time_born_genders.length == 255) {
      int all_group_index = born_index * 3 * 7 + gender_index * 7;
      int hour_group_index = all_group_index + 6 * 3 * 7;
      forward(Arrays.toString(Arrays.copyOfRange(time_born_genders, all_group_index, all_group_index + 7)),
          Arrays.toString(Arrays.copyOfRange(time_born_genders, hour_group_index, hour_group_index + 7)));
    } else {
      forward("[]", "[]");
    }
  }
}
