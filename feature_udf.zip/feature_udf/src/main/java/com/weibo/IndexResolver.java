package com.weibo;

import com.weibo.dataflow.ConfResolver;
import com.weibo.dataflow.DataFlowFeature;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Map;

/**
 * Created by dejun.xiedj on 2017/6/2.
 */
public class IndexResolver {
  public static void main(String[] args) throws FileNotFoundException {
    if (args.length != 2) {
      System.out.println("Usage: IndexResolver <feature_conf_file> <index>");
      return;
    }
    BufferedReader br = new BufferedReader(new FileReader(args[0]));
    Map<String, DataFlowFeature> name2Features = ConfResolver.resolve(br);
    System.out.println(resolveIndex(name2Features, Long.parseLong(args[1])));
  }

  public static String resolveIndex(Map<String, DataFlowFeature> name2Features, long idx) {
    for(DataFlowFeature f : name2Features.values()) {
      if (f.isVirtual()) {
        continue;
      }
      if (idx >= f.getStartIdx() && idx <= f.getEndIdx()) {
        return f.getFeatureConf(idx);
      }
    }
    return "Invalid supplied index for feature conf.";
  }
}
