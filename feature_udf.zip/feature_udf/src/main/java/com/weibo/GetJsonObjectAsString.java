package com.weibo;

import com.aliyun.odps.udf.UDF;
import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDFException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import java.util.Map;

public class GetJsonObjectAsString extends UDF {

  public final String evaluate(String json, String key) {
    JsonParser jsonParser = new JsonParser();
    JsonObject jsonObject = (JsonObject) jsonParser.parse(json);
    JsonElement jsonElement = jsonObject.get(key);
    if (jsonElement != null) {
      return jsonElement.getAsString();
    } else {
      return null;
    }
  }
}
