package com.weibo;

import com.aliyun.odps.udf.UDTF;
import com.aliyun.odps.udf.annotation.Resolve;
import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDFException;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.google.gson.JsonParser;
import com.google.gson.JsonObject;
import com.google.gson.JsonElement;
import com.google.gson.JsonArray;

import java.util.Arrays;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.List;


//"extend->total_read_num,inter_act_num,inter_act_num_recent,hot_ret_num,hot_cmt_num,hot_like_num,hot_ret_num_recent,hot_cmt_num_recent,hot_like_num_recent,time_born_gender_action_list,recommend_base_level"
@Resolve({"string->string,string,string,string,string,string,string,string,string,string,string"})
public class ExtractExpoMsg extends UDTF {
  @Override
  public void process(Object[] args) throws UDFException {
    String extend = (String) args[0];
    JsonObject extend_info = getJsonObject(extend);
    // try {
    JsonObject exposure_info = getJsonObject(getJsonString(extend_info, "exposure_interaction_rate", "{}"));
    JsonObject recommend_info = getJsonObject(getJsonString(extend_info, "recommend_sources", "{}"));
    // catch ()
    int total_read_num = getJsonInt(extend_info, "total_read_num", 0);
    int inter_act_num = getJsonInt(exposure_info, "inter_act_num", 0);
    int inter_act_num_recent = getJsonInt(exposure_info, "inter_act_num_recent", 0);
    int hot_ret_num = getJsonInt(exposure_info, "hot_ret_num", 0);
    int hot_cmt_num = getJsonInt(exposure_info, "hot_cmt_num", 0);
    int hot_like_num = getJsonInt(exposure_info, "hot_like_num", 0);
    int hot_ret_num_recent = getJsonInt(exposure_info, "hot_ret_num_recent", 0);
    int hot_cmt_num_recent = getJsonInt(exposure_info, "hot_cmt_num_recent", 0);
    int hot_like_num_recent = getJsonInt(exposure_info, "hot_like_num_recent", 0);
    JsonArray time_born_gender_action_list = getJsonArray(exposure_info, "time_born_gender_action_list", new JsonArray());
    int recommend_base_level = getJsonInt(recommend_info, "recommend_source_detail", -1);
    forward(String.valueOf(total_read_num),
        String.valueOf(inter_act_num),
        String.valueOf(inter_act_num_recent),
        String.valueOf(hot_ret_num),
        String.valueOf(hot_cmt_num),
        String.valueOf(hot_like_num),
        String.valueOf(hot_ret_num_recent),
        String.valueOf(hot_cmt_num_recent),
        String.valueOf(hot_like_num_recent),
        time_born_gender_action_list.toString(),
        String.valueOf(recommend_base_level));
  }

  public static JsonObject getJsonObject(String json) {
    JsonParser jsonParser = new JsonParser();
    return (JsonObject) jsonParser.parse(json);
  }

  public static String getJsonString(JsonObject jo, String key, String defaultValue) {
    JsonElement jsonElement = jo.get(key);
    if (jsonElement != null) {
      return jsonElement.getAsString();
    } else {
      return defaultValue;
    }
  }

  public static int getJsonInt(JsonObject jo, String key, int defaultValue) {
    JsonElement jsonElement = jo.get(key);
    if (jsonElement != null) {
      return jsonElement.getAsInt();
    } else {
      return defaultValue;
    }
  }

  public static JsonArray getJsonArray(JsonObject jo, String key, JsonArray defaultValue) {
    JsonElement jsonElement = jo.get(key);
    if (jsonElement != null) {
      return jsonElement.getAsJsonArray();
    } else {
      return defaultValue;
    }
  }
}
