package com.weibo.dataflow.feature;

import com.weibo.dataflow.DataFlowFeature;
import com.weibo.dataflow.ConfUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public class Compound extends DataFlowFeature {
  List<DataFlowFeature> subFeatures;

  public Compound(String name, long startIdx, long endIdx, List<DataFlowFeature> subFeatures, boolean hasOther) {
    super(FEATRUE_TYPE.COMPOUND, name, startIdx, endIdx, false, hasOther);
    this.subFeatures = subFeatures;
  }

  public String getResult(String useless) {
    currentIdx = 0;
    for (DataFlowFeature feature : subFeatures) {
      if (feature.getCurrentIdx() == -1) {
        throw new RuntimeException("Failed to resolve compound feature " + name + " because sub feature " + feature.getName() + " has not be resolved.");
      }
      currentIdx = currentIdx * feature.getCount() + (feature.getCurrentIdx() - feature.getStartIdx());
    }
    currentIdx += getStartIdx();
    if (currentIdx > getEndIdx()) {
      if (hasOther) {
        currentIdx = getEndIdx();
      } else {
        throw new RuntimeException("Local index " + currentIdx
            + " is bigger than " + getEndIdx()
            + ", but hasOther is false, feature name: " + getName());
      }
    }
    StringBuilder sb = new StringBuilder();
    return sb.append(currentIdx).append(":1").toString();
  }

  public Object getCurrentValue() {
    throw new RuntimeException("not implement");
  }

  public String getFeatureConf(long idx) {
    assert (idx >= startIdx && idx <= endIdx);
    List<String> subFeatureConf = new ArrayList<String>();
    long originalIdx = idx;
    idx -= getStartIdx();
    for (int i = subFeatures.size() - 1; i >= 0; --i) {
      DataFlowFeature feature = subFeatures.get(i);
      long currentIdx = idx % feature.getCount();
      subFeatureConf.add(feature.getFeatureConf(currentIdx + feature.getStartIdx()));
      idx = idx / feature.getCount();
    }
    String result = (isVirtual ? "Local" : "") + "Index " + originalIdx + " in " + getType() + " " + getName()
        + "[" + getStartIdx() + ", " + getEndIdx() + "]"
        + " sub feature's corresponding original values are:\n";
    for (int i = subFeatureConf.size() - 1; i >= 0; --i) {
      result += "  " + subFeatureConf.get(i) + "\n";
    }
    return result;
  }
}
