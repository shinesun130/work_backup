package com.weibo.dataflow.feature;

import com.weibo.dataflow.DataFlowFeature;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public class Descartes extends DataFlowFeature {
  List<DataFlowFeature> subFeatures;
  DataFlowFeature coeff;

  public Descartes(String name, long startIdx, long endIdx, List<DataFlowFeature> subFeatures, DataFlowFeature coeff, boolean hasOther) {
    super(FEATRUE_TYPE.DESCARTES, name, startIdx, endIdx, false, hasOther);
    this.subFeatures = subFeatures;
    this.coeff = coeff;
  }

  public String getResult(String useless) {
    currentIdx = 0;
    for (DataFlowFeature feature : subFeatures) {
      if (feature.getCurrentIdx() == -1) {
        throw new RuntimeException("Failed to resolve compound feature " + name + " because sub feature " + feature.getName() + " has not be resolved.");
      }
      currentIdx = currentIdx * feature.getCount() + (feature.getCurrentIdx() - feature.getStartIdx());
    }
    currentIdx += getStartIdx();
    if (currentIdx > getEndIdx()) {
      if (hasOther) {
        currentIdx = getEndIdx();
      } else {
        throw new RuntimeException("Local index " + currentIdx
            + " is bigger than " + getEndIdx()
            + ", but hasOther is false, feature name: " + getName());
      }
    }
    StringBuilder sb = new StringBuilder();
    sb.append(currentIdx);
    if (coeff == null) {
      sb.append(":1");
    } else {
      if (coeff.getCurrentIdx() == -1) {
        throw new RuntimeException("Failed to resolve compound feature " + name + " because sub feature " + coeff.getName() + " has not be resolved.");
      }
      sb.append(":").append(coeff.getCurrentValue());
    }
    return sb.toString();
  }

  public Object getCurrentValue() {
    throw new RuntimeException("not implement");
  }

  public String getFeatureConf(long idx) {
    assert (idx >= startIdx && idx <= endIdx);
    List<String> subFeatureConf = new ArrayList<String>();
    long originalIdx = idx;
    idx -= getStartIdx();
    for (int i = subFeatures.size() - 1; i >= 0; --i) {
      DataFlowFeature feature = subFeatures.get(i);
      long currentIdx = idx % feature.getCount();
      subFeatureConf.add(feature.getFeatureConf(currentIdx + feature.getStartIdx()));
      idx = idx / feature.getCount();
    }
    String result = "Index " + originalIdx + " in " + getType() + " " + getName()
        + "[" + getStartIdx() + ", " + getEndIdx() + "]\n"
        + "Sub feature's corresponding original value is:\n";
    for (int i = subFeatureConf.size() - 1; i >= 0; --i) {
      result += "  " + subFeatureConf.get(i) + "\n";
    }
    if (coeff != null) {
      result += "Coeff feature's corresponding original value could not calculate from global index.";
    }
    return result;
  }
}
