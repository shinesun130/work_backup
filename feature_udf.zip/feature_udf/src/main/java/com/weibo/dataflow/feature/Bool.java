package com.weibo.dataflow.feature;

import com.weibo.dataflow.ConfUtil;
import com.weibo.dataflow.DataFlowFeature;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public class Bool extends DataFlowFeature {
  private List<Boolean> values = new ArrayList<Boolean>();
  Double currentValue;

  public Bool(String name, long startIdx, long endIdx, boolean isVirtual, boolean hasOther) {
    super(FEATRUE_TYPE.BOOL, name, startIdx, endIdx, isVirtual, hasOther);
    assert (endIdx - startIdx == 2);
    values.add(false);
    values.add(true);
  }

  public String getResult(String str) {
    Double val = ConfUtil.checkDoubleOrFloat(str);
    if (val == null) {
      currentValue = null;
      return "";
    }
    StringBuilder sb = new StringBuilder();
    return sb.append(getIdx(val)).append(":1").toString();
  }

  public Object getCurrentValue() {
    return currentValue;
  }

  public String getFeatureConf(long idx) {
    assert (idx >= startIdx && idx <= endIdx);
    String result = (isVirtual ? "Local " : "") + "Index " + idx + " in " + getType() + " " + getName()
        + "[" + getStartIdx() + ", " + getEndIdx() + "]"
        + " corresponding original value is ";
    if (idx - startIdx == 0) {
      result += "0.0";
    } else if (idx - startIdx == 1) {
      result += "1.0";
    } else {
      result += "other";
    }
    result += ".";
    return result;
  }

  private long getIdx(Double val) {
    if (currentValue != null && currentValue.equals(val)) {
      return currentIdx;
    }
    currentValue = val;
    Boolean b = Math.abs(1 - val) < 0.000001;
    boolean match = false;
    for (int i = 0; i < values.size(); ++i) {
      if (values.get(i).equals(b)) {
        currentIdx = i + startIdx;
        match = true;
        break;
      }
    }
    assert(match);
    return currentIdx;
  }
}
