package com.weibo.dataflow;

import com.google.gson.GsonBuilder;
import com.weibo.dataflow.feature.*;
import com.aliyun.odps.udf.ExecutionContext;

import java.io.*;
import java.util.*;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


public class ConfResolver {
  public static class Range {
    private Double start;
    private Double end;

    public Range(Double start, Double end) {
      this.start = start;
      this.end = end;
    }

    public String toString() {
      return "(" + start + "," + end + ")";
    }

    public Double getStart() {
      return start;
    }

    public Double getEnd() {
      return end;
    }
  };

  private static Map<String, DataFlowFeature> name2Feature = new LinkedHashMap<String, DataFlowFeature>();
  private static Gson gson = new GsonBuilder().create();

  public static Map<String, DataFlowFeature> resolve(String resource, ExecutionContext ctx) {
    try {
      InputStream is = ctx.readResourceFileAsStream(resource);
      BufferedReader br = new BufferedReader(new InputStreamReader(is));
      return resolve(br);
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
  }

  public static Map<String, DataFlowFeature> resolve(BufferedReader resourceReader) {
    try {
      boolean pre = false;
      long indexStart = Long.MAX_VALUE;
      long indexEnd = Long.MIN_VALUE;
      String featureConfStr = null;
      String idxConfStr = null;

      String s = null;
      while (true) {
        s = resourceReader.readLine();

        if (s != null && (s.startsWith("@") || s.equals(""))) continue;

        if (s == null || s.startsWith("#")) {
          if (pre) {
            DataFlowFeature f = createFeature(featureConfStr.substring(1), idxConfStr);
            if (name2Feature.get(f.getName()) != null) {
              assert (false);
            }
            name2Feature.put(f.getName(), f);
          }
          if (s == null) break;
          pre = true;
          featureConfStr = s;
          indexStart = Long.MAX_VALUE;
          indexEnd = Long.MIN_VALUE;
        } else if (s.startsWith("%")) {
          idxConfStr = s.substring(1);
        }
      }
      resourceReader.close();
    } catch (NumberFormatException e) {
      throw new RuntimeException(e);
    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    } catch (IOException e) {
      throw new RuntimeException(e);
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
    return name2Feature;
  }

  private static DataFlowFeature createFeature(String featureConfStr, String idxConfStr) {

    assert (featureConfStr != null);
    boolean isVirutal = false;
    if (featureConfStr.startsWith("#")) {
      isVirutal = true;
      featureConfStr = featureConfStr.substring(1);
    }

    //Map<String, String> featureConf = getMap(featureConfStr);
    Map<String, String> idxConf = getMap(idxConfStr);
    long indexStart = isVirutal ? 0 : Long.parseLong(idxConf.get("globalStart"));
    long indexEnd = indexStart + Long.parseLong(idxConf.get("localEnd")) - Long.parseLong(idxConf.get("localStart"));
    boolean hasOther = idxConf.containsKey("hasOther") && idxConf.get("hasOther").equals("1");
    if (hasOther) {
      ++indexEnd;
    }
    assert (indexStart <= indexEnd);
    assert (!idxConf.containsKey("orderEnumList") || (idxConf.get("orderEnumList").equals("") || idxConf.get("orderEnumList").equals("[]")));
    //assert (!idxConf.containsKey("hasOther"));

    String[] parts = featureConfStr.split("\\t+");
    List<String> str = new ArrayList<String>();
    for (int i = 0; i < parts.length; ++i) {
      String t = parts[i].trim();
      if (t.length() > 0) str.add(t);
    }

    assert (str.size() >= 2);
    String type = str.get(1).toLowerCase();
    if (type.equals("enum")) {
      assert (str.size() >= 3);
      String method = str.get(2).toLowerCase();
      if (method.equals("pickcat")) {
        assert (str.size() == 4);
        String[] values = getMap(str.get(3)).get("category").split(",");
        return new PickCat(str.get(0), indexStart, indexEnd, Arrays.asList(values), isVirutal, hasOther);
      } else if  (method.equals("log10")) {
        assert (str.size() == 3);
        return new Log(str.get(0), indexStart, indexEnd, isVirutal, hasOther);
      } else if (method.equals("piecewise")) {
        assert (str.size() == 4);
        Map<String, String> pieceWiseConf = getMap(str.get(3));
        Map<String, Range> values = ConfUtil.splitPiecewise(pieceWiseConf);
        return new Piecewise(str.get(0), indexStart, indexEnd, values, isVirutal, hasOther);
      } else if (method.equals("descartes")) {
        assert (str.size() == 4);
        Map<String, String> featureConf = getMap(str.get(3));
        List<String> subFeatureNames = ConfUtil.splitCompound(featureConf.get("features"));
        DataFlowFeature coeff = null;
        if (featureConf.containsKey("coeff")) {
          coeff = name2Feature.get(featureConf.get("coeff"));
        }
        return new Descartes(str.get(0), indexStart, indexEnd, getFeatures(str.get(0), subFeatureNames), coeff, hasOther);
      } else {
        throw new RuntimeException("Unsupported enum method: " + str.get(2).toLowerCase() + ".");
      }
    } else if (type.equals("default")) {
      assert (str.size() == 2);
      return new Default(str.get(0), indexStart, indexEnd, isVirutal, hasOther);
    } else if (type.equals("bool")) {
      assert (str.size() == 2);
      return new Bool(str.get(0), indexStart, indexEnd, isVirutal, hasOther);
    } else if (type.equals("compound")) {
      assert (str.size() == 3);
      List<String> subFeatureNames = ConfUtil.splitCompound(getMap(str.get(2)).get("features"));
      return new Compound(str.get(0), indexStart, indexEnd, getFeatures(str.get(0), subFeatureNames), hasOther);
    } else {
      throw new RuntimeException("Unsupported feature type: " + type + ".");
    }
  }

  private static List<DataFlowFeature> getFeatures(String name, List<String> names) {
    List<DataFlowFeature> features = new ArrayList<>();
    for (String featureName : names) {
      DataFlowFeature subFeature = name2Feature.get(featureName);
      if (subFeature == null) {
        throw new RuntimeException("Could get sub feature: " + featureName + " for " + name);
      }
      features.add(subFeature);
    }
    return features;
  }

  private static Map<String, String> getMap(String jsonStr) {
    return gson.fromJson(jsonStr, new TypeToken<Map<String, String>>(){}.getType());
  }
}
