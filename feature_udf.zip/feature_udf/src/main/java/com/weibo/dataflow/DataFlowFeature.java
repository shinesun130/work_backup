package com.weibo.dataflow;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public abstract class DataFlowFeature {
  public enum FEATRUE_TYPE {
    ENUM_LOG10,
    ENUM_PIECEWISE,
    PICK_CAT,
    COMPOUND,
    BOOL,
    DEFAULT,
    DESCARTES,
  }

  protected FEATRUE_TYPE type;
  protected String name;
  // global start index
  protected long startIdx;
  // global end index
  protected long endIdx;
  // cache current index for compound or descartes feature using
  protected long currentIdx = -1;
  protected boolean isVirtual = false;
  protected boolean hasOther = false;

  public DataFlowFeature(FEATRUE_TYPE type, String name, long startIdx, long endIdx, boolean isVirtual, boolean hasOther) {
    this.type = type;
    this.name = name;
    this.startIdx = startIdx;
    this.endIdx = endIdx;
    this.isVirtual = isVirtual;
    this.hasOther = hasOther;
  }

  public FEATRUE_TYPE getType() {
    return type;
  }
  public String getName() {
    return name;
  }

  public long getCount() {
    return endIdx - startIdx + 1;
  }

  public long getCurrentIdx() {
    return currentIdx;
  }

  public long getStartIdx() {
    return startIdx;
  }

  public long getEndIdx() {
    return endIdx;
  }

  public boolean isVirtual() {
    return isVirtual;
  }

  /**
   * get kv feature result from orignal value
   * @param val orignal value
   * @return kv result, key is index, value is 1 or orignal value (feature default)
   */
  public abstract String getResult(String val);

  /**
   * get current value for feature DESCARTES' coeff
   * @return current value
   */
  public abstract Object getCurrentValue();

  /**
   * get feature conf from global index for developer to investigate
   * @param idx global index
   * @return feature conf
   */
  public abstract String getFeatureConf(long idx);
}
