package com.weibo.dataflow;

import com.aliyun.odps.udf.ExecutionContext;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConfUtil {

  public static Double checkDoubleOrFloat(String s) {
    Double d = null;
    if (s != null) {
      try {
        d = Double.valueOf(s);
      } catch (NumberFormatException e) {
        // ignore
      }
    }
    return d;
  }

  public static List<String> read(String resource, ExecutionContext ctx) {
    List<String> aList = new ArrayList<String>();
    try {
      InputStream in = ctx.readResourceFileAsStream(resource);
      BufferedReader br = new BufferedReader(new InputStreamReader(in));

      String s = null;
      while ((s = br.readLine()) != null) {
        s = s.trim();
        aList.add(s);
      }
      br.close();
    } catch (IOException e) {
      throw new RuntimeException(e);
    }
    return aList;
  }

  public static Map<String, ConfResolver.Range> splitPiecewise(Map<String, String> conf) {
    Map<String, ConfResolver.Range> ret = new HashMap<String, ConfResolver.Range>();
    for (Map.Entry<String, String> entry : conf.entrySet()) {
      String[] parts = entry.getValue().split(",");
      assert (parts.length == 2);
      ret.put(entry.getKey(), new ConfResolver.Range(Double.valueOf(parts[0].trim()), Double.valueOf(parts[1].trim())));
    }
    return ret;
  }

  public static List<String> splitCompound(String s) {
    List<String> alist = new ArrayList<String>();
    s = s.trim();
    String[] parts = s.split(",");
    for (int i = 0; i < parts.length; ++i) {
      alist.add(parts[i].trim());
    }
    return alist;
  }
}
