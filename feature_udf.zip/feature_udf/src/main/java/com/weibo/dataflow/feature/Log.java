package com.weibo.dataflow.feature;

import com.weibo.dataflow.DataFlowFeature;
import com.weibo.dataflow.ConfUtil;

import java.util.List;
import java.util.ArrayList;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public class Log extends DataFlowFeature {
  private List<Long> values = new ArrayList<Long>();
  private Double currentValue;

  public Log(String name, long startIdx, long endIdx, boolean isVirtual, boolean hasOther) {
    super(FEATRUE_TYPE.ENUM_LOG10, name, startIdx, endIdx, isVirtual, hasOther);
    for (long i = 0; i <= endIdx - startIdx - (hasOther ? 1 : 0); ++i) {
      values.add(i);
    }
  }

  public String getResult(String str) {
    Double val = ConfUtil.checkDoubleOrFloat(str);
    if (val == null) {
      currentValue = null;
      return "";
    }
    StringBuilder sb = new StringBuilder();
    return sb.append(getIdx(val)).append(":1").toString();
  }

  public Object getCurrentValue() {
    return currentValue;
  }

  public String getFeatureConf(long idx) {
    assert (idx >= startIdx && idx <= endIdx);
    String result = (isVirtual ? "Local " : "") + "Index " + idx + " in " + getType() + " " + getName()
        + "[" + getStartIdx() + ", " + getEndIdx() + "]"
        + " corresponding original value is ";
    if (idx == endIdx) {
      result += "not in [pow(10, " + values.get(0) + ") " + Math.pow(10, values.get(0)) + ", "
          + "pow(10, " + values.get((int)(endIdx - startIdx)) + ") " + Math.pow(10, values.get((int)(endIdx - startIdx))) + "]";
    } else {
      result += "in [pow(10, " + values.get((int)(idx - startIdx)) + ") " + Math.pow(10, values.get((int)(idx - startIdx)))
          + ", pow(10, " + values.get((int)(idx - startIdx + 1)) + ") " + Math.pow(10, values.get((int)(idx - startIdx + 1))) + "]";
    }
    result += ".";
    return result;
  }

  private long getIdx(Double val) {
    if (currentValue != null && currentValue.equals(val)) {
      return currentIdx;
    }
    currentValue = val;
    int k = (int) Math.floor(Math.log10(val));
    boolean match = false;
    for (int i = 0; i < values.size(); ++i) {
      if (values.get(i) - k == 0) {
        currentIdx = i + startIdx;
        match = true;
      }
    }
    if (!match) {
      if (hasOther) {
        currentIdx = endIdx;
      } else {
        throw new RuntimeException("No matched value found when getting feature index, name: " + getName()
            + ", value: " + val);
      }
    }
    return currentIdx;
  }
}