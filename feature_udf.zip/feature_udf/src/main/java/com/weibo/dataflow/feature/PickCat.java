package com.weibo.dataflow.feature;

import com.weibo.dataflow.DataFlowFeature;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public class PickCat extends DataFlowFeature {
  private List<String> values;
  private Map<String, Long> valueMap;
  private String currentValue;

  public PickCat(String name, long startIdx, long endIdx, List<String> values, boolean isVirtual, boolean hasOther) {
    super(FEATRUE_TYPE.PICK_CAT, name, startIdx, endIdx, isVirtual, hasOther);
    this.values = values;
    valueMap = new HashMap<String, Long>(values.size());
    for (int i = 0; i < values.size(); ++i) {
      valueMap.put(values.get(i), Long.valueOf(i));
    }
  }

  public String getResult(String str) {
    StringBuilder sb = new StringBuilder();
    return sb.append(getIdx(str)).append(":1").toString();
  }

  public Object getCurrentValue() {
    return currentValue;
  }

  public String getFeatureConf(long idx) {
    assert (idx >= startIdx && idx <= endIdx);
    String result = (isVirtual ? "Local " : "") + "Index " + idx + " in " + getType() + " " + getName()
        + "[" + getStartIdx() + ", " + getEndIdx() + "]"
        + " corresponding original value is ";
    if (idx == endIdx) {
      result += "other";
    } else {
      result += values.get((int)(idx - startIdx));
    }
    result += ".";
    return result;
  }

  private long getIdx(String val) {
    if (currentValue != null && currentValue.equals(val)) {
      return currentIdx;
    }
    currentValue = val;
    boolean match = false;
    long validValuesLen = endIdx - startIdx + (hasOther ? 0 : 1);
    assert (validValuesLen <= values.size());
    Long idx = valueMap.get(val != null ? val : "NULL");
    if (idx != null && idx < validValuesLen) {
      currentIdx = idx.longValue() + startIdx;
      match = true;
    }
    if (!match) {
      if (hasOther) {
        currentIdx = endIdx;
      } else {
        throw new RuntimeException("No matched value found when getting feature index, name: " + getName()
            + ", value: " + val);
      }
    }
    return currentIdx;
  }
}
