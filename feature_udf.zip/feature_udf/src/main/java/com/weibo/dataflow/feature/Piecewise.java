package com.weibo.dataflow.feature;

import com.weibo.dataflow.ConfResolver;
import com.weibo.dataflow.DataFlowFeature;
import com.weibo.dataflow.ConfUtil;

import java.util.List;
import java.util.Map;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public class Piecewise extends DataFlowFeature {
  private Map<String, ConfResolver.Range> values;
  private Double currentValue;

  public Piecewise(String name, long startIdx, long endIdx, Map<String, ConfResolver.Range> values, boolean isVirtual, boolean hasOther) {
    super(FEATRUE_TYPE.ENUM_PIECEWISE, name, startIdx, endIdx, isVirtual, hasOther);
    this.values = values;
  }

  public String getResult(String str) {
    Double val = ConfUtil.checkDoubleOrFloat(str);
    if (val == null) {
      currentValue = null;
      return "";
    }
    StringBuilder sb = new StringBuilder();
    return sb.append(getIdx(val)).append(":1").toString();
  }

  public Object getCurrentValue() {
    return currentValue;
  }

  public String getFeatureConf(long idx) {
    assert (idx >= startIdx && idx <= endIdx);
    String result = (isVirtual ? "Local " : "") + "Index " + idx + " in " + getType() + " " + getName()
        + "[" + getStartIdx() + ", " + getEndIdx() + "]"
        + " corresponding original value is ";
    if (idx == endIdx) {
      result += "not in range " + values.values().toString();
    } else {
      String localIdxStr = String.valueOf(idx - startIdx);
      result += "in range [" + values.get(localIdxStr).getStart()
          + ", " + values.get(localIdxStr).getEnd() + "]";
    }
    result += ".";
    return result;
  }

  private long getIdx(Double val) {
    if (currentValue != null && currentValue.equals(val)) {
      return currentIdx;
    }
    currentValue = val;
    boolean match = false;
    long validValuesLen = endIdx - startIdx + (hasOther ? 0 : 1);
    assert (validValuesLen <= values.size());
    for (int i = 0; i < validValuesLen; ++i) {
      if (values.get(String.valueOf(i)).getStart() <= val && val <= values.get(String.valueOf(i)).getEnd()) {
        currentIdx = i + startIdx;
        match = true;
      }
    }
    if (!match) {
      if (hasOther) {
        currentIdx = endIdx;
      } else {
        throw new RuntimeException("No matched value found when getting feature index, name: " + getName()
            + ", value: " + val);
      }
    }
    return currentIdx;
  }
}
