package com.weibo.dataflow.feature;

import com.weibo.dataflow.DataFlowFeature;
import com.weibo.dataflow.ConfUtil;

/**
 * Created by dejun.xiedj on 2017/5/24.
 */
public class Default extends DataFlowFeature {
  private Double currentValue;

  public Default(String name, long startIdx, long endIdx, boolean isVirtual, boolean hasOther) {
    super(FEATRUE_TYPE.DEFAULT, name, startIdx, endIdx, isVirtual, hasOther);
    assert (startIdx == endIdx);
  }

  public String getResult(String str) {
    Double val = ConfUtil.checkDoubleOrFloat(str);
    currentValue = val;
    if (val == null) {
      return "";
    }
    currentIdx = endIdx;
    StringBuilder sb = new StringBuilder();
    return sb.append(currentIdx).append(":").append(val).toString();
  }

  public Object getCurrentValue() {
    return currentValue;
  }

  public String getFeatureConf(long idx) {
    assert (idx >= startIdx && idx <= endIdx);
    String result = (isVirtual ? "Local " : "") + "Index " + idx + " in " + getType() + " " + getName()
        + "[" + getStartIdx() + ", " + getEndIdx() + "]"
        + " corresponding original value is unknown.";
    return result;
  }
}
