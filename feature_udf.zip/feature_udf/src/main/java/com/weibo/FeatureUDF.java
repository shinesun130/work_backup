package com.weibo;

import com.weibo.dataflow.*;

import com.aliyun.odps.udf.UDF;
import com.aliyun.odps.udf.ExecutionContext;
import com.aliyun.odps.udf.UDFException;

import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

public class FeatureUDF extends UDF {
  private static Map<String, DataFlowFeature> name2Feature;

  public void setup(ExecutionContext ctx) throws UDFException {
    name2Feature = ConfResolver.resolve("hot_weibo_large_scale_compute_data_set.feature.conf", ctx);
  }

  public final String evaluate(String keys, String... values) {
    if (keys == null) return null;
    String[] realKeys = keys.trim().split(",");
    if (realKeys == null || values == null || realKeys.length != values.length) return null;
    Map<String, String> name2Value = new HashMap<>();
    for (int i = 0; i < realKeys.length; ++i) {
      name2Value.put(realKeys[i].trim(), values[i]);
    }

    StringBuilder sb = new StringBuilder();
    String delimiter = "";
    for (Map.Entry<String, DataFlowFeature> entry : name2Feature.entrySet()) {
      String name = entry.getKey();
      DataFlowFeature feature = entry.getValue();
      String result;
      if (feature.getType() == DataFlowFeature.FEATRUE_TYPE.COMPOUND ||
          feature.getType() == DataFlowFeature.FEATRUE_TYPE.DESCARTES) {
        result = feature.getResult(null);
      } else {
        result = feature.getResult(name2Value.get(name));
      }
      if (feature.isVirtual()) {
        continue;
      }
      if (!"".equals(result)) {
        sb.append(delimiter);
        sb.append(result);
        delimiter = " ";
      }
    }
    return sb.toString();
  }

}
