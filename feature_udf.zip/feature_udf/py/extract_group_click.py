#_*_ coding:utf8 _*_
import os
import sys 
sys.path.append('.')
import time
import math
import random

def getDateTimeStamp(date_str, date_format = None):
	if date_format is not None:
		timeArray = time.strptime(date_str, date_format)
		timeStamp = int(time.mktime(timeArray))
		return timeStamp
	else:
		if len(date_str) == 8:
			return getDateTimeStamp(date_str, "%Y%m%d")
		elif len(date_str) == 10:
			return getDateTimeStamp(date_str, "%Y%m%d%H")
		else:
			return int(time.time())

def detectLike(duration, is_click):
	duration = float(duration) / 1000
	is_click = float(is_click)
	if is_click == 1 :
		#if duration > 1.5:
		if duration > 0.5:
			return 1
	else:
		#if duration > 1.5 and duration < 3:
		#if duration > 1.5 and duration < 5:
		if duration > 0.5 and duration < 7:
			return 0

		#if duration >= 3 and duration < 7 and (
		#	int(pic_num) + int(article_num) + int(video_num) + \
		#			int(obj_num) + int(long_pic_num) + int(gif_num) > 0):
		#	return 0

	return -1

def change2Dict(tags):
	global white_ability_tags
	tag_dict = {}
	type_dict = {}
	if '1042' not in tags:
		return tag_dict, type_dict
	for tag_info in tags.split(','):
		tag, weight = tag_info.rsplit('@',1)
		#if 'abilityTag' in tag and tag not in white_ability_tags:
		#	continue
		tag_dict[tag] = float(weight)
		tag_type = getObjType(tag)
		if tag_type not in type_dict:
			type_dict[tag_type] = set()
		type_dict[tag_type].add(tag)
	return tag_dict, type_dict

def detectInterType(keys1, keys2, inter_keys, max_weight):
	total = 4
	i = 0
	keys1_len = len(keys1)
	keys2_len = len(keys2)
	inter_len = len(inter_keys)
	if max_weight > 90:
		return 0
	if max_weight > 80:
		return 0.1
	if max_weight > 70:
		return 0.3
	if max_weight > 60:
		return 0.4
	if max_weight > 40:
		return 0.5
	if len(set(keys1.keys()) & set(keys2.keys())) > 0 and len(inter_keys) < 1:
		return 1.0
	return 1.0
	if keys1_len < 1:
		i = total - 1
	elif keys2_len < 1:
		i = total - 2
	elif inter_len < 1:
		i = total - 3
	elif inter_len < keys2_len:
		i = total - 4
	else:
		i = total - 4
	return gen_feature_list(total, i)

def getObjType(obj_id):
	obj_type = obj_id.split('1042015:',1)[-1].rsplit('_',1)[0]
	return obj_type

def detectInterWeight(tags1, tags2, default_weight=None):
	tags1_dict, tags1_type = change2Dict(tags1)
	tags2_dict, tags2_type = change2Dict(tags2)
	max_weight = 0
	inter_weight = 0
	inter_tags = set(tags1_dict.keys()) & set(tags2_dict.keys())
	for tag in inter_tags:
		tag_weight = default_weight
		if tag_weight is None:
			tag_weight = tags2_dict[tag]
		tmp_weight = tags1_dict[tag] * tag_weight
		if tmp_weight > inter_weight:
			inter_weight = tmp_weight
		if tags1_dict[tag] > max_weight:
			max_weight = tags1_dict[tag]
	inter_type = detectInterType(tags1_type, tags2_type, inter_tags, max_weight)
	return inter_weight, inter_type, max_weight

def isNewsCat(tags, news_cats):
	tags_dict, tags_type = change2Dict(tags)
	return len( set(tags_dict.keys()) & news_cats ) > 0

def detectInterStrong(max_weight):
	if max_weight >= 95:
		return 1.0
	if max_weight >= 90:
		return 0.9
	if max_weight >= 85:
		return 0.8
	if max_weight >= 80:
		return 0.7
	if max_weight >= 75:
		return 0.6
	if max_weight >= 70:
		return 0.5
	if max_weight >= 65:
		return 0.4
	if max_weight >= 60:
		return 0.3
	return 0

def detectTimeEffect(dt, hour, created_at):
	action_time = getDateTimeStamp('%s%s' % (dt, hour))
	created_at = int(created_at)
	inter_time = action_time - created_at
	if inter_time < 0:
		inter_time = 0
	return inter_time/3600

def detectUserCLevel(user_c_level):
	c_level = 6
	if user_c_level.startswith('C'):
		c_level = int(user_c_level.strip('C'))
	return c_level

def gen_feature_list(total_len, target_index, is_sort=False, desc=False):
	f = [0] * total_len
	if not is_sort:
		f[target_index] = 1
	elif desc:
		f[target_index: ] = [ 1 ] * (total_len - target_index)
	else:
		f[0: target_index+1] = [1] * (target_index + 1)
	return f

def discNum(num, thres=[]): 
	i = -1
	dimens_num = len(thres)
	for k, thre in enumerate(thres):
		if num >= thre:
			i = dimens_num - k - 1
			break
	return i

def discFansCount(fans_count, is_sort=False):
	fanscount = int(fans_count)
	thres = [ \
				30000000, 10000000, 5000000,\
				3000000, 1000000, 500000, \
				300000, 100000, 50000, 
				10000, 5000, 1000, \
				500, 0 ]
	total = len(thres) + 1
	i = discNum(fanscount, thres)

	return discFeature(total, i, is_sort, False)

def getFansIndex(fans_count):
	fanscount = int(fans_count)
	thres = [ \
				30000000, 10000000, 5000000,\
				3000000, 1000000, 500000, \
				300000, 100000, 50000, 
				10000, 5000, 1000, \
				500, 0 ]
	total = len(thres) + 1
	i = discNum(fanscount, thres)

	if i > total - 2:
		i = total - 2
	if i < 0:
		i = total - 1

	return i

def getFansWeight(fanscount):
	fanscount = int(fanscount)
	if fanscount > 30000000:
		return 1
	if fanscount > 10000000:
		return 0.9
	if fanscount > 5000000:
		return 0.8
	if fanscount > 3000000:
		return 0.7
	if fanscount > 1000000:
		return 0.6
	if fanscount > 500000:
		return 0.5
	if fanscount > 300000:
		return 0.4
	if fanscount > 100000:
		return 0.3
	if fanscount > 50000:
		return 0.2
	if fanscount > 10000:
		return 0.1
	return 0.0

def discFriendsCount(friends_count):
	friendscount = int(friends_count)
	thres = [ 1500, 1000, 500, 300, 100, 50, 0 ] 
	total = len(thres) + 1
	i = discNum(friendscount, thres)
	return discFeature(total, i)

def discTextLen(text_len, is_sort=False):
	textlen = float(text_len)/3
	#thres = [ 120, 80, 45, 30, 10, 7, 0 ]
	thres = [ 120, 80, 45, 7, 0 ]
	total = len(thres) + 1
	i = discNum(textlen, thres)
	return discFeature(total, i, is_sort, False)

def discEngNum(eng_num):
	eng_num = int(eng_num)
	thres = [ 20, 10, 3, 0 ]
	total = len(thres) + 1
	i = discNum(eng_num, thres)
	return discFeature(total, i)

def discEffectNum(effect_num, is_sort=False, is_news_cat=False, l_inter_obj_weight=1):
	thres = [72, 48, 24, 16, 0]
	total = len(thres) + 1
	i = discNum(effect_num, thres)
	e_features = [0] * 2
	if l_inter_obj_weight > 0:
		e_features[0] = discFeature(total, i, is_sort, True)
	else:
		e_features[0] = discFeature(total, i, is_sort, True)
	return e_features

def discUserWeight(c_level, verified_type):
	verified_type = int(verified_type)
	if c_level in [1]:
		if verified_type in [ 1, 3 ]:
			return 0.9
		else:
			return 0.8
	if c_level in [ 2 ]:
		if verified_type in [ 1, 3 ]:
			return 0.7
		else:
			return 0.6
	if c_level in [ 3 ]:
		if verified_type in [ 1, 3 ]:
			return 0.5
		else:
			return 0.4
	return 0.3

def discVerifiedType(verified_type):
	verified_type = int(verified_type)
	if verified_type in [ 0 ]:
		return 0.5
	if verified_type in [ 1, 3 ]:
		return 0.3
	return 0.1

def getEffectNumIndex(effect_num):
	thres = [48, 36, 24, 16, 12, 8, 4, 0]
	total = len(thres) + 1
	i = discNum(effect_num, thres)
	if i > total - 2:
		i = total - 2
	if i < 0:
		i = total - 1
	return i

def getEffectWeight(effect_num):
	if effect_num < 4:
		return 0.9
	if effect_num < 8:
		return 0.8
	if effect_num < 12:
		return 0.7
	if effect_num < 16:
		return 0.6
	if effect_num < 24:
		return 0.5
	if effect_num < 36:
		return 0.4
	if effect_num < 48:
		return 0.3
	return 0.2

def discInterCount(inter_count, is_sort=False, desc=False ):
	try:
		inter_count = float(inter_count)
	except:
		inter_count = -1
	thres = [ 1000000, 500000, 200000, \
				100000, 50000, 10000, \
				5000, 3000, 1000, \
				500, 100, 50, 0 ]
	total = len(thres) + 1
	i = discNum(inter_count, thres)
	return discFeature(total, i, is_sort, desc, False)

def getInterCountIndex(inter_count):
	try:
		inter_count = float(inter_count)
	except:
		inter_count = -1
	thres = [ 1000000, 500000, 200000, \
				100000, 50000, 10000, \
				5000, 3000, 1000, \
				500, 100, 50, 0 ]
	total = len(thres) + 1
	i = discNum(inter_count, thres)
	if i > total - 2:
		i = total - 2
	if i < 0:
		i = total - 1
	return i

def discInterRate(inter_count):
	try:
		inter_count = float(inter_count)
	except:
		inter_count = -1
	thres = [ 1000000, 500000, 200000, \
				100000, 50000, 10000, \
				5000, 3000, 1000, \
				500, 100, 50, 0 ]
	total = len(thres) + 1
	i = discNum(inter_count, thres)
	return discFeature(total, i )

def discFeature(total, n, is_sort=False, desc=False, is_normalization=True):
	i = int(n)
	if i > total - 2:
		i = total - 2
	if i < 0:
		i = total - 1
		if is_sort and is_normalization:
			if desc:
				i = total - 2
			else:
				i = 0
	if is_normalization:
		return float(i)/(total -2)
	else:
		return gen_feature_list(total, i, False, desc)

def discFeatureIndex(total, n):
	i = int(n)
	if i > total - 2:
		i = total - 2
	if i < 0:
		i = total - 1
	return i

def gen_features(feature_list):
	disc_features = []
	for feature in feature_list:
		if isinstance(feature, list):
			disc_features.extend(feature)
		else:
			disc_features.append(feature)
	return '\t'.join(map(str, disc_features))

def detectTimeRound(hour, begin_time=0, end_time=23):
	hour = int(hour)
	if hour >= begin_time and hour <= end_time:
		return True
	else:
		return False

def loadStarPersons(star_person_file):
	stars = {}
	for line in file(star_person_file):
		infos = line.strip().split('\t')
		if len(infos) < 3:
			sys.stderr.write('format error: %s\n' % line.strip())
			continue
		uid, obj_id, name = infos[0:3]
		stars[uid] = ('1042015:tagCategory_050@95', '%s@95' % obj_id)
	return stars

def appendStarTag(content_category, content_tag, content_obj, uid, stars):
	if uid in stars:
		a_cate, a_obj = stars[uid]
		if len(content_category) < 1:
			sys.stderr.write('append: %s\n' % uid)
			content_category = a_cate
		else:
			content_category += ',%s' % a_cate
		if len(content_obj) < 1:
			content_obj = a_obj
		else:
			content_obj += ',%s' % a_obj
		
	return content_category, content_tag, content_obj

def discActiveNum(ret_num, cmt_num, like_num):
	ret_num = float(ret_num)
	cmt_num = float(cmt_num)
	like_num = float(like_num)
	high_active_per = 2.0
	active_per = 1.0
	normal_active_per = 1/3.0
	inactive_per = 1/6.0
	bad_active_per = 1/9.0

	total = 6
	i = 0
	active_num = min(cmt_num, like_num)
	if active_num > ret_num * high_active_per:
		i = total - 1
	if active_num > ret_num * active_per:
		i = total - 2
	if active_num > ret_num * normal_active_per:
		i = total - 3
	elif active_num > ret_num * inactive_per:
		i = total - 4
	elif active_num > ret_num * bad_active_per:
		i = total - 5
	else:
		i = total - 6
	
	return gen_feature_list(total, i)

def genClickRate(expo, click):
	try:
		expo = float(expo)
	except:
		expo = 0.0
	
	try:
		click = float(click)
	except:
		click = 0.0
	
	rate = (click + 10)/(expo + 157)
	return max(2 * rate - 0.05, 0)

def getRepeatNum(is_click, inter_cat_weight, cmt_num):
	global high_negagive_index
	global corpus_repeats
	inter_index = getInterCountIndex(cmt_num)
	rep_num = 1
	is_click = int(is_click)
	repeat_info = corpus_repeats.get(inter_index, (1,1))
	rep_num = int(repeat_info[is_click])
	if is_click == 0 and inter_index >= 5:
		high_negagive_index += 1
		if high_negagive_index % 5 == 0:
			rep_num /= 3
	return rep_num

def calHotWeight(hot, l_inter_category_type=0, effect_num=0):
	hot = float(hot)
	min_hot = min(15000, 1+hot)
	#return (1/(1+math.exp(-0.0005*min_hot))-0.5)*2
	hot_weight = 0.0
	if min_hot <= 10:
		hot_weight = 0.03 * min_hot
	elif min_hot <= 30:
		hot_weight = 0.30 +(0.0453 * math.log(min_hot) - 0.1046)
	elif min_hot <= 300:
		hot_weight = 0.35 + (-1E-06 * min_hot * min_hot + 0.0012 * min_hot - 0.0324)
	elif min_hot <= 1100:
		hot_weight = 0.55 + (0.0003 * min_hot - 0.075)
	elif min_hot <= 3000:
		hot_weight = 0.75 + (-3E-08 * min_hot * min_hot + 0.0002 * min_hot - 0.1924)
	elif min_hot <= 5000:
		hot_weight = 0.90 + (5E-05 * min_hot - 0.15)
	else:
		hot_weight = 1.00 + (1E-05 * min_hot - 0.05)
	
	hot_weight /= 1.1

	#thres = [72, 48, 24, 0]
	thres = [0]
	i = discNum(effect_num, thres)

	c_features = [0] * 2 * len(thres)
	if l_inter_category_type < 0.55:
		c_features[0 + i] = hot_weight
	else:
		c_features[len(thres) + i] = hot_weight
	return c_features

def calClickRate(click_rate, article_weight, video_weight, obj_weight):
	rates = [0] * 2
	if float(article_weight) + float(obj_weight) > 0:
		rates[0] = click_rate
	else:
		rates[0] = click_rate
	return rates

def getLongArticleInterCount(inter_count):
	inter_count = int(inter_count)
	min_hot = min(100000, 1+inter_count)
	hot_weight = 0.0
	if min_hot <= 1000:
		hot_weight = 0.05 * min_hot
	elif min_hot <= 10000:
		hot_weight = 1E-06 * min_hot * min_hot + 0.0151 * min_hot + 46.461
	elif min_hot <= 50000:
		hot_weight = 123.48 * math.log(min_hot) - 832.03
	else:
		hot_weight = 0.01 * min_hot
	return hot_weight

def getWhiteAbilityTags(white_ability_tag_file):
	white_ability_tags = set()
	for line in file(white_ability_tag_file):
		line = line.strip()
		if line.startswith('1042'):
			white_ability_tags.add(line)
	return white_ability_tags

def getNewsCats(news_cat_file):
	news_cats = set()
	for line in file(news_cat_file):
		infos = line.strip().split('\t')	
		if len(infos) != 2:
			sys.stderr.write('format error: line[%s] file[%s]\n' % (\
											line.strip(), news_cat_file))
			continue
		cat_name, cat_id = infos
		news_cats.add(cat_id)
	return news_cats

def disMatchInteWeight(weight):
	m_features = [0] * 4
	if weight >= 0.8:
		m_features[0] = 1
	elif weight >= 0.6:
		m_features[1] = 1
	elif weight >= 0.4:
		m_features[2] = 1
	else:
		m_features[3] = 1
	return m_features

def test():
	print discInterCount(131280)
	print discEffectNum(24)
	print discTextLen(90)
	print discFeature(3, 1)
	print discFeature(4, 1)
	print discFeature(5, 1)
	print discFeature(6, 1)
	print discFeature(8, 1)
	print discFeature(10, 1)
	print discFeature(11,1)
	print discEngNum(13)
	print discFansCount(12345)
	print discFriendsCount(1234)
	print discFeature(3, 4)

def get_born_index( born ):
	if born == 'all':
		return 5
	if born == '70s':
		return 0
	elif born == '80s':
		return 1
	elif born == '90s':
		return 2
	elif born == '00s':
		return 3
	else:
		return 4

def get_gender_index( gender ):
	if gender == 'm':
		return 0
	elif gender == 'f':
		return 1
	else:
		return 2

def get_group_click( born, gender, time_born_gender_action_list ): 
	time_born_genders = time_born_gender_action_list.strip().strip('[ ]').split(',')
	born_index = get_born_index( born )
	gender_index = get_gender_index( gender )
	if len( time_born_genders ) == 180:
		all_group_index = born_index * 3 * 6 + gender_index * 6
		hour_group_index = all_group_index + 5 * 3 * 6
		return time_born_genders[all_group_index:all_group_index+6], \
						time_born_genders[hour_group_index:hour_group_index+6]
	elif len( time_born_genders ) == 255:
		all_group_index = born_index * 3 * 7 + gender_index * 7
		hour_group_index = all_group_index + 6 * 3 * 7
		return time_born_genders[all_group_index:all_group_index+7], \
						time_born_genders[hour_group_index:hour_group_index+7]
	return [], []
	

if __name__ == '__main__':
	i = 0
	inte = 0.3
	for line in sys.stdin:
		if 'None' in line:
			continue
		infos = line.strip().split('\t')
		if len(infos) < 37:
			sys.stderr.write('format error: %s\n' % line.strip())
			continue

		is_click, actions, isautoplay, mid, duration, uid, born, gender, area_id, \
				user_tags, doc_tags, author_id, expo_time, network_type, \
				recommend_source, recommend_base_level, category, \
				first_level_inte_type, second_level_inte_type, \
				third_level_inte_type, effect_weight, pic_weight, \
				article_weight, video_weight, obj_weight, user_weight, \
				ret_num, cmt_num, like_num, \
				ret_num_recent, cmt_num_recent, like_num_recent, \
				total_read_num, expose_num, act_num, inter_act_num, \
				expose_num_recent, act_num_recent,  inter_act_num_recent, \
				hot_ret_num, hot_cmt_num, hot_like_num, \
				hot_ret_num_recent, hot_cmt_num_recent, hot_like_num_recent,\
				article_read_num, miaopai_view_num, time_born_gender_action_list, extend, \
				dt, hour, born, gender = infos 

		if gender == '1':
			gender = 'm'
		elif gender == '2':
			gender = 'f'

		all_group_msg, hour_group_msg = get_group_click( born, gender, time_born_gender_action_list ) 
		print '\t'.join(map(str, [ is_click, actions, isautoplay, \
				mid, duration, uid, born, gender, area_id, \
				user_tags, doc_tags, author_id, expo_time, network_type,\
				recommend_source, recommend_base_level, category, \
				first_level_inte_type, second_level_inte_type, \
				third_level_inte_type, effect_weight, pic_weight, \
				article_weight, video_weight, obj_weight, user_weight, \
				ret_num, cmt_num, like_num, \
				ret_num_recent, cmt_num_recent, like_num_recent, \
				total_read_num, expose_num, act_num, inter_act_num, \
				expose_num_recent, act_num_recent,  inter_act_num_recent, \
				hot_ret_num, hot_cmt_num, hot_like_num, \
				hot_ret_num_recent, hot_cmt_num_recent, hot_like_num_recent, \
				article_read_num, miaopai_view_num, all_group_msg, hour_group_msg, extend ])) 
