#_*_ coding:utf8 _*_
import os
import sys
import re
re_mid = re.compile('mid[:=](\d+)')

if __name__ == '__main__':
	for line in sys.stdin:
		infos = line.strip().split('\t', 3)
		if len(infos) < 4:
			sys.stderr.write('format error: %s\n' % line.strip())
			continue
		uid, target_id, action, extend = infos[0:4]
		mid = None
		if ( target_id.startswith('3') or 
				target_id.startswith('4') ) and len(target_id) == 16:
			mid = target_id
		else:
			res_mids = re_mid.findall(extend)
			if len(res_mids) > 0:
				mid = res_mids[0]

		isautoplay = 0
		if 'isautoplay:1' in extend:
			isautoplay = 1

		if mid:
			print '%s\t%s\t%s\t%s\t%s' % (uid, mid, target_id, action, isautoplay)
