# _*_ coding:utf8 _*_
import os
import sys
import json

def detectInterType(max_weight):
	max_weight = float(max_weight) * 100
	if max_weight > 90:
		return 0
	if max_weight > 80:
		return 0.1
	if max_weight > 70:
		return 0.3
	if max_weight > 60:
		return 0.5
	if max_weight > 40:
		return 0.7
	return 1.0

if __name__ == '__main__':
	for line in sys.stdin:
		infos = line.strip().split('\t')
		if len(infos)  < 50:
			sys.stderr.write('format error: %s\n' % line.strip())
			continue
		service_type, uid, vid, aid, time, area_id, \
			parameter_type, error_code, error_msg, \
			time_spent_millis, domain, network_type, \
			enabledtriggers, category_id, id, ctr, \
			doc_detail, group_id, category, author_id, \
			recommend_source, ret_num, cmt_num, like_num, \
			ret_num_recent, cmt_num_recent, like_num_recent, \
			act_num, expose_num, act_num_recent, expose_num_recent, \
			article_read_num, miaopai_view_num, information_hot_tag_detail, \
			hot_weight, first_level_inte_weight, second_level_inte_weight, \
			third_level_inte_weight, effect_weight, pic_weight, \
			article_weight, video_weight, obj_weight, user_weight, \
			mblog_miaopai_num, extend, extend2, extend3, dt, hour, duration = infos[0:51]

		try:
			extend_info = json.loads(extend)
			exposure_info = json.loads(extend_info.get('exposure_interaction_rate','{}'))
			recommend_info = json.loads(extend_info.get('recommend_sources','{}'))
		except Exception as e:
			sys.stderr.write('json load error[%s]: %s\n' % ( e , line.strip()) )
			continue

		#print uid[-4], first_level_inte_weight, second_level_inte_weight, third_level_inte_weight, effect_weight, pic_weight, article_weight, video_weight, obj_weight, user_weight
		##if uid[-4] != '1' and uid[-4] != '9':
		##	first_level_inte_weight = 1.0 + float(first_level_inte_weight)/-1.10657431281
		##	second_level_inte_weight = 1.0 + float(second_level_inte_weight)/-1.31540199452
		##	third_level_inte_weight = 1.0 + float(third_level_inte_weight)/-0.505323006299
		##	effect_weight = float(effect_weight)/-0.764663013164
		##	pic_weight = float(pic_weight)/0.0151921700785
		##	article_weight = float(article_weight)/0.0129638331063
		##	video_weight = float(video_weight)/0.0222596026936
		##	obj_weight = float(obj_weight)/0.0144510752737
		##	user_weight = float(user_weight)/0.000001
		##else:
		##	first_level_inte_weight = detectInterType(float(first_level_inte_weight))
		##	second_level_inte_weight = detectInterType(float(second_level_inte_weight))
		##	third_level_inte_weight = detectInterType(float(third_level_inte_weight))
		#print uid[-4], first_level_inte_weight, second_level_inte_weight, third_level_inte_weight, effect_weight, pic_weight, article_weight, video_weight, obj_weight, user_weight

		total_read_num = extend_info.get('total_read_num',0)
		inter_act_num = exposure_info.get('inter_act_num',0)
		inter_act_num_recent = exposure_info.get('inter_act_num_recent',0)
		hot_ret_num = exposure_info.get('hot_ret_num',0)	
		hot_cmt_num = exposure_info.get('hot_cmt_num',0)	
		hot_like_num = exposure_info.get('hot_like_num',0)	
		hot_ret_num_recent = exposure_info.get('hot_ret_num_recent',0)	
		hot_cmt_num_recent = exposure_info.get('hot_cmt_num_recent',0)	
		hot_like_num_recent = exposure_info.get('hot_like_num_recent',0)	
		time_born_gender_action_list = exposure_info.get('time_born_gender_action_list',[])	
		recommend_base_level = recommend_info.get('recommend_source_detail',-1)	
		born = ""
		gender = ""
		user_tags = []
		doc_tags = []
		extend_msg = {}
		
		print '\t'.join(map(str, ( id, duration, uid, born, gender, area_id,
				user_tags, doc_tags, author_id, time, network_type, 
				recommend_source, recommend_base_level, category, 
				first_level_inte_weight, second_level_inte_weight, 
				third_level_inte_weight, effect_weight, pic_weight, 
				article_weight, video_weight, obj_weight, user_weight, 
				ret_num, cmt_num, like_num, 
				ret_num_recent, cmt_num_recent, like_num_recent, 
				total_read_num, expose_num, act_num, inter_act_num, 
				expose_num_recent, act_num_recent,  inter_act_num_recent, 
				hot_ret_num, hot_cmt_num, hot_like_num, 
				hot_ret_num_recent, hot_cmt_num_recent, hot_like_num_recent,
				article_read_num, miaopai_view_num, time_born_gender_action_list, extend_msg )))
